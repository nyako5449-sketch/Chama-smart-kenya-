export type UserRole = 
  | 'super_admin' 
  | 'chairperson' 
  | 'treasurer' 
  | 'secretary' 
  | 'member' 
  | 'auditor';

export type Language = 'en' | 'sw';

export type ChamaType = 
  | 'table_banking' 
  | 'investment_club' 
  | 'merry_go_round' 
  | 'welfare_sacco' 
  | 'family_savings';

export type ContributionFrequency = 'weekly' | 'monthly' | 'quarterly' | 'custom';

export type InterestMethod = 'flat_rate' | 'reducing_balance' | 'interest_free';

export interface User {
  id: string;
  fullName: string;
  phone: string; // Kenyan format e.g. +254712345678
  email: string;
  avatarUrl: string;
  nationalId: string;
  currentChamaId: string;
  joinedChamaIds: string[];
  preferredLanguage: Language;
  isVerified: boolean;
  createdAt: string;
}

export interface Chama {
  id: string;
  name: string;
  description: string;
  county: string;
  town: string;
  groupType: ChamaType;
  regNumber?: string;
  chairpersonId: string;
  treasurerId: string;
  secretaryId: string;
  contributionFrequency: ContributionFrequency;
  minContribution: number; // in KES
  welfareContribution: number; // in KES
  loanInterestMethod: InterestMethod;
  defaultInterestRatePercent: number; // e.g. 10%
  maxLoanRepaymentMonths: number;
  maxLoanMultiplier: number; // e.g. 3x savings
  latePenaltyPercent: number; // e.g. 5%
  meetingSchedule: string;
  inviteCode: string;
  isPremium: boolean;
  currency: string;
  bankAccountDetails?: string;
  mpesaPaybill?: string;
  createdAt: string;
}

export interface Member {
  id: string;
  chamaId: string;
  userId: string;
  memberNumber: string;
  fullName: string;
  phone: string;
  role: UserRole;
  status: 'active' | 'suspended' | 'pending_approval' | 'exited';
  joinedDate: string;
  totalSavings: number;
  totalWelfare: number;
  activeLoanCount: number;
  outstandingLoanBalance: number;
  attendanceRate: number; // percentage
  email?: string;
}

export interface Contribution {
  id: string;
  chamaId: string;
  memberId: string;
  memberName: string;
  memberPhone: string;
  amount: number;
  type: 'savings' | 'welfare' | 'special_project' | 'fine';
  cycleMonth: string; // YYYY-MM
  deadlineDate: string;
  paymentMethod: 'mpesa_daraja' | 'mpesa_manual' | 'bank_transfer' | 'cash';
  paymentReference: string;
  status: 'confirmed' | 'pending_reconciliation' | 'unpaid' | 'overdue';
  isMpesaVerified: boolean;
  receiptNumber: string;
  verifiedBy?: string;
  notes?: string;
  createdAt: string;
}

export interface RepaymentScheduleItem {
  installmentNumber: number;
  dueDate: string;
  principalDue: number;
  interestDue: number;
  totalDue: number;
  status: 'paid' | 'pending' | 'overdue';
  paidAt?: string;
}

export interface LoanGuarantor {
  memberId: string;
  memberName: string;
  amountGuaranteed: number;
  status: 'pledged' | 'confirmed';
}

export interface Loan {
  id: string;
  chamaId: string;
  memberId: string;
  memberName: string;
  memberPhone: string;
  requestedAmount: number;
  approvedAmount: number;
  interestMethod: InterestMethod;
  interestRatePercent: number;
  totalInterest: number;
  totalPayable: number;
  amountPaid: number;
  balanceRemaining: number;
  purpose: string;
  durationMonths: number;
  monthlyInstallment: number;
  applicationDate: string;
  approvalStatus: 'pending' | 'chair_approved' | 'fully_approved' | 'rejected' | 'disbursed' | 'settled';
  chairApprovedBy?: string;
  chairApprovedAt?: string;
  treasurerApprovedBy?: string;
  treasurerApprovedAt?: string;
  rejectedReason?: string;
  disbursedAt?: string;
  disbursementMethod?: 'mpesa' | 'bank' | 'cash';
  guarantors: LoanGuarantor[];
  schedule: RepaymentScheduleItem[];
  lateFeeAccrued: number;
}

export interface LoanRepayment {
  id: string;
  loanId: string;
  chamaId: string;
  memberId: string;
  memberName: string;
  amount: number;
  paymentMethod: 'mpesa' | 'bank' | 'cash';
  paymentReference: string;
  receiptNumber: string;
  paidAt: string;
  recordedBy: string;
}

export interface Expense {
  id: string;
  chamaId: string;
  title: string;
  category: 'meeting_refreshments' | 'welfare_benevolence' | 'bank_charges' | 'legal_audit' | 'investment_asset' | 'administrative' | 'other';
  amount: number;
  paidTo: string;
  paidFromAccount: 'cash' | 'bank' | 'mpesa_paybill';
  status: 'pending_approval' | 'approved' | 'rejected';
  approvedBy?: string;
  receiptUrl?: string;
  description: string;
  date: string;
  createdAt: string;
}

export type LedgerAccountType = 
  | 'cash_in_hand' 
  | 'bank_account' 
  | 'mpesa_float' 
  | 'member_savings' 
  | 'welfare_reserve' 
  | 'loans_receivable' 
  | 'interest_income' 
  | 'expenses';

export interface LedgerEntry {
  id: string;
  chamaId: string;
  reference: string;
  debitAccount: LedgerAccountType;
  creditAccount: LedgerAccountType;
  amount: number;
  narration: string;
  timestamp: string;
  auditHash: string;
  recordedBy: string;
}

export interface MeetingAgendaItem {
  id: string;
  title: string;
  durationMinutes: number;
  presenter: string;
}

export interface MeetingActionItem {
  id: string;
  task: string;
  assignedTo: string;
  dueDate: string;
  completed: boolean;
}

export interface MeetingPollOption {
  id: string;
  text: string;
  voteCount: number;
}

export interface MeetingPoll {
  id: string;
  question: string;
  options: MeetingPollOption[];
  votedUserIds: string[];
  isActive: boolean;
}

export interface Meeting {
  id: string;
  chamaId: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  venue: string;
  isVirtual: boolean;
  virtualLink?: string;
  agenda: MeetingAgendaItem[];
  minutes: string;
  isMinutesPublished: boolean;
  attendance: {
    memberId: string;
    memberName: string;
    status: 'present' | 'absent' | 'apology';
  }[];
  actionItems: MeetingActionItem[];
  polls: MeetingPoll[];
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'contribution_reminder' | 'loan_update' | 'meeting_alert' | 'mpesa_received' | 'system';
  timestamp: string;
  isRead: boolean;
  actionUrl?: string;
}

export interface AdMobConfig {
  enabled: boolean;
  testMode: boolean;
  bannerEnabled: boolean;
  interstitialEnabled: boolean;
  rewardedEnabled: boolean;
  nativeEnabled: boolean;
  bannerPlacements: {
    dashboardBottom: boolean;
    recordsBottom: boolean;
    reportsBottom: boolean;
    meetingsBottom: boolean;
  };
  interstitialFrequencyMins: number;
  lastInterstitialShownAt: number;
  testAdUnitIds: {
    banner: string;
    interstitial: string;
    rewarded: string;
    native: string;
  };
  totalImpressions: number;
  estimatedRevenueKes: number;
}

export interface AuditLog {
  id: string;
  chamaId: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  timestamp: string;
  ipAddress?: string;
}

export interface OfflineQueueItem {
  id: string;
  actionType: 'create_contribution' | 'submit_loan_repayment' | 'record_expense' | 'log_attendance';
  payload: any;
  queuedAt: string;
  status: 'pending' | 'synced' | 'failed';
  error?: string;
}
