import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Bell, CheckCircle2, Wifi, WifiOff 
} from 'lucide-react';
import { AndroidFrame } from './components/AndroidFrame';
import { HeaderBar } from './components/HeaderBar';
import { BottomNav, TabType } from './components/BottomNav';
import { DashboardView } from './views/DashboardView';
import { ContributionsView } from './views/ContributionsView';
import { LoansView } from './views/LoansView';
import { MembersView } from './views/MembersView';
import { MoreView, MoreSubScreen } from './views/MoreView';
import { MeetingsView } from './views/MeetingsView';
import { LedgerExpensesView } from './views/LedgerExpensesView';
import { ReportsView } from './views/ReportsView';
import { AdSettingsView } from './views/AdSettingsView';
import { SettingsPrivacyView } from './views/SettingsPrivacyView';

// Modals
import { MpesaStkModal } from './components/MpesaStkModal';
import { ReceiptModal } from './components/ReceiptModal';
import { LoanCalculatorModal } from './components/LoanCalculatorModal';
import { LoanApprovalModal } from './components/LoanApprovalModal';
import { ChamaSwitchModal } from './components/ChamaSwitchModal';
import { NotificationsModal } from './components/NotificationsModal';
import { AdMobInterstitialModal } from './components/AdMobInterstitialModal';
import { AdMobRewardedModal } from './components/AdMobRewardedModal';
import { DevDocsModal } from './components/DevDocsModal';
import { PublishModal } from './components/PublishModal';

import { storage } from './services/storageService';
import { Chama, Contribution, Language, Loan, UserRole } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [moreSubScreen, setMoreSubScreen] = useState<MoreSubScreen>('menu');
  const [activeChama, setActiveChama] = useState<Chama>(storage.getActiveChama());
  const [currentRole, setCurrentRole] = useState<UserRole>('chairperson');
  const [language, setLanguage] = useState<Language>('en');
  const [isOffline, setIsOffline] = useState<boolean>(storage.isOfflineSimulated());
  const [syncToastMessage, setSyncToastMessage] = useState<string | null>(null);

  // Modals state
  const [isStkOpen, setIsStkOpen] = useState(false);
  const [selectedContribution, setSelectedContribution] = useState<Contribution | null>(null);
  const [isLoanCalcOpen, setIsLoanCalcOpen] = useState(false);
  const [selectedLoanForApproval, setSelectedLoanForApproval] = useState<Loan | null>(null);
  const [isChamaSwitchOpen, setIsChamaSwitchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isInterstitialOpen, setIsInterstitialOpen] = useState(false);
  const [isRewardedOpen, setIsRewardedOpen] = useState(false);
  const [isRewardUnlocked, setIsRewardUnlocked] = useState(false);
  const [isDevDocsOpen, setIsDevDocsOpen] = useState(false);
  const [isPublishOpen, setIsPublishOpen] = useState(false);

  // Notifications
  const [notifications, setNotifications] = useState(storage.getNotifications());
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  useEffect(() => {
    const user = storage.getCurrentUser();
    setLanguage(user.preferredLanguage || 'en');
  }, []);

  const refreshAllData = () => {
    setActiveChama(storage.getActiveChama());
    setNotifications(storage.getNotifications());
  };

  const handleToggleOffline = () => {
    const next = !isOffline;
    setIsOffline(next);
    storage.setOfflineSimulated(next);

    if (!next) {
      // Switched to online: flush any pending offline actions
      const syncedCount = storage.flushOfflineQueue();
      if (syncedCount > 0) {
        setSyncToastMessage(`Synced ${syncedCount} offline transaction(s) to Chama ledger.`);
        setTimeout(() => setSyncToastMessage(null), 3500);
      } else {
        setSyncToastMessage('Back Online · All records synchronized.');
        setTimeout(() => setSyncToastMessage(null), 2500);
      }
      refreshAllData();
    } else {
      setSyncToastMessage('Offline Mode Enabled · Local queue active.');
      setTimeout(() => setSyncToastMessage(null), 2500);
    }
  };

  const handleRoleChanged = (newRole: UserRole) => {
    setCurrentRole(newRole);
    storage.switchRole(newRole);
    refreshAllData();
  };

  const handleToggleLanguage = () => {
    const next = language === 'en' ? 'sw' : 'en';
    setLanguage(next);
    const u = storage.getCurrentUser();
    u.preferredLanguage = next;
    storage.setCurrentUser(u);
  };

  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
    if (tab === 'more') {
      setMoreSubScreen('menu');
    }
  };

  return (
    <AndroidFrame 
      activeChamaName={activeChama.name}
      onOpenPublish={() => setIsPublishOpen(true)}
    >
      {/* Top Header */}
      <HeaderBar
        activeChama={activeChama}
        onOpenChamaSwitch={() => setIsChamaSwitchOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        unreadCount={unreadCount}
        currentLanguage={language}
        onToggleLanguage={handleToggleLanguage}
        isOffline={isOffline}
        onToggleOffline={handleToggleOffline}
        currentRole={currentRole}
        onRoleChanged={handleRoleChanged}
      />

      {/* Sync Toast Notification */}
      {syncToastMessage && (
        <div className="bg-slate-900 text-white text-[11px] px-3 py-2 flex items-center justify-between border-b border-slate-800 animate-in fade-in duration-150">
          <div className="flex items-center gap-1.5 font-medium">
            <CheckCircle2 size={13} className="text-emerald-400" />
            <span>{syncToastMessage}</span>
          </div>
        </div>
      )}

      {/* Main View Area */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {activeTab === 'dashboard' && (
          <DashboardView
            activeChama={activeChama}
            currentRole={currentRole}
            language={language}
            onOpenStkPush={() => setIsStkOpen(true)}
            onOpenLoanCalculator={() => setIsLoanCalcOpen(true)}
            onNavigateTab={handleTabChange}
            onSelectContributionForReceipt={(c) => setSelectedContribution(c)}
            onOpenAdMobRewarded={() => setIsRewardedOpen(true)}
          />
        )}

        {activeTab === 'transactions' && (
          <ContributionsView
            activeChama={activeChama}
            currentRole={currentRole}
            language={language}
            onOpenStkPush={() => setIsStkOpen(true)}
            onSelectContributionForReceipt={(c) => setSelectedContribution(c)}
          />
        )}

        {activeTab === 'loans' && (
          <LoansView
            activeChama={activeChama}
            currentRole={currentRole}
            language={language}
            onOpenLoanCalculator={() => setIsLoanCalcOpen(true)}
            onOpenLoanApproval={(l) => setSelectedLoanForApproval(l)}
            onRefreshData={refreshAllData}
          />
        )}

        {activeTab === 'members' && (
          <MembersView
            activeChama={activeChama}
            currentRole={currentRole}
            language={language}
          />
        )}

        {activeTab === 'more' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {moreSubScreen !== 'menu' && (
              <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 flex items-center gap-2 text-xs font-semibold text-slate-700">
                <button
                  onClick={() => setMoreSubScreen('menu')}
                  className="flex items-center gap-1 text-emerald-800 hover:text-emerald-950 font-bold"
                >
                  <ArrowLeft size={14} />
                  <span>Back to Menu</span>
                </button>
              </div>
            )}

            {moreSubScreen === 'menu' && (
              <MoreView
                activeChama={activeChama}
                currentRole={currentRole}
                language={language}
                onSelectSubScreen={(screen) => setMoreSubScreen(screen)}
                onOpenDevDocs={() => setIsDevDocsOpen(true)}
                onOpenPublish={() => setIsPublishOpen(true)}
              />
            )}

            {moreSubScreen === 'meetings' && (
              <MeetingsView
                activeChama={activeChama}
                currentRole={currentRole}
                language={language}
              />
            )}

            {moreSubScreen === 'ledger' && (
              <LedgerExpensesView
                activeChama={activeChama}
                currentRole={currentRole}
                language={language}
              />
            )}

            {moreSubScreen === 'reports' && (
              <ReportsView
                activeChama={activeChama}
                currentRole={currentRole}
                language={language}
                onOpenRewardedAd={() => setIsRewardedOpen(true)}
                isRewardUnlocked={isRewardUnlocked}
              />
            )}

            {moreSubScreen === 'ad_settings' && (
              <AdSettingsView
                activeChama={activeChama}
                currentRole={currentRole}
                language={language}
                onAdConfigUpdated={refreshAllData}
                onOpenTestInterstitial={() => setIsInterstitialOpen(true)}
                onOpenTestRewarded={() => setIsRewardedOpen(true)}
              />
            )}

            {moreSubScreen === 'privacy' && (
              <SettingsPrivacyView
                language={language}
                onToggleLanguage={handleToggleLanguage}
                onOpenDevDocs={() => setIsDevDocsOpen(true)}
                onRefreshData={refreshAllData}
              />
            )}
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={handleTabChange}
        language={language}
      />

      {/* Modals & Dialogs */}
      <MpesaStkModal
        isOpen={isStkOpen}
        onClose={() => setIsStkOpen(false)}
        onPaymentSuccess={(c) => {
          refreshAllData();
          setSelectedContribution(c);
        }}
      />

      <ReceiptModal
        isOpen={!!selectedContribution}
        contribution={selectedContribution}
        onClose={() => setSelectedContribution(null)}
      />

      <LoanCalculatorModal
        isOpen={isLoanCalcOpen}
        onClose={() => setIsLoanCalcOpen(false)}
        onLoanSubmitted={() => {
          refreshAllData();
          setActiveTab('loans');
        }}
      />

      <LoanApprovalModal
        isOpen={!!selectedLoanForApproval}
        loan={selectedLoanForApproval}
        onClose={() => setSelectedLoanForApproval(null)}
        onLoanUpdated={() => refreshAllData()}
      />

      <ChamaSwitchModal
        isOpen={isChamaSwitchOpen}
        onClose={() => setIsChamaSwitchOpen(false)}
        activeChamaId={activeChama.id}
        onChamaSelected={() => refreshAllData()}
      />

      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onRefresh={refreshAllData}
      />

      <AdMobInterstitialModal
        isOpen={isInterstitialOpen}
        onClose={() => setIsInterstitialOpen(false)}
      />

      <AdMobRewardedModal
        isOpen={isRewardedOpen}
        onClose={() => setIsRewardedOpen(false)}
        onRewardEarned={() => {
          setIsRewardUnlocked(true);
        }}
      />

      <DevDocsModal
        isOpen={isDevDocsOpen}
        onClose={() => setIsDevDocsOpen(false)}
      />

      <PublishModal
        isOpen={isPublishOpen}
        onClose={() => setIsPublishOpen(false)}
      />
    </AndroidFrame>
  );
}
