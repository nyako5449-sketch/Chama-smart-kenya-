import { InterestMethod, RepaymentScheduleItem } from '../types';

/**
 * Format amounts in Kenyan Shillings
 */
export function formatKES(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) {
    return 'KSh 0.00';
  }
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount).replace('KES', 'KSh');
}

/**
 * Normalizes Kenyan phone numbers to international +254 format
 * Handles formats like: 0712345678, 712345678, +254712345678, 254712345678, 0112345678
 */
export function normalizeKenyanPhone(phone: string): string {
  let cleaned = phone.replace(/\s+/g, '').replace(/[-()]/g, '');
  if (cleaned.startsWith('+254')) return cleaned;
  if (cleaned.startsWith('254')) return `+${cleaned}`;
  if (cleaned.startsWith('0')) return `+254${cleaned.slice(1)}`;
  if (cleaned.startsWith('7') || cleaned.startsWith('1')) return `+254${cleaned}`;
  return cleaned;
}

export function isValidKenyanPhone(phone: string): boolean {
  const norm = normalizeKenyanPhone(phone);
  // Kenya mobile prefixes: +254 7XX XXX XXX or +254 1XX XXX XXX (length 13 including +)
  return /^\+254[17][0-9]{8}$/.test(norm);
}

/**
 * Calculate loan repayments according to the group's agreed interest method
 */
export function calculateLoanBreakdown(
  principal: number,
  annualOrFlatInterestRatePercent: number,
  durationMonths: number,
  method: InterestMethod,
  startDate: Date = new Date()
): {
  totalInterest: number;
  totalPayable: number;
  monthlyInstallment: number;
  schedule: RepaymentScheduleItem[];
} {
  const schedule: RepaymentScheduleItem[] = [];

  if (principal <= 0 || durationMonths <= 0) {
    return { totalInterest: 0, totalPayable: 0, monthlyInstallment: 0, schedule: [] };
  }

  if (method === 'interest_free') {
    const monthlyPrincipal = Math.round((principal / durationMonths) * 100) / 100;
    let accumulatedPrincipal = 0;

    for (let i = 1; i <= durationMonths; i++) {
      const dueDate = new Date(startDate);
      dueDate.setMonth(dueDate.getMonth() + i);
      const isLast = i === durationMonths;
      const principalDue = isLast ? Math.round((principal - accumulatedPrincipal) * 100) / 100 : monthlyPrincipal;
      accumulatedPrincipal += principalDue;

      schedule.push({
        installmentNumber: i,
        dueDate: dueDate.toISOString().split('T')[0],
        principalDue,
        interestDue: 0,
        totalDue: principalDue,
        status: 'pending',
      });
    }

    return {
      totalInterest: 0,
      totalPayable: principal,
      monthlyInstallment: monthlyPrincipal,
      schedule,
    };
  }

  if (method === 'flat_rate') {
    // Flat rate: Total Interest = Principal * (Rate / 100)
    // Rate is treated as total loan period percentage as customary in Kenyan chamas (e.g., 10% flat for 3-6 months)
    const rateDecimal = annualOrFlatInterestRatePercent / 100;
    const totalInterest = Math.round(principal * rateDecimal * 100) / 100;
    const totalPayable = principal + totalInterest;
    const monthlyTotal = Math.round((totalPayable / durationMonths) * 100) / 100;
    const monthlyPrincipal = Math.round((principal / durationMonths) * 100) / 100;
    const monthlyInterest = Math.round((totalInterest / durationMonths) * 100) / 100;

    let accumulatedTotal = 0;
    for (let i = 1; i <= durationMonths; i++) {
      const dueDate = new Date(startDate);
      dueDate.setMonth(dueDate.getMonth() + i);
      const isLast = i === durationMonths;
      const installmentDue = isLast ? Math.round((totalPayable - accumulatedTotal) * 100) / 100 : monthlyTotal;
      accumulatedTotal += installmentDue;

      schedule.push({
        installmentNumber: i,
        dueDate: dueDate.toISOString().split('T')[0],
        principalDue: isLast ? totalPayable - totalInterest - (monthlyPrincipal * (durationMonths - 1)) : monthlyPrincipal,
        interestDue: isLast ? installmentDue - (totalPayable - totalInterest - (monthlyPrincipal * (durationMonths - 1))) : monthlyInterest,
        totalDue: installmentDue,
        status: 'pending',
      });
    }

    return {
      totalInterest,
      totalPayable,
      monthlyInstallment: monthlyTotal,
      schedule,
    };
  }

  // Reducing Balance Method (standard amortization formula)
  // Monthly interest rate r = (Rate / 100) / 12 (or per cycle)
  const monthlyRate = (annualOrFlatInterestRatePercent / 100) / 12;
  let monthlyPayment = 0;
  if (monthlyRate === 0) {
    monthlyPayment = principal / durationMonths;
  } else {
    monthlyPayment = (principal * (monthlyRate * Math.pow(1 + monthlyRate, durationMonths))) / (Math.pow(1 + monthlyRate, durationMonths) - 1);
  }

  let remainingPrincipal = principal;
  let totalInterest = 0;

  for (let i = 1; i <= durationMonths; i++) {
    const dueDate = new Date(startDate);
    dueDate.setMonth(dueDate.getMonth() + i);
    const interestForMonth = Math.round(remainingPrincipal * monthlyRate * 100) / 100;
    let principalForMonth = Math.round((monthlyPayment - interestForMonth) * 100) / 100;

    if (i === durationMonths || remainingPrincipal - principalForMonth < 0) {
      principalForMonth = remainingPrincipal;
    }

    const totalDue = Math.round((principalForMonth + interestForMonth) * 100) / 100;
    remainingPrincipal = Math.max(0, Math.round((remainingPrincipal - principalForMonth) * 100) / 100);
    totalInterest += interestForMonth;

    schedule.push({
      installmentNumber: i,
      dueDate: dueDate.toISOString().split('T')[0],
      principalDue: principalForMonth,
      interestDue: interestForMonth,
      totalDue,
      status: 'pending',
    });
  }

  totalInterest = Math.round(totalInterest * 100) / 100;
  const totalPayable = Math.round((principal + totalInterest) * 100) / 100;

  return {
    totalInterest,
    totalPayable,
    monthlyInstallment: Math.round(monthlyPayment * 100) / 100,
    schedule,
  };
}

/**
 * Generate official random transaction reference like Safaricom M-Pesa format (e.g. SIK8923XZQ)
 */
export function generateMpesaReference(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let ref = 'S';
  for (let i = 0; i < 9; i++) {
    ref += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return ref;
}

export function generateReceiptNumber(typePrefix: string = 'RC'): string {
  const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, '');
  const randNum = Math.floor(1000 + Math.random() * 9000);
  return `${typePrefix}-${dateStr}-${randNum}`;
}

/**
 * Parse a raw copied Safaricom SMS to auto-fill payment verification
 */
export function parseSafaricomSms(smsText: string): {
  reference?: string;
  amount?: number;
  senderPhone?: string;
  senderName?: string;
  dateStr?: string;
} | null {
  if (!smsText) return null;

  const refMatch = smsText.match(/\b([A-Z0-9]{8,12})\b\s+Confirmed/i) || smsText.match(/\b([A-Z0-9]{10})\b/i);
  const amountMatch = smsText.match(/Ksh\.?\s?([0-9,]+(\.[0-9]{1,2})?)/i) || smsText.match(/KES\.?\s?([0-9,]+(\.[0-9]{1,2})?)/i);
  const phoneMatch = smsText.match(/(\+?254\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{3}|0[17][0-9]{2}\s?[0-9]{3}\s?[0-9]{3})/i);
  
  const reference = refMatch ? refMatch[1].toUpperCase() : undefined;
  const amount = amountMatch ? parseFloat(amountMatch[1].replace(/,/g, '')) : undefined;
  const senderPhone = phoneMatch ? normalizeKenyanPhone(phoneMatch[1].replace(/\s+/g, '')) : undefined;

  return {
    reference,
    amount,
    senderPhone,
  };
}
