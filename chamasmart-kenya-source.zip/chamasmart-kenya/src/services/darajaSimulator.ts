import { generateMpesaReference } from './calculations';

export interface StkPushRequest {
  phoneNumber: string; // 2547XXXXXXXX
  amount: number;
  accountReference: string; // e.g. Chama Member Number or Group Name
  transactionDesc: string;
}

export interface StkPushResponse {
  merchantRequestId: string;
  checkoutRequestId: string;
  responseCode: string;
  responseDescription: string;
  customerMessage: string;
}

export interface StkCallbackResult {
  merchantRequestId: string;
  checkoutRequestId: string;
  resultCode: number;
  resultDesc: string;
  mpesaReceiptNumber?: string;
  amount?: number;
  phoneNumber?: string;
  transactionDate?: string;
}

export class DarajaService {
  /**
   * Simulate Safaricom Daraja STK Push Request
   */
  static async initiateStkPush(req: StkPushRequest): Promise<StkPushResponse> {
    // Simulate network delay
    await new Promise((res) => setTimeout(res, 800));

    const timestamp = Date.now();
    return {
      merchantRequestId: `29115-34620-${timestamp.toString().slice(-5)}`,
      checkoutRequestId: `ws_CO_${timestamp}_${Math.floor(100000 + Math.random() * 900000)}`,
      responseCode: '0',
      responseDescription: 'Success. Request accepted for processing',
      customerMessage: `Success. Prompt sent to ${req.phoneNumber}. Enter M-Pesa PIN to complete payment of KSh ${req.amount}.`,
    };
  }

  /**
   * Simulate USSD PIN entry and Safaricom callback response
   */
  static async completeSimulatedPayment(
    checkoutRequestId: string,
    phoneNumber: string,
    amount: number,
    isApproved: boolean = true
  ): Promise<StkCallbackResult> {
    await new Promise((res) => setTimeout(res, 1200));

    if (!isApproved) {
      return {
        merchantRequestId: `MR-${Date.now()}`,
        checkoutRequestId,
        resultCode: 1032,
        resultDesc: '[STK_CB] Request cancelled by user.',
      };
    }

    const receipt = generateMpesaReference();
    const now = new Date();
    const formattedDate = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}`;

    return {
      merchantRequestId: `MR-${Date.now()}`,
      checkoutRequestId,
      resultCode: 0,
      resultDesc: 'The service request is processed successfully.',
      mpesaReceiptNumber: receipt,
      amount,
      phoneNumber,
      transactionDate: formattedDate,
    };
  }
}
