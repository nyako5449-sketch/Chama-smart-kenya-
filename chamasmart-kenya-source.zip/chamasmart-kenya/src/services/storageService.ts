import { 
  User, Chama, Member, Contribution, Loan, LoanRepayment, 
  Expense, LedgerEntry, Meeting, NotificationItem, 
  AdMobConfig, AuditLog, OfflineQueueItem, UserRole, Language 
} from '../types';
import { generateReceiptNumber } from './calculations';

const STORAGE_KEYS = {
  CURRENT_USER: 'chamasmart_current_user',
  ACTIVE_CHAMA_ID: 'chamasmart_active_chama_id',
  CHAMAS: 'chamasmart_chamas',
  MEMBERS: 'chamasmart_members',
  CONTRIBUTIONS: 'chamasmart_contributions',
  LOANS: 'chamasmart_loans',
  REPAYMENTS: 'chamasmart_repayments',
  EXPENSES: 'chamasmart_expenses',
  LEDGER: 'chamasmart_ledger',
  MEETINGS: 'chamasmart_meetings',
  NOTIFICATIONS: 'chamasmart_notifications',
  ADMOB: 'chamasmart_admob',
  AUDIT_LOGS: 'chamasmart_audit_logs',
  OFFLINE_QUEUE: 'chamasmart_offline_queue',
  IS_OFFLINE_SIMULATED: 'chamasmart_is_offline',
  DEVICE_VIEW_MODE: 'chamasmart_device_view_mode',
};

const SEED_CURRENT_USER: User = {
  id: 'usr_001',
  fullName: 'Grace Wanjiku Mwangi',
  phone: '+254712345678',
  email: 'grace.wanjiku@chamasmart.ke',
  avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
  nationalId: '29841029',
  currentChamaId: 'chama_tumaini',
  joinedChamaIds: ['chama_tumaini', 'chama_hustlers', 'chama_ushirikiano'],
  preferredLanguage: 'en',
  isVerified: true,
  createdAt: '2025-01-15T08:00:00Z',
};

const SEED_CHAMAS: Chama[] = [
  {
    id: 'chama_tumaini',
    name: 'Tumaini Women Table Banking',
    description: 'Empowering women entrepreneurs in Nakuru through monthly table banking savings, soft business loans, and family welfare support.',
    county: 'Nakuru',
    town: 'Nakuru City',
    groupType: 'table_banking',
    regNumber: 'NKU/CD/CBO/2023/491',
    chairpersonId: 'usr_001',
    treasurerId: 'usr_002',
    secretaryId: 'usr_003',
    contributionFrequency: 'monthly',
    minContribution: 2500,
    welfareContribution: 500,
    loanInterestMethod: 'flat_rate',
    defaultInterestRatePercent: 10,
    maxLoanRepaymentMonths: 6,
    maxLoanMultiplier: 3,
    latePenaltyPercent: 5,
    meetingSchedule: 'First Saturday of every month at 2:00 PM',
    inviteCode: 'TUMAINI-2026',
    isPremium: false,
    currency: 'KES',
    bankAccountDetails: 'KCB Bank - Nakuru West Branch, A/C: 1184920194',
    mpesaPaybill: '408221',
    createdAt: '2024-03-10T10:00:00Z',
  },
  {
    id: 'chama_hustlers',
    name: 'Nairobi Hustlers Investment Club',
    description: 'Youth-led professional syndicate pooling capital for commercial real estate, treasury bills, and agribusiness in Kenya.',
    county: 'Nairobi',
    town: 'Westlands',
    groupType: 'investment_club',
    regNumber: 'NRB/REG/INV/2024/099',
    chairpersonId: 'usr_005',
    treasurerId: 'usr_001',
    secretaryId: 'usr_004',
    contributionFrequency: 'monthly',
    minContribution: 10000,
    welfareContribution: 1000,
    loanInterestMethod: 'reducing_balance',
    defaultInterestRatePercent: 12,
    maxLoanRepaymentMonths: 12,
    maxLoanMultiplier: 4,
    latePenaltyPercent: 10,
    meetingSchedule: 'Third Sunday bi-monthly at 4:00 PM (Hybrid/Zoom & Physical)',
    inviteCode: 'HUSTLE-NAIROBI',
    isPremium: true,
    currency: 'KES',
    bankAccountDetails: 'NCBA Bank - Upper Hill Branch, A/C: 8492018821',
    mpesaPaybill: '522522',
    createdAt: '2024-06-01T12:00:00Z',
  },
  {
    id: 'chama_ushirikiano',
    name: 'Ushirikiano Welfare SACCO Group',
    description: 'Community emergency and benevolence solidarity group providing urgent healthcare, bereavement, and school fees support.',
    county: 'Nyeri',
    town: 'Karatina',
    groupType: 'welfare_sacco',
    regNumber: 'NYR/WELFARE/2022/104',
    chairpersonId: 'usr_003',
    treasurerId: 'usr_006',
    secretaryId: 'usr_001',
    contributionFrequency: 'monthly',
    minContribution: 1000,
    welfareContribution: 1000,
    loanInterestMethod: 'interest_free',
    defaultInterestRatePercent: 0,
    maxLoanRepaymentMonths: 3,
    maxLoanMultiplier: 2,
    latePenaltyPercent: 0,
    meetingSchedule: 'Last Sunday of each month at 3:00 PM at Community Hall',
    inviteCode: 'USHIRIKIANO-NYERI',
    isPremium: false,
    currency: 'KES',
    bankAccountDetails: 'Equity Bank - Karatina Branch, A/C: 04901928374',
    mpesaPaybill: '247247',
    createdAt: '2023-09-15T09:00:00Z',
  }
];

const SEED_MEMBERS: Member[] = [
  {
    id: 'mem_001',
    chamaId: 'chama_tumaini',
    userId: 'usr_001',
    memberNumber: 'CSK-001',
    fullName: 'Grace Wanjiku Mwangi',
    phone: '+254712345678',
    role: 'chairperson',
    status: 'active',
    joinedDate: '2024-03-10',
    totalSavings: 48000,
    totalWelfare: 6000,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 98,
    email: 'grace.wanjiku@chamasmart.ke'
  },
  {
    id: 'mem_002',
    chamaId: 'chama_tumaini',
    userId: 'usr_002',
    memberNumber: 'CSK-002',
    fullName: 'Mary Akinyi Otieno',
    phone: '+254722987654',
    role: 'treasurer',
    status: 'active',
    joinedDate: '2024-03-10',
    totalSavings: 45000,
    totalWelfare: 6000,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 100,
    email: 'mary.akinyi@gmail.com'
  },
  {
    id: 'mem_003',
    chamaId: 'chama_tumaini',
    userId: 'usr_003',
    memberNumber: 'CSK-003',
    fullName: 'Beatrice Wambui Ndung\'u',
    phone: '+254733456789',
    role: 'secretary',
    status: 'active',
    joinedDate: '2024-03-10',
    totalSavings: 38500,
    totalWelfare: 5500,
    activeLoanCount: 1,
    outstandingLoanBalance: 15400,
    attendanceRate: 95,
    email: 'wambui.beatrice@yahoo.com'
  },
  {
    id: 'mem_004',
    chamaId: 'chama_tumaini',
    userId: 'usr_004',
    memberNumber: 'CSK-004',
    fullName: 'Faith Chebet Korir',
    phone: '+254701234567',
    role: 'member',
    status: 'active',
    joinedDate: '2024-04-01',
    totalSavings: 32000,
    totalWelfare: 4500,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 90,
  },
  {
    id: 'mem_005',
    chamaId: 'chama_tumaini',
    userId: 'usr_005',
    memberNumber: 'CSK-005',
    fullName: 'Peter Omondi Juma',
    phone: '+254720998877',
    role: 'member',
    status: 'active',
    joinedDate: '2024-04-15',
    totalSavings: 27500,
    totalWelfare: 4000,
    activeLoanCount: 1,
    outstandingLoanBalance: 24200,
    attendanceRate: 85,
  },
  {
    id: 'mem_006',
    chamaId: 'chama_tumaini',
    userId: 'usr_006',
    memberNumber: 'CSK-006',
    fullName: 'David Kiprono Cheruiyot',
    phone: '+254714556677',
    role: 'auditor',
    status: 'active',
    joinedDate: '2024-05-01',
    totalSavings: 25000,
    totalWelfare: 3500,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 92,
  },
  {
    id: 'mem_007',
    chamaId: 'chama_tumaini',
    userId: 'usr_007',
    memberNumber: 'CSK-007',
    fullName: 'Esther Moraa Nyachae',
    phone: '+254728112233',
    role: 'member',
    status: 'active',
    joinedDate: '2024-06-01',
    totalSavings: 22500,
    totalWelfare: 3000,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 88,
  },
  {
    id: 'mem_008',
    chamaId: 'chama_tumaini',
    userId: 'usr_008',
    memberNumber: 'CSK-008',
    fullName: 'Samuel Mwangi Githinji',
    phone: '+254799001122',
    role: 'member',
    status: 'active',
    joinedDate: '2024-06-15',
    totalSavings: 18000,
    totalWelfare: 2500,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 80,
  },
  // Nairobi Hustlers Investment Club (Westlands)
  {
    id: 'mem_h01',
    chamaId: 'chama_hustlers',
    userId: 'usr_005',
    memberNumber: 'NHC-001',
    fullName: 'Peter Omondi Juma',
    phone: '+254720998877',
    role: 'chairperson',
    status: 'active',
    joinedDate: '2024-06-01',
    totalSavings: 120000,
    totalWelfare: 12000,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 95,
  },
  {
    id: 'mem_h02',
    chamaId: 'chama_hustlers',
    userId: 'usr_001',
    memberNumber: 'NHC-002',
    fullName: 'Grace Wanjiku Mwangi',
    phone: '+254712345678',
    role: 'treasurer',
    status: 'active',
    joinedDate: '2024-06-01',
    totalSavings: 110000,
    totalWelfare: 11000,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 100,
  },
  {
    id: 'mem_h03',
    chamaId: 'chama_hustlers',
    userId: 'usr_004',
    memberNumber: 'NHC-003',
    fullName: 'Faith Chebet Korir',
    phone: '+254701234567',
    role: 'secretary',
    status: 'active',
    joinedDate: '2024-06-01',
    totalSavings: 95000,
    totalWelfare: 9500,
    activeLoanCount: 1,
    outstandingLoanBalance: 60000,
    attendanceRate: 90,
  },
  // Ushirikiano Welfare SACCO Group (Nyeri)
  {
    id: 'mem_u01',
    chamaId: 'chama_ushirikiano',
    userId: 'usr_003',
    memberNumber: 'USK-001',
    fullName: 'Beatrice Wambui Ndung\'u',
    phone: '+254733456789',
    role: 'chairperson',
    status: 'active',
    joinedDate: '2023-09-15',
    totalSavings: 36000,
    totalWelfare: 36000,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 96,
  },
  {
    id: 'mem_u02',
    chamaId: 'chama_ushirikiano',
    userId: 'usr_006',
    memberNumber: 'USK-002',
    fullName: 'David Kiprono Cheruiyot',
    phone: '+254714556677',
    role: 'treasurer',
    status: 'active',
    joinedDate: '2023-09-15',
    totalSavings: 30000,
    totalWelfare: 30000,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 92,
  },
  {
    id: 'mem_u03',
    chamaId: 'chama_ushirikiano',
    userId: 'usr_001',
    memberNumber: 'USK-003',
    fullName: 'Grace Wanjiku Mwangi',
    phone: '+254712345678',
    role: 'secretary',
    status: 'active',
    joinedDate: '2023-09-15',
    totalSavings: 28000,
    totalWelfare: 28000,
    activeLoanCount: 0,
    outstandingLoanBalance: 0,
    attendanceRate: 98,
  }
];

const SEED_CONTRIBUTIONS: Contribution[] = [
  {
    id: 'cnt_001',
    chamaId: 'chama_tumaini',
    memberId: 'mem_001',
    memberName: 'Grace Wanjiku Mwangi',
    memberPhone: '+254712345678',
    amount: 3000, // 2500 savings + 500 welfare
    type: 'savings',
    cycleMonth: '2026-10',
    deadlineDate: '2026-10-05',
    paymentMethod: 'mpesa_daraja',
    paymentReference: 'SIK891KLD3',
    status: 'confirmed',
    isMpesaVerified: true,
    receiptNumber: 'RC-2610-4821',
    verifiedBy: 'Safaricom Daraja API',
    notes: 'October monthly savings + welfare',
    createdAt: '2026-10-04T11:20:00Z',
  },
  {
    id: 'cnt_002',
    chamaId: 'chama_tumaini',
    memberId: 'mem_002',
    memberName: 'Mary Akinyi Otieno',
    memberPhone: '+254722987654',
    amount: 3000,
    type: 'savings',
    cycleMonth: '2026-10',
    deadlineDate: '2026-10-05',
    paymentMethod: 'mpesa_daraja',
    paymentReference: 'SIK922QPR8',
    status: 'confirmed',
    isMpesaVerified: true,
    receiptNumber: 'RC-2610-4822',
    verifiedBy: 'Safaricom Daraja API',
    notes: 'Prompt M-Pesa contribution',
    createdAt: '2026-10-04T14:15:00Z',
  },
  {
    id: 'cnt_003',
    chamaId: 'chama_tumaini',
    memberId: 'mem_003',
    memberName: 'Beatrice Wambui Ndung\'u',
    memberPhone: '+254733456789',
    amount: 3000,
    type: 'savings',
    cycleMonth: '2026-10',
    deadlineDate: '2026-10-05',
    paymentMethod: 'mpesa_manual',
    paymentReference: 'SIK711MM99',
    status: 'confirmed',
    isMpesaVerified: true,
    receiptNumber: 'RC-2610-4823',
    verifiedBy: 'Mary Akinyi (Treasurer)',
    notes: 'Reconciled from Safaricom SMS forwarded by member',
    createdAt: '2026-10-05T09:40:00Z',
  },
  {
    id: 'cnt_004',
    chamaId: 'chama_tumaini',
    memberId: 'mem_004',
    memberName: 'Faith Chebet Korir',
    memberPhone: '+254701234567',
    amount: 3000,
    type: 'savings',
    cycleMonth: '2026-10',
    deadlineDate: '2026-10-05',
    paymentMethod: 'bank_transfer',
    paymentReference: 'KCB-TRF-902188',
    status: 'confirmed',
    isMpesaVerified: false,
    receiptNumber: 'RC-2610-4824',
    verifiedBy: 'Mary Akinyi (Treasurer)',
    notes: 'Bank slip reconciled with KCB statement',
    createdAt: '2026-10-05T16:00:00Z',
  },
  {
    id: 'cnt_005',
    chamaId: 'chama_tumaini',
    memberId: 'mem_005',
    memberName: 'Peter Omondi Juma',
    memberPhone: '+254720998877',
    amount: 3000,
    type: 'savings',
    cycleMonth: '2026-10',
    deadlineDate: '2026-10-05',
    paymentMethod: 'cash',
    paymentReference: 'CASH-REC-104',
    status: 'confirmed',
    isMpesaVerified: false,
    receiptNumber: 'RC-2610-4825',
    verifiedBy: 'Grace Wanjiku (Chairperson)',
    notes: 'Paid cash during physical Saturday table banking meeting',
    createdAt: '2026-10-06T15:30:00Z',
  },
  {
    id: 'cnt_006',
    chamaId: 'chama_tumaini',
    memberId: 'mem_007',
    memberName: 'Esther Moraa Nyachae',
    memberPhone: '+254728112233',
    amount: 3000,
    type: 'savings',
    cycleMonth: '2026-10',
    deadlineDate: '2026-10-05',
    paymentMethod: 'mpesa_manual',
    paymentReference: 'PENDING-REC-01',
    status: 'pending_reconciliation',
    isMpesaVerified: false,
    receiptNumber: 'RC-2610-PEND-01',
    notes: 'Member reported M-Pesa transfer, waiting for Treasurer to verify Safaricom statement',
    createdAt: '2026-10-18T10:12:00Z',
  }
];

const SEED_LOANS: Loan[] = [
  {
    id: 'loan_001',
    chamaId: 'chama_tumaini',
    memberId: 'mem_003',
    memberName: 'Beatrice Wambui Ndung\'u',
    memberPhone: '+254733456789',
    requestedAmount: 30000,
    approvedAmount: 30000,
    interestMethod: 'flat_rate',
    interestRatePercent: 10,
    totalInterest: 3000,
    totalPayable: 33000,
    amountPaid: 17600,
    balanceRemaining: 15400,
    purpose: 'Stocking boutique clothing inventory for end-of-year sales in Nakuru CBD',
    durationMonths: 6,
    monthlyInstallment: 5500,
    applicationDate: '2026-07-02',
    approvalStatus: 'disbursed',
    chairApprovedBy: 'Grace Wanjiku',
    chairApprovedAt: '2026-07-03T10:00:00Z',
    treasurerApprovedBy: 'Mary Akinyi',
    treasurerApprovedAt: '2026-07-03T14:30:00Z',
    disbursedAt: '2026-07-04T09:00:00Z',
    disbursementMethod: 'mpesa',
    guarantors: [
      { memberId: 'mem_001', memberName: 'Grace Wanjiku', amountGuaranteed: 15000, status: 'confirmed' },
      { memberId: 'mem_002', memberName: 'Mary Akinyi', amountGuaranteed: 15000, status: 'confirmed' }
    ],
    schedule: [
      { installmentNumber: 1, dueDate: '2026-08-04', principalDue: 5000, interestDue: 500, totalDue: 5500, status: 'paid', paidAt: '2026-08-03' },
      { installmentNumber: 2, dueDate: '2026-09-04', principalDue: 5000, interestDue: 500, totalDue: 5500, status: 'paid', paidAt: '2026-09-04' },
      { installmentNumber: 3, dueDate: '2026-10-04', principalDue: 5000, interestDue: 500, totalDue: 5500, status: 'paid', paidAt: '2026-10-02' },
      { installmentNumber: 4, dueDate: '2026-11-04', principalDue: 5000, interestDue: 500, totalDue: 5500, status: 'pending' },
      { installmentNumber: 5, dueDate: '2026-12-04', principalDue: 5000, interestDue: 500, totalDue: 5500, status: 'pending' },
      { installmentNumber: 6, dueDate: '2027-01-04', principalDue: 5000, interestDue: 500, totalDue: 5500, status: 'pending' },
    ],
    lateFeeAccrued: 0,
  },
  {
    id: 'loan_002',
    chamaId: 'chama_tumaini',
    memberId: 'mem_005',
    memberName: 'Peter Omondi Juma',
    memberPhone: '+254720998877',
    requestedAmount: 40000,
    approvedAmount: 40000,
    interestMethod: 'flat_rate',
    interestRatePercent: 10,
    totalInterest: 4000,
    totalPayable: 44000,
    amountPaid: 19800,
    balanceRemaining: 24200,
    purpose: 'Procuring solar battery storage and wiring for dairy chilling station',
    durationMonths: 4,
    monthlyInstallment: 11000,
    applicationDate: '2026-08-10',
    approvalStatus: 'disbursed',
    chairApprovedBy: 'Grace Wanjiku',
    chairApprovedAt: '2026-08-11T11:00:00Z',
    treasurerApprovedBy: 'Mary Akinyi',
    treasurerApprovedAt: '2026-08-11T16:00:00Z',
    disbursedAt: '2026-08-12T10:00:00Z',
    disbursementMethod: 'mpesa',
    guarantors: [
      { memberId: 'mem_004', memberName: 'Faith Chebet', amountGuaranteed: 20000, status: 'confirmed' },
      { memberId: 'mem_006', memberName: 'David Cheruiyot', amountGuaranteed: 20000, status: 'confirmed' }
    ],
    schedule: [
      { installmentNumber: 1, dueDate: '2026-09-12', principalDue: 10000, interestDue: 1000, totalDue: 11000, status: 'paid', paidAt: '2026-09-11' },
      { installmentNumber: 2, dueDate: '2026-10-12', principalDue: 10000, interestDue: 1000, totalDue: 11000, status: 'overdue' },
      { installmentNumber: 3, dueDate: '2026-11-12', principalDue: 10000, interestDue: 1000, totalDue: 11000, status: 'pending' },
      { installmentNumber: 4, dueDate: '2026-12-12', principalDue: 10000, interestDue: 1000, totalDue: 11000, status: 'pending' },
    ],
    lateFeeAccrued: 550, // 5% of 11,000 late fee
  },
  {
    id: 'loan_003',
    chamaId: 'chama_tumaini',
    memberId: 'mem_004',
    memberName: 'Faith Chebet Korir',
    memberPhone: '+254701234567',
    requestedAmount: 20000,
    approvedAmount: 20000,
    interestMethod: 'flat_rate',
    interestRatePercent: 10,
    totalInterest: 2000,
    totalPayable: 22000,
    amountPaid: 0,
    balanceRemaining: 22000,
    purpose: 'Secondary school fees second-term top-up for children',
    durationMonths: 4,
    monthlyInstallment: 5500,
    applicationDate: '2026-10-19',
    approvalStatus: 'chair_approved', // Awaiting Treasurer
    chairApprovedBy: 'Grace Wanjiku',
    chairApprovedAt: '2026-10-20T08:30:00Z',
    guarantors: [
      { memberId: 'mem_001', memberName: 'Grace Wanjiku', amountGuaranteed: 10000, status: 'confirmed' },
      { memberId: 'mem_003', memberName: 'Beatrice Wambui', amountGuaranteed: 10000, status: 'confirmed' }
    ],
    schedule: [],
    lateFeeAccrued: 0,
  },
  {
    id: 'loan_h01',
    chamaId: 'chama_hustlers',
    memberId: 'mem_h03',
    memberName: 'Faith Chebet Korir',
    memberPhone: '+254701234567',
    requestedAmount: 100000,
    approvedAmount: 100000,
    interestMethod: 'reducing_balance',
    interestRatePercent: 12,
    totalInterest: 6618,
    totalPayable: 106618,
    amountPaid: 46618,
    balanceRemaining: 60000,
    purpose: 'Importing drone multispectral cameras for precision tea plantation survey',
    durationMonths: 12,
    monthlyInstallment: 8885,
    applicationDate: '2026-05-10',
    approvalStatus: 'disbursed',
    chairApprovedBy: 'Peter Omondi',
    chairApprovedAt: '2026-05-11T09:00:00Z',
    treasurerApprovedBy: 'Grace Wanjiku',
    treasurerApprovedAt: '2026-05-11T12:00:00Z',
    disbursedAt: '2026-05-12T08:00:00Z',
    disbursementMethod: 'bank',
    guarantors: [
      { memberId: 'mem_h01', memberName: 'Peter Omondi', amountGuaranteed: 50000, status: 'confirmed' },
      { memberId: 'mem_h02', memberName: 'Grace Wanjiku', amountGuaranteed: 50000, status: 'confirmed' },
    ],
    schedule: [
      { installmentNumber: 1, dueDate: '2026-06-12', principalDue: 7885, interestDue: 1000, totalDue: 8885, status: 'paid', paidAt: '2026-06-11' },
      { installmentNumber: 2, dueDate: '2026-07-12', principalDue: 7964, interestDue: 921, totalDue: 8885, status: 'paid', paidAt: '2026-07-12' },
      { installmentNumber: 3, dueDate: '2026-08-12', principalDue: 8043, interestDue: 842, totalDue: 8885, status: 'paid', paidAt: '2026-08-10' },
      { installmentNumber: 4, dueDate: '2026-09-12', principalDue: 8124, interestDue: 761, totalDue: 8885, status: 'paid', paidAt: '2026-09-12' },
      { installmentNumber: 5, dueDate: '2026-10-12', principalDue: 8205, interestDue: 680, totalDue: 8885, status: 'paid', paidAt: '2026-10-10' },
      { installmentNumber: 6, dueDate: '2026-11-12', principalDue: 8287, interestDue: 598, totalDue: 8885, status: 'pending' },
    ],
    lateFeeAccrued: 0,
  }
];

const SEED_EXPENSES: Expense[] = [
  {
    id: 'exp_001',
    chamaId: 'chama_tumaini',
    title: 'Monthly Table Banking Venue & Tea Refreshments',
    category: 'meeting_refreshments',
    amount: 3200,
    paidTo: 'Nakuru Catholic Hall Caretaker & Catering',
    paidFromAccount: 'cash',
    status: 'approved',
    approvedBy: 'Grace Wanjiku',
    description: 'Meeting room hire, drinking water, and hot tea for 18 attending members',
    date: '2026-10-06',
    createdAt: '2026-10-06T17:00:00Z',
  },
  {
    id: 'exp_002',
    chamaId: 'chama_tumaini',
    title: 'KCB Bank Ledger Maintenance & SMS Alert Fees',
    category: 'bank_charges',
    amount: 850,
    paidTo: 'KCB Bank Nakuru Branch',
    paidFromAccount: 'bank',
    status: 'approved',
    approvedBy: 'Mary Akinyi',
    description: 'Quarterly group account ledger maintenance and transaction SMS charges',
    date: '2026-09-30',
    createdAt: '2026-09-30T23:59:00Z',
  },
  {
    id: 'exp_003',
    chamaId: 'chama_tumaini',
    title: 'Welfare Berevolence Support — Member Family Hospitalization',
    category: 'welfare_benevolence',
    amount: 10000,
    paidTo: 'Beatrice Wambui (Emergency Patient Bill)',
    paidFromAccount: 'mpesa_paybill',
    status: 'approved',
    approvedBy: 'Grace Wanjiku & Mary Akinyi',
    description: 'Approved benevolent solidarity grant from Chama Welfare Reserve for daughter\'s appendectomy bill at Nakuru Provincial Hospital',
    date: '2026-09-18',
    createdAt: '2026-09-18T10:00:00Z',
  }
];

const SEED_LEDGER_ENTRIES: LedgerEntry[] = [
  {
    id: 'led_001',
    chamaId: 'chama_tumaini',
    reference: 'LED-2610-001',
    debitAccount: 'mpesa_float',
    creditAccount: 'member_savings',
    amount: 2500,
    narration: 'October Savings received via M-Pesa STK (Grace Wanjiku)',
    timestamp: '2026-10-04T11:20:00Z',
    auditHash: 'a89f31c4e908b',
    recordedBy: 'System (Daraja)',
  },
  {
    id: 'led_002',
    chamaId: 'chama_tumaini',
    reference: 'LED-2610-002',
    debitAccount: 'mpesa_float',
    creditAccount: 'welfare_reserve',
    amount: 500,
    narration: 'October Welfare kitty contribution (Grace Wanjiku)',
    timestamp: '2026-10-04T11:20:00Z',
    auditHash: 'b45129ff103cc',
    recordedBy: 'System (Daraja)',
  },
  {
    id: 'led_003',
    chamaId: 'chama_tumaini',
    reference: 'LED-2610-003',
    debitAccount: 'loans_receivable',
    creditAccount: 'mpesa_float',
    amount: 30000,
    narration: 'Disbursed business expansion loan to Beatrice Wambui',
    timestamp: '2026-07-04T09:00:00Z',
    auditHash: 'c77201bb8812a',
    recordedBy: 'Treasurer Mary Akinyi',
  },
  {
    id: 'led_004',
    chamaId: 'chama_tumaini',
    reference: 'LED-2610-004',
    debitAccount: 'expenses',
    creditAccount: 'cash_in_hand',
    amount: 3200,
    narration: 'Meeting venue hire and tea refreshments',
    timestamp: '2026-10-06T17:00:00Z',
    auditHash: 'd99823cc7701e',
    recordedBy: 'Chairperson Grace Wanjiku',
  }
];

const SEED_MEETINGS: Meeting[] = [
  {
    id: 'mtg_001',
    chamaId: 'chama_tumaini',
    title: 'October Monthly Table Banking & Annual Investment Review',
    date: '2026-10-06',
    startTime: '14:00',
    endTime: '16:30',
    venue: 'St. Paul Community Hall, Nakuru West',
    isVirtual: false,
    agenda: [
      { id: 'ag_1', title: 'Opening Prayer & Chairperson Remarks', durationMinutes: 15, presenter: 'Grace Wanjiku' },
      { id: 'ag_2', title: 'Table Banking Contributions & Loan Reconciliation', durationMinutes: 45, presenter: 'Mary Akinyi (Treasurer)' },
      { id: 'ag_3', title: 'Review of Late Loans & Guarantor Notifications', durationMinutes: 30, presenter: 'Beatrice Wambui (Secretary)' },
      { id: 'ag_4', title: 'Vote: Approval of 50-Acre Grain Storage Joint Investment', durationMinutes: 30, presenter: 'Grace Wanjiku' },
      { id: 'ag_5', title: 'AOB & Next Meeting Date', durationMinutes: 15, presenter: 'Members' },
    ],
    minutes: 'Meeting commenced at 2:15 PM with prayer led by Beatrice. 16 of 18 members attended. Treasurer reported total collected savings of KSh 52,500. One member loan in slight arrears was discussed and grace period extended to October 25th. Poll on grain storage investment concluded with 88% approval.',
    isMinutesPublished: true,
    attendance: [
      { memberId: 'mem_001', memberName: 'Grace Wanjiku', status: 'present' },
      { memberId: 'mem_002', memberName: 'Mary Akinyi', status: 'present' },
      { memberId: 'mem_003', memberName: 'Beatrice Wambui', status: 'present' },
      { memberId: 'mem_004', memberName: 'Faith Chebet', status: 'present' },
      { memberId: 'mem_005', memberName: 'Peter Omondi', status: 'present' },
      { memberId: 'mem_006', memberName: 'David Cheruiyot', status: 'present' },
      { memberId: 'mem_007', memberName: 'Esther Moraa', status: 'apology' },
      { memberId: 'mem_008', memberName: 'Samuel Mwangi', status: 'present' },
    ],
    actionItems: [
      { id: 'act_1', task: 'Follow up with Equity bank for updated quarterly paper statement', assignedTo: 'Mary Akinyi', dueDate: '2026-10-25', completed: true },
      { id: 'act_2', task: 'Obtain draft sales agreement for grain storage investment', assignedTo: 'Grace Wanjiku', dueDate: '2026-11-01', completed: false },
      { id: 'act_3', task: 'Send WhatsApp reminder for November 7th Table Banking session', assignedTo: 'Beatrice Wambui', dueDate: '2026-11-03', completed: false },
    ],
    polls: [
      {
        id: 'poll_1',
        question: 'Should we allocate KSh 120,000 from retained earnings towards the Nakuru County Maize Aggregation Warehouse scheme?',
        options: [
          { id: 'opt_1', text: 'Yes, invest for guaranteed 14% dividend', voteCount: 14 },
          { id: 'opt_2', text: 'No, retain funds in KCB Fixed Deposit', voteCount: 2 },
          { id: 'opt_3', text: 'Need more financial documentation first', voteCount: 1 },
        ],
        votedUserIds: ['usr_001', 'usr_002', 'usr_003', 'usr_004', 'usr_005'],
        isActive: true,
      }
    ],
    createdAt: '2026-09-20T10:00:00Z',
  },
  {
    id: 'mtg_002',
    chamaId: 'chama_tumaini',
    title: 'November Table Banking Session & End-of-Year Merry-Go-Round Payout',
    date: '2026-11-07',
    startTime: '14:00',
    endTime: '16:00',
    venue: 'St. Paul Community Hall, Nakuru West',
    isVirtual: false,
    agenda: [
      { id: 'ag_21', title: 'Monthly Contribution & Savings Collection', durationMinutes: 40, presenter: 'Mary Akinyi' },
      { id: 'ag_22', title: 'Merry-Go-Round Draw & Disbursement to Payout Winner', durationMinutes: 20, presenter: 'Grace Wanjiku' },
      { id: 'ag_23', title: 'New Loan Applications Review', durationMinutes: 40, presenter: 'Loan Committee' },
    ],
    minutes: 'Draft in progress...',
    isMinutesPublished: false,
    attendance: [],
    actionItems: [],
    polls: [],
    createdAt: '2026-10-15T11:00:00Z',
  },
  {
    id: 'mtg_h01',
    chamaId: 'chama_hustlers',
    title: 'Q4 Commercial Real Estate & Treasury Bills Syndicate Strategy',
    date: '2026-11-15',
    startTime: '16:00',
    endTime: '18:00',
    venue: 'Villa Rosa Kempinski Boardroom & Zoom (Hybrid)',
    isVirtual: true,
    virtualLink: 'https://zoom.us/j/8492018821',
    agenda: [
      { id: 'h_ag1', title: 'Macroeconomic & CBK Treasury Bill Rates Review (15.2%)', durationMinutes: 30, presenter: 'Peter Omondi' },
      { id: 'h_ag2', title: 'Westlands Commercial Office Suite Due Diligence Report', durationMinutes: 45, presenter: 'Grace Wanjiku' },
      { id: 'h_ag3', title: 'Member Equity Contributions Rebalancing', durationMinutes: 30, presenter: 'Faith Chebet' },
    ],
    minutes: 'Draft scheduled for November 15th.',
    isMinutesPublished: false,
    attendance: [
      { memberId: 'mem_h01', memberName: 'Peter Omondi', status: 'present' },
      { memberId: 'mem_h02', memberName: 'Grace Wanjiku', status: 'present' },
      { memberId: 'mem_h03', memberName: 'Faith Chebet', status: 'present' },
    ],
    actionItems: [],
    polls: [
      {
        id: 'poll_h1',
        question: 'Should we reinvest KSh 500,000 from maturing 91-day T-Bills into the 182-day paper at 15.4%?',
        options: [
          { id: 'opt_h1', text: 'Yes, lock 182-day rate', voteCount: 8 },
          { id: 'opt_h2', text: 'No, hold in NCBA Money Market Fund for liquidity', voteCount: 3 },
        ],
        votedUserIds: ['usr_005'],
        isActive: true,
      }
    ],
    createdAt: '2026-10-10T14:00:00Z',
  },
  {
    id: 'mtg_u01',
    chamaId: 'chama_ushirikiano',
    title: 'Ushirikiano Monthly Benevolence & Healthcare Relief Session',
    date: '2026-10-26',
    startTime: '15:00',
    endTime: '17:00',
    venue: 'Karatina ACK Social Hall',
    isVirtual: false,
    agenda: [
      { id: 'u_ag1', title: 'Opening Devotion & Chairperson Welcome', durationMinutes: 15, presenter: 'Beatrice Wambui' },
      { id: 'u_ag2', title: 'Emergency Hospitalization Payout Audit', durationMinutes: 35, presenter: 'David Cheruiyot' },
      { id: 'u_ag3', title: 'Member Welfare Kitty Replenishment Collections', durationMinutes: 40, presenter: 'Grace Wanjiku' },
    ],
    minutes: 'All 32 members accounted for. Benevolence kitty holds sufficient reserves for upcoming term fees assistance.',
    isMinutesPublished: true,
    attendance: [
      { memberId: 'mem_u01', memberName: 'Beatrice Wambui', status: 'present' },
      { memberId: 'mem_u02', memberName: 'David Cheruiyot', status: 'present' },
      { memberId: 'mem_u03', memberName: 'Grace Wanjiku', status: 'present' },
    ],
    actionItems: [],
    polls: [],
    createdAt: '2026-10-01T09:00:00Z',
  }
];

const SEED_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_001',
    userId: 'usr_001',
    title: 'M-Pesa Contribution Confirmed',
    message: 'KSh 3,000 received from Grace Wanjiku (Ref: SIK891KLD3). Reconciled with savings ledger.',
    type: 'mpesa_received',
    timestamp: '2026-10-04T11:21:00Z',
    isRead: false,
  },
  {
    id: 'notif_002',
    userId: 'usr_001',
    title: 'Loan Approval Required (Dual Sign-off)',
    message: 'Faith Chebet submitted a school fee loan of KSh 20,000. Your signature as Chairperson is approved, awaiting Treasurer.',
    type: 'loan_update',
    timestamp: '2026-10-20T08:31:00Z',
    isRead: false,
  },
  {
    id: 'notif_003',
    userId: 'usr_001',
    title: 'Upcoming Chama Meeting',
    message: 'November Table Banking Session scheduled for Saturday Nov 7th, 2026 at 2:00 PM.',
    type: 'meeting_alert',
    timestamp: '2026-10-15T11:05:00Z',
    isRead: true,
  }
];

const SEED_ADMOB_CONFIG: AdMobConfig = {
  enabled: true,
  testMode: true,
  bannerEnabled: true,
  interstitialEnabled: true,
  rewardedEnabled: true,
  nativeEnabled: true,
  bannerPlacements: {
    dashboardBottom: true,
    recordsBottom: true,
    reportsBottom: true,
    meetingsBottom: true,
  },
  interstitialFrequencyMins: 15,
  lastInterstitialShownAt: 0,
  testAdUnitIds: {
    // Official Google AdMob sample test unit IDs
    banner: 'ca-app-pub-3940256099942544/6300978111',
    interstitial: 'ca-app-pub-3940256099942544/1033173712',
    rewarded: 'ca-app-pub-3940256099942544/5224354917',
    native: 'ca-app-pub-3940256099942544/2247696110',
  },
  totalImpressions: 142,
  estimatedRevenueKes: 248.50,
};

const SEED_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'aud_1',
    chamaId: 'chama_tumaini',
    userId: 'usr_001',
    userName: 'Grace Wanjiku',
    action: 'APPROVED_LOAN',
    details: 'Approved 1st level sign-off for Faith Chebet loan KSh 20,000',
    timestamp: '2026-10-20T08:30:00Z',
  },
  {
    id: 'aud_2',
    chamaId: 'chama_tumaini',
    userId: 'usr_002',
    userName: 'Mary Akinyi',
    action: 'RECORD_CONTRIBUTION',
    details: 'Reconciled manual contribution KSh 3,000 for Beatrice Wambui (Ref: SIK711MM99)',
    timestamp: '2026-10-05T09:40:00Z',
  },
  {
    id: 'aud_3',
    chamaId: 'chama_tumaini',
    userId: 'usr_001',
    userName: 'Grace Wanjiku',
    action: 'RECORD_EXPENSE',
    details: 'Logged meeting venue and catering expense KSh 3,200',
    timestamp: '2026-10-06T17:00:00Z',
  }
];

class StorageService {
  private get<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      if (!item) return defaultValue;
      return JSON.parse(item) as T;
    } catch {
      return defaultValue;
    }
  }

  private set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn('LocalStorage write failed:', e);
    }
  }

  // --- Auth & User ---
  getCurrentUser(): User {
    return this.get<User>(STORAGE_KEYS.CURRENT_USER, SEED_CURRENT_USER);
  }

  setCurrentUser(user: User): void {
    this.set(STORAGE_KEYS.CURRENT_USER, user);
  }

  switchRole(role: UserRole): User {
    const user = this.getCurrentUser();
    user.id = user.id || 'usr_001';
    this.setCurrentUser(user);

    // Also update current member role in active chama
    const activeChamaId = this.getActiveChamaId();
    const members = this.getMembers(activeChamaId);
    const memberIndex = members.findIndex(m => m.userId === user.id);
    if (memberIndex >= 0) {
      members[memberIndex].role = role;
      this.saveMembers(activeChamaId, members);
    }

    return user;
  }

  // --- Chamas ---
  getChamas(): Chama[] {
    return this.get<Chama[]>(STORAGE_KEYS.CHAMAS, SEED_CHAMAS);
  }

  getActiveChamaId(): string {
    const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_CHAMA_ID);
    if (saved) return saved;
    const currentUser = this.getCurrentUser();
    return currentUser.currentChamaId || 'chama_tumaini';
  }

  setActiveChamaId(chamaId: string): void {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_CHAMA_ID, chamaId);
    const user = this.getCurrentUser();
    user.currentChamaId = chamaId;
    this.setCurrentUser(user);
  }

  getActiveChama(): Chama {
    const id = this.getActiveChamaId();
    const chamas = this.getChamas();
    return chamas.find(c => c.id === id) || chamas[0] || SEED_CHAMAS[0];
  }

  saveChamas(chamas: Chama[]): void {
    this.set(STORAGE_KEYS.CHAMAS, chamas);
  }

  createChama(newChama: Omit<Chama, 'id' | 'createdAt'>): Chama {
    const chamas = this.getChamas();
    const id = `chama_${Date.now()}`;
    const chama: Chama = {
      ...newChama,
      id,
      createdAt: new Date().toISOString(),
    };
    chamas.push(chama);
    this.saveChamas(chamas);
    this.setActiveChamaId(id);

    // Create current user as chairperson member
    const user = this.getCurrentUser();
    const newMember: Member = {
      id: `mem_${Date.now()}`,
      chamaId: id,
      userId: user.id,
      memberNumber: `CSK-001`,
      fullName: user.fullName,
      phone: user.phone,
      role: 'chairperson',
      status: 'active',
      joinedDate: new Date().toISOString().split('T')[0],
      totalSavings: 0,
      totalWelfare: 0,
      activeLoanCount: 0,
      outstandingLoanBalance: 0,
      attendanceRate: 100,
      email: user.email,
    };
    const allMembers = this.getAllMembers();
    allMembers.push(newMember);
    this.set(STORAGE_KEYS.MEMBERS, allMembers);

    this.logAudit(id, user.id, user.fullName, 'CREATE_CHAMA', `Created new chama: ${chama.name} (${chama.groupType})`);
    return chama;
  }

  // --- Members ---
  getAllMembers(): Member[] {
    return this.get<Member[]>(STORAGE_KEYS.MEMBERS, SEED_MEMBERS);
  }

  getMembers(chamaId: string): Member[] {
    return this.getAllMembers().filter(m => m.chamaId === chamaId);
  }

  saveMembers(chamaId: string, updatedMembers: Member[]): void {
    const all = this.getAllMembers();
    const others = all.filter(m => m.chamaId !== chamaId);
    this.set(STORAGE_KEYS.MEMBERS, [...others, ...updatedMembers]);
  }

  addMember(chamaId: string, memberData: Partial<Member>): Member {
    const existing = this.getMembers(chamaId);
    const newMember: Member = {
      id: `mem_${Date.now()}`,
      chamaId,
      userId: `usr_${Date.now()}`,
      memberNumber: `CSK-${String(existing.length + 1).padStart(3, '0')}`,
      fullName: memberData.fullName || 'New Member',
      phone: memberData.phone || '+254700000000',
      role: memberData.role || 'member',
      status: 'active',
      joinedDate: new Date().toISOString().split('T')[0],
      totalSavings: 0,
      totalWelfare: 0,
      activeLoanCount: 0,
      outstandingLoanBalance: 0,
      attendanceRate: 100,
      email: memberData.email,
    };
    existing.push(newMember);
    this.saveMembers(chamaId, existing);
    return newMember;
  }

  // --- Contributions ---
  getAllContributions(): Contribution[] {
    return this.get<Contribution[]>(STORAGE_KEYS.CONTRIBUTIONS, SEED_CONTRIBUTIONS);
  }

  getContributions(chamaId: string): Contribution[] {
    return this.getAllContributions().filter(c => c.chamaId === chamaId);
  }

  recordContribution(chamaId: string, contributionData: Omit<Contribution, 'id' | 'createdAt' | 'receiptNumber'>): Contribution {
    const contributions = this.getAllContributions();
    const receiptNumber = generateReceiptNumber('RC');
    const newContribution: Contribution = {
      ...contributionData,
      id: `cnt_${Date.now()}`,
      receiptNumber,
      createdAt: new Date().toISOString(),
    };

    contributions.unshift(newContribution);
    this.set(STORAGE_KEYS.CONTRIBUTIONS, contributions);

    // If confirmed, update member savings & ledger automatically
    if (newContribution.status === 'confirmed') {
      this.updateMemberSavings(chamaId, newContribution.memberId, newContribution.amount, newContribution.type);
      this.createLedgerEntry(chamaId, {
        reference: `LED-${newContribution.receiptNumber}`,
        debitAccount: newContribution.paymentMethod.startsWith('mpesa') ? 'mpesa_float' : (newContribution.paymentMethod === 'bank_transfer' ? 'bank_account' : 'cash_in_hand'),
        creditAccount: newContribution.type === 'welfare' ? 'welfare_reserve' : 'member_savings',
        amount: newContribution.amount,
        narration: `Contribution (${newContribution.type}) by ${newContribution.memberName} - Ref: ${newContribution.paymentReference}`,
        recordedBy: newContribution.verifiedBy || 'System',
      });
    }

    return newContribution;
  }

  private updateMemberSavings(chamaId: string, memberId: string, amount: number, type: string) {
    const members = this.getMembers(chamaId);
    const member = members.find(m => m.id === memberId);
    if (member) {
      if (type === 'welfare') {
        member.totalWelfare = (member.totalWelfare || 0) + amount;
      } else {
        member.totalSavings = (member.totalSavings || 0) + amount;
      }
      this.saveMembers(chamaId, members);
    }
  }

  reconcileContribution(chamaId: string, contributionId: string, verifiedBy: string): void {
    const contributions = this.getAllContributions();
    const item = contributions.find(c => c.id === contributionId);
    if (item && item.status !== 'confirmed') {
      item.status = 'confirmed';
      item.isMpesaVerified = true;
      item.verifiedBy = verifiedBy;
      this.set(STORAGE_KEYS.CONTRIBUTIONS, contributions);
      this.updateMemberSavings(chamaId, item.memberId, item.amount, item.type);
    }
  }

  // --- Loans ---
  getAllLoans(): Loan[] {
    return this.get<Loan[]>(STORAGE_KEYS.LOANS, SEED_LOANS);
  }

  getLoans(chamaId: string): Loan[] {
    return this.getAllLoans().filter(l => l.chamaId === chamaId);
  }

  applyForLoan(chamaId: string, loanData: Omit<Loan, 'id' | 'applicationDate' | 'approvalStatus' | 'amountPaid' | 'balanceRemaining'>): Loan {
    const loans = this.getAllLoans();
    const newLoan: Loan = {
      ...loanData,
      id: `loan_${Date.now()}`,
      applicationDate: new Date().toISOString().split('T')[0],
      approvalStatus: 'pending',
      amountPaid: 0,
      balanceRemaining: loanData.totalPayable,
    };
    loans.unshift(newLoan);
    this.set(STORAGE_KEYS.LOANS, loans);
    return newLoan;
  }

  approveLoan(loanId: string, role: 'chairperson' | 'treasurer', officerName: string): Loan | null {
    const loans = this.getAllLoans();
    const loan = loans.find(l => l.id === loanId);
    if (!loan) return null;

    if (role === 'chairperson') {
      loan.chairApprovedBy = officerName;
      loan.chairApprovedAt = new Date().toISOString();
      if (loan.treasurerApprovedBy) {
        loan.approvalStatus = 'fully_approved';
      } else {
        loan.approvalStatus = 'chair_approved';
      }
    } else if (role === 'treasurer') {
      loan.treasurerApprovedBy = officerName;
      loan.treasurerApprovedAt = new Date().toISOString();
      if (loan.chairApprovedBy) {
        loan.approvalStatus = 'fully_approved';
      }
    }
    this.set(STORAGE_KEYS.LOANS, loans);
    return loan;
  }

  disburseLoan(loanId: string, officerName: string, method: 'mpesa' | 'bank' | 'cash'): Loan | null {
    const loans = this.getAllLoans();
    const loan = loans.find(l => l.id === loanId);
    if (!loan) return null;

    loan.approvalStatus = 'disbursed';
    loan.disbursedAt = new Date().toISOString();
    loan.disbursementMethod = method;

    // Update active loan on member profile
    const members = this.getMembers(loan.chamaId);
    const member = members.find(m => m.id === loan.memberId);
    if (member) {
      member.activeLoanCount = (member.activeLoanCount || 0) + 1;
      member.outstandingLoanBalance = (member.outstandingLoanBalance || 0) + loan.totalPayable;
      this.saveMembers(loan.chamaId, members);
    }

    // Ledger entry for loan disbursement
    this.createLedgerEntry(loan.chamaId, {
      reference: `LOAN-DISB-${loan.id.slice(-6)}`,
      debitAccount: 'loans_receivable',
      creditAccount: method === 'mpesa' ? 'mpesa_float' : (method === 'bank' ? 'bank_account' : 'cash_in_hand'),
      amount: loan.approvedAmount,
      narration: `Loan disbursed to ${loan.memberName} (${loan.purpose})`,
      recordedBy: officerName,
    });

    this.set(STORAGE_KEYS.LOANS, loans);
    return loan;
  }

  recordLoanRepayment(repayment: Omit<LoanRepayment, 'id' | 'receiptNumber' | 'paidAt'>): LoanRepayment {
    const repayments = this.get<LoanRepayment[]>(STORAGE_KEYS.REPAYMENTS, []);
    const receiptNumber = generateReceiptNumber('LRP');
    const newRepayment: LoanRepayment = {
      ...repayment,
      id: `lrp_${Date.now()}`,
      receiptNumber,
      paidAt: new Date().toISOString(),
    };
    repayments.unshift(newRepayment);
    this.set(STORAGE_KEYS.REPAYMENTS, repayments);

    // Update loan balance
    const loans = this.getAllLoans();
    const loan = loans.find(l => l.id === repayment.loanId);
    if (loan) {
      loan.amountPaid = (loan.amountPaid || 0) + repayment.amount;
      loan.balanceRemaining = Math.max(0, loan.totalPayable - loan.amountPaid);
      if (loan.balanceRemaining === 0) {
        loan.approvalStatus = 'settled';
      }

      // Mark paid/overdue schedule installments as paid
      if (loan.schedule && loan.schedule.length > 0) {
        let remainingRepay = repayment.amount;
        for (const item of loan.schedule) {
          if (item.status === 'overdue' || item.status === 'pending') {
            if (remainingRepay >= item.totalDue * 0.9) {
              item.status = 'paid';
              item.paidAt = new Date().toISOString().split('T')[0];
              remainingRepay -= item.totalDue;
            }
          }
        }
        const hasRemainingOverdue = loan.schedule.some((s) => s.status === 'overdue');
        if (!hasRemainingOverdue) {
          loan.lateFeeAccrued = 0;
        }
      }

      this.set(STORAGE_KEYS.LOANS, loans);

      // Update member debt
      const members = this.getMembers(loan.chamaId);
      const member = members.find(m => m.id === loan.memberId);
      if (member) {
        member.outstandingLoanBalance = Math.max(0, (member.outstandingLoanBalance || 0) - repayment.amount);
        if (loan.balanceRemaining === 0) {
          member.activeLoanCount = Math.max(0, (member.activeLoanCount || 1) - 1);
        }
        this.saveMembers(loan.chamaId, members);
      }

      // Record double entry in ledger
      this.createLedgerEntry(loan.chamaId, {
        reference: `LED-${receiptNumber}`,
        debitAccount: repayment.paymentMethod === 'mpesa' ? 'mpesa_float' : (repayment.paymentMethod === 'bank' ? 'bank_account' : 'cash_in_hand'),
        creditAccount: 'loans_receivable',
        amount: repayment.amount,
        narration: `Loan repayment by ${loan.memberName} (Ref: ${repayment.paymentReference})`,
        recordedBy: repayment.recordedBy,
      });
    }

    return newRepayment;
  }

  // --- Expenses ---
  getAllExpenses(): Expense[] {
    return this.get<Expense[]>(STORAGE_KEYS.EXPENSES, SEED_EXPENSES);
  }

  getExpenses(chamaId: string): Expense[] {
    return this.getAllExpenses().filter(e => e.chamaId === chamaId);
  }

  recordExpense(expenseData: Omit<Expense, 'id' | 'createdAt'>): Expense {
    const expenses = this.getAllExpenses();
    const newExpense: Expense = {
      ...expenseData,
      id: `exp_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    expenses.unshift(newExpense);
    this.set(STORAGE_KEYS.EXPENSES, expenses);

    if (newExpense.status === 'approved') {
      this.createLedgerEntry(newExpense.chamaId, {
        reference: `LED-EXP-${newExpense.id.slice(-6)}`,
        debitAccount: 'expenses',
        creditAccount: newExpense.paidFromAccount === 'cash' ? 'cash_in_hand' : (newExpense.paidFromAccount === 'bank' ? 'bank_account' : 'mpesa_float'),
        amount: newExpense.amount,
        narration: `Expense: ${newExpense.title} (${newExpense.paidTo})`,
        recordedBy: newExpense.approvedBy || 'Treasurer',
      });
    }

    return newExpense;
  }

  // --- Ledger ---
  getLedger(chamaId: string): LedgerEntry[] {
    const all = this.get<LedgerEntry[]>(STORAGE_KEYS.LEDGER, SEED_LEDGER_ENTRIES);
    return all.filter(l => l.chamaId === chamaId);
  }

  createLedgerEntry(chamaId: string, entry: Omit<LedgerEntry, 'id' | 'chamaId' | 'timestamp' | 'auditHash'>): LedgerEntry {
    const all = this.get<LedgerEntry[]>(STORAGE_KEYS.LEDGER, SEED_LEDGER_ENTRIES);
    const newEntry: LedgerEntry = {
      ...entry,
      id: `led_${Date.now()}`,
      chamaId,
      timestamp: new Date().toISOString(),
      auditHash: Math.random().toString(36).substring(2, 15),
    };
    all.unshift(newEntry);
    this.set(STORAGE_KEYS.LEDGER, all);
    return newEntry;
  }

  // --- Meetings ---
  getMeetings(chamaId: string): Meeting[] {
    const all = this.get<Meeting[]>(STORAGE_KEYS.MEETINGS, SEED_MEETINGS);
    return all.filter(m => m.chamaId === chamaId);
  }

  saveMeetings(chamaId: string, updated: Meeting[]): void {
    const all = this.get<Meeting[]>(STORAGE_KEYS.MEETINGS, SEED_MEETINGS);
    const others = all.filter(m => m.chamaId !== chamaId);
    this.set(STORAGE_KEYS.MEETINGS, [...others, ...updated]);
  }

  createMeeting(meeting: Omit<Meeting, 'id' | 'createdAt'>): Meeting {
    const meetings = this.getMeetings(meeting.chamaId);
    const newMeeting: Meeting = {
      ...meeting,
      id: `mtg_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    meetings.unshift(newMeeting);
    this.saveMeetings(meeting.chamaId, meetings);
    return newMeeting;
  }

  voteOnPoll(chamaId: string, meetingId: string, pollId: string, optionId: string, userId: string): void {
    const meetings = this.getMeetings(chamaId);
    const meeting = meetings.find(m => m.id === meetingId);
    if (!meeting) return;
    const poll = meeting.polls.find(p => p.id === pollId);
    if (!poll || poll.votedUserIds.includes(userId)) return;

    const opt = poll.options.find(o => o.id === optionId);
    if (opt) {
      opt.voteCount += 1;
      poll.votedUserIds.push(userId);
      this.saveMeetings(chamaId, meetings);
    }
  }

  // --- Notifications ---
  getNotifications(): NotificationItem[] {
    return this.get<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, SEED_NOTIFICATIONS);
  }

  markNotificationRead(id: string): void {
    const items = this.getNotifications();
    const item = items.find(n => n.id === id);
    if (item) {
      item.isRead = true;
      this.set(STORAGE_KEYS.NOTIFICATIONS, items);
    }
  }

  // --- AdMob Config ---
  getAdMobConfig(): AdMobConfig {
    return this.get<AdMobConfig>(STORAGE_KEYS.ADMOB, SEED_ADMOB_CONFIG);
  }

  saveAdMobConfig(config: AdMobConfig): void {
    this.set(STORAGE_KEYS.ADMOB, config);
  }

  recordAdImpression(format: 'banner' | 'interstitial' | 'rewarded' | 'native'): void {
    const config = this.getAdMobConfig();
    config.totalImpressions += 1;
    // Estimated CPM in Kenya ~ $0.50 - $1.20 per 1000 = ~ KSh 0.10 - 0.25 per impression
    config.estimatedRevenueKes += 0.18;
    this.saveAdMobConfig(config);
  }

  // --- Audit Logs ---
  getAuditLogs(chamaId: string): AuditLog[] {
    const all = this.get<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, SEED_AUDIT_LOGS);
    return all.filter(a => a.chamaId === chamaId);
  }

  logAudit(chamaId: string, userId: string, userName: string, action: string, details: string): void {
    const all = this.get<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, SEED_AUDIT_LOGS);
    all.unshift({
      id: `aud_${Date.now()}`,
      chamaId,
      userId,
      userName,
      action,
      details,
      timestamp: new Date().toISOString(),
    });
    this.set(STORAGE_KEYS.AUDIT_LOGS, all.slice(0, 100)); // keep last 100
  }

  // --- Offline Simulation & Queue ---
  isOfflineSimulated(): boolean {
    return localStorage.getItem(STORAGE_KEYS.IS_OFFLINE_SIMULATED) === 'true';
  }

  setOfflineSimulated(val: boolean): void {
    localStorage.setItem(STORAGE_KEYS.IS_OFFLINE_SIMULATED, String(val));
  }

  getOfflineQueue(): OfflineQueueItem[] {
    return this.get<OfflineQueueItem[]>(STORAGE_KEYS.OFFLINE_QUEUE, []);
  }

  enqueueOfflineAction(actionType: OfflineQueueItem['actionType'], payload: any): void {
    const queue = this.getOfflineQueue();
    queue.push({
      id: `queue_${Date.now()}`,
      actionType,
      payload,
      queuedAt: new Date().toISOString(),
      status: 'pending',
    });
    this.set(STORAGE_KEYS.OFFLINE_QUEUE, queue);
  }

  flushOfflineQueue(): number {
    const queue = this.getOfflineQueue();
    const count = queue.length;
    // Process queue items into normal storage
    queue.forEach(item => {
      if (item.actionType === 'create_contribution') {
        this.recordContribution(item.payload.chamaId, item.payload);
      } else if (item.actionType === 'record_expense') {
        this.recordExpense(item.payload);
      }
    });
    this.set(STORAGE_KEYS.OFFLINE_QUEUE, []);
    return count;
  }

  // --- Device View Mode (Android frame vs Responsive web) ---
  getDeviceViewMode(): 'android_frame' | 'responsive' {
    return (localStorage.getItem(STORAGE_KEYS.DEVICE_VIEW_MODE) as any) || 'android_frame';
  }

  setDeviceViewMode(mode: 'android_frame' | 'responsive'): void {
    localStorage.setItem(STORAGE_KEYS.DEVICE_VIEW_MODE, mode);
  }

  // Reset demo data to factory defaults
  resetAllData(): void {
    localStorage.clear();
  }
}

export const storage = new StorageService();
