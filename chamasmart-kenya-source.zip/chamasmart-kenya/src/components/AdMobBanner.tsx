import React, { useEffect, useState } from 'react';
import { storage } from '../services/storageService';
import { ExternalLink, Info, ShieldCheck } from 'lucide-react';

interface AdMobBannerProps {
  placement: 'dashboardBottom' | 'reportsBottom' | 'meetingsBottom' | 'recordsBottom';
}

export const AdMobBanner: React.FC<AdMobBannerProps> = ({ placement }) => {
  const [config, setConfig] = useState(storage.getAdMobConfig());
  const activeChama = storage.getActiveChama();

  useEffect(() => {
    // If enabled and placement matches, record impression
    if (config.enabled && config.bannerEnabled && config.bannerPlacements[placement] && !activeChama.isPremium) {
      storage.recordAdImpression('banner');
    }
  }, [config.enabled, config.bannerEnabled, placement, activeChama.isPremium]);

  if (!config.enabled || !config.bannerEnabled || !config.bannerPlacements[placement] || activeChama.isPremium) {
    return null;
  }

  return (
    <div className="my-3 px-3">
      <div className="bg-slate-900 border border-slate-700/80 rounded-xl p-3 shadow-md relative overflow-hidden text-slate-100">
        <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 text-[10px] text-slate-400">
          <div className="flex items-center gap-1.5 font-mono">
            <span className="bg-amber-500/20 text-amber-300 font-semibold px-1.5 py-0.5 rounded text-[9px]">
              AdMob Test Ad
            </span>
            <span className="truncate max-w-[170px] text-slate-400">{config.testAdUnitIds.banner}</span>
          </div>
          <div className="flex items-center gap-1 text-slate-400 hover:text-slate-200 cursor-pointer">
            <ShieldCheck size={12} className="text-emerald-400" />
            <span>AdChoices</span>
          </div>
        </div>

        <div className="pt-2 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white font-bold text-xs shadow-inner flex-shrink-0">
              KCB
            </div>
            <div>
              <p className="text-xs font-semibold text-white leading-tight">
                KCB Biashara Chama Account
              </p>
              <p className="text-[11px] text-slate-400 leading-snug">
                Earn up to 9.5% p.a. on group fixed deposits with zero ledger fees.
              </p>
            </div>
          </div>
          <a
            href="https://ke.kcbgroup.com"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => storage.recordAdImpression('banner')}
            className="flex-shrink-0 bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-medium py-1.5 px-3 rounded-lg flex items-center gap-1 transition-all active:scale-95"
          >
            <span>Learn</span>
            <ExternalLink size={11} />
          </a>
        </div>
      </div>
    </div>
  );
};
