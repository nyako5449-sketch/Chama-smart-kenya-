import React, { useState } from 'react';
import { 
  X, Smartphone, ArrowRight, CheckCircle2, AlertCircle, 
  Clock, Shield, FileText, Sparkles, RefreshCw 
} from 'lucide-react';
import { storage } from '../services/storageService';
import { DarajaService, StkPushResponse } from '../services/darajaSimulator';
import { formatKES, isValidKenyanPhone, normalizeKenyanPhone, parseSafaricomSms } from '../services/calculations';
import { Contribution, Member } from '../types';

interface MpesaStkModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: (contribution: Contribution) => void;
  defaultMember?: Member;
  defaultAmount?: number;
  contributionType?: 'savings' | 'welfare' | 'special_project';
}

export const MpesaStkModal: React.FC<MpesaStkModalProps> = ({
  isOpen,
  onClose,
  onPaymentSuccess,
  defaultMember,
  defaultAmount,
  contributionType = 'savings',
}) => {
  const activeChama = storage.getActiveChama();
  const members = storage.getMembers(activeChama.id);
  const currentUser = storage.getCurrentUser();

  const [activeTab, setActiveTab] = useState<'stk_push' | 'manual_sms'>('stk_push');

  // Form State
  const [selectedMemberId, setSelectedMemberId] = useState(
    defaultMember?.id || members[0]?.id || ''
  );
  const [phone, setPhone] = useState(
    defaultMember?.phone || currentUser.phone || '0712345678'
  );
  const [amount, setAmount] = useState<number>(
    defaultAmount || activeChama.minContribution || 2500
  );
  const [type, setType] = useState<'savings' | 'welfare' | 'special_project'>(
    contributionType
  );
  const [notes, setNotes] = useState('');

  // STK State machine: idle -> pushing -> awaiting_pin -> verifying -> success | error
  const [stkState, setStkState] = useState<'idle' | 'pushing' | 'awaiting_pin' | 'verifying' | 'success' | 'error'>('idle');
  const [stkResponse, setStkResponse] = useState<StkPushResponse | null>(null);
  const [ussdPin, setUssdPin] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [confirmedContribution, setConfirmedContribution] = useState<Contribution | null>(null);

  // Manual SMS Reconciliation State
  const [smsRawText, setSmsRawText] = useState('');
  const [manualRef, setManualRef] = useState('');
  const [manualAmount, setManualAmount] = useState(amount);
  const [manualMethod, setManualMethod] = useState<'mpesa_manual' | 'bank_transfer' | 'cash'>('mpesa_manual');

  React.useEffect(() => {
    if (isOpen) {
      setStkState('idle');
      setUssdPin('');
      setErrorMessage('');
      setStkResponse(null);
      setConfirmedContribution(null);
      if (defaultMember) {
        setSelectedMemberId(defaultMember.id);
        setPhone(defaultMember.phone);
      } else if (members[0]) {
        setSelectedMemberId(members[0].id);
        setPhone(members[0].phone);
      }
      if (defaultAmount) {
        setAmount(defaultAmount);
      } else {
        setAmount(activeChama.minContribution || 2500);
      }
    }
  }, [isOpen, defaultMember, defaultAmount, activeChama.id]);

  if (!isOpen) return null;

  const selectedMember = members.find((m) => m.id === selectedMemberId) || members[0];

  const handleInitiateStk = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!isValidKenyanPhone(phone)) {
      setErrorMessage('Please enter a valid Kenyan phone number (e.g. 0712345678 or +254712345678)');
      return;
    }
    if (amount <= 0) {
      setErrorMessage('Amount must be greater than KSh 0');
      return;
    }

    try {
      setStkState('pushing');
      const formattedPhone = normalizeKenyanPhone(phone).replace('+', '');
      const resp = await DarajaService.initiateStkPush({
        phoneNumber: formattedPhone,
        amount,
        accountReference: selectedMember?.memberNumber || activeChama.name.slice(0, 12),
        transactionDesc: `${type.toUpperCase()} Contribution`,
      });

      setStkResponse(resp);
      setStkState('awaiting_pin');
    } catch (err: any) {
      setStkState('error');
      setErrorMessage(err.message || 'Failed to initiate STK push');
    }
  };

  const handleSimulatePinSubmission = async (approved: boolean) => {
    if (!stkResponse) return;
    setStkState('verifying');

    try {
      const result = await DarajaService.completeSimulatedPayment(
        stkResponse.checkoutRequestId,
        phone,
        amount,
        approved
      );

      if (result.resultCode === 0 && result.mpesaReceiptNumber) {
        const newContribution = storage.recordContribution(activeChama.id, {
          chamaId: activeChama.id,
          memberId: selectedMember.id,
          memberName: selectedMember.fullName,
          memberPhone: normalizeKenyanPhone(phone),
          amount,
          type,
          cycleMonth: new Date().toISOString().slice(0, 7),
          deadlineDate: new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0],
          paymentMethod: 'mpesa_daraja',
          paymentReference: result.mpesaReceiptNumber,
          status: 'confirmed',
          isMpesaVerified: true,
          verifiedBy: 'Safaricom Daraja API',
          notes: notes || `M-Pesa STK Push payment via ${phone}`,
        });

        setConfirmedContribution(newContribution);
        setStkState('success');
        onPaymentSuccess(newContribution);
      } else {
        setStkState('error');
        setErrorMessage(result.resultDesc || 'Payment cancelled by user');
      }
    } catch (err: any) {
      setStkState('error');
      setErrorMessage(err.message || 'Verification error');
    }
  };

  const handleParseSms = () => {
    const parsed = parseSafaricomSms(smsRawText);
    if (parsed) {
      if (parsed.reference) setManualRef(parsed.reference);
      if (parsed.amount) setManualAmount(parsed.amount);
      if (parsed.senderPhone) {
        setPhone(parsed.senderPhone);
        const match = members.find((m) => normalizeKenyanPhone(m.phone) === parsed.senderPhone);
        if (match) setSelectedMemberId(match.id);
      }
    }
  };

  const handleManualReconcile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualRef.trim()) {
      setErrorMessage('Transaction reference is required');
      return;
    }

    const newContribution = storage.recordContribution(activeChama.id, {
      chamaId: activeChama.id,
      memberId: selectedMember.id,
      memberName: selectedMember.fullName,
      memberPhone: normalizeKenyanPhone(phone),
      amount: manualAmount,
      type,
      cycleMonth: new Date().toISOString().slice(0, 7),
      deadlineDate: new Date().toISOString().split('T')[0],
      paymentMethod: manualMethod,
      paymentReference: manualRef.toUpperCase().trim(),
      status: 'confirmed',
      isMpesaVerified: manualMethod === 'mpesa_manual',
      verifiedBy: currentUser.fullName,
      notes: notes || `Reconciled manually by ${currentUser.fullName}`,
    });

    setConfirmedContribution(newContribution);
    setStkState('success');
    onPaymentSuccess(newContribution);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-emerald-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 border border-emerald-700 flex items-center justify-center text-emerald-200">
              <Smartphone size={18} />
            </div>
            <div>
              <h3 className="font-bold text-sm">M-Pesa & Payment Gateway</h3>
              <p className="text-[11px] text-emerald-300">
                {activeChama.name} · Paybill: {activeChama.mpesaPaybill || '408221'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-emerald-300 hover:text-white p-1 rounded-lg"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Switcher */}
        {stkState !== 'success' && stkState !== 'awaiting_pin' && (
          <div className="flex border-b border-slate-200 bg-slate-50 p-1">
            <button
              onClick={() => setActiveTab('stk_push')}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'stk_push'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              M-Pesa STK Push
            </button>
            <button
              onClick={() => setActiveTab('manual_sms')}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'manual_sms'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Manual SMS / Bank Slip
            </button>
          </div>
        )}

        <div className="p-4 overflow-y-auto flex-1 text-slate-800">
          {errorMessage && (
            <div className="mb-3 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle size={16} className="flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* SUCCESS STATE */}
          {stkState === 'success' && confirmedContribution && (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 size={40} />
              </div>
              <div>
                <h4 className="text-lg font-bold text-slate-900">
                  Payment Confirmed!
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Reconciled into group savings & double-entry ledger.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-left text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Receipt No:</span>
                  <span className="font-mono font-semibold text-slate-800">{confirmedContribution.receiptNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">M-Pesa Reference:</span>
                  <span className="font-mono font-bold text-emerald-700">{confirmedContribution.paymentReference}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Member:</span>
                  <span className="font-medium text-slate-800">{confirmedContribution.memberName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Amount Paid:</span>
                  <span className="font-bold text-slate-900">{formatKES(confirmedContribution.amount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Account Type:</span>
                  <span className="capitalize font-medium text-slate-800">{confirmedContribution.type}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={onClose}
                  className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-2.5 px-4 rounded-xl text-xs transition-all"
                >
                  Done
                </button>
              </div>
            </div>
          )}

          {/* SIMULATED USSD PROMPT OVERLAY */}
          {stkState === 'awaiting_pin' && (
            <div className="py-2 space-y-4">
              <div className="bg-emerald-950 text-white p-4 rounded-xl border border-emerald-800 text-center relative overflow-hidden shadow-lg">
                <div className="absolute top-2 left-2 text-[10px] font-mono text-emerald-400">
                  [SIM Toolkit USSD Prompt]
                </div>
                <p className="text-xs text-emerald-200 mt-3 leading-relaxed">
                  Do you want to pay <span className="font-bold text-white">{formatKES(amount)}</span> to <span className="font-bold text-white">{activeChama.name.toUpperCase()}</span> (Paybill {activeChama.mpesaPaybill || '408221'})?
                </p>
                <div className="mt-4 max-w-[200px] mx-auto">
                  <label className="block text-[11px] text-emerald-300 mb-1">
                    Enter M-Pesa PIN:
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    value={ussdPin}
                    onChange={(e) => setUssdPin(e.target.value)}
                    placeholder="••••"
                    className="w-full text-center tracking-widest text-lg font-mono py-1.5 px-3 rounded-lg bg-emerald-900 border border-emerald-600 text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                  />
                </div>
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => handleSimulatePinSubmission(false)}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 py-1.5 px-3 rounded-lg text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleSimulatePinSubmission(true)}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 py-1.5 px-3 rounded-lg text-xs font-bold"
                  >
                    Send (OK)
                  </button>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 text-center">
                This simulates the real phone popup sent by Safaricom Daraja STK Push to <span className="font-semibold text-slate-700">{phone}</span>.
              </p>
            </div>
          )}

          {stkState === 'pushing' && (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-full border-3 border-emerald-600 border-t-transparent animate-spin mx-auto" />
              <h4 className="text-sm font-semibold text-slate-900">
                Calling Safaricom Daraja Gateway...
              </h4>
              <p className="text-xs text-slate-500">
                Sending STK Push prompt to {phone}
              </p>
            </div>
          )}

          {stkState === 'verifying' && (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-full border-3 border-emerald-600 border-t-transparent animate-spin mx-auto" />
              <h4 className="text-sm font-semibold text-slate-900">
                Verifying Safaricom STK Callback...
              </h4>
              <p className="text-xs text-slate-500">
                Confirming encrypted transaction hash with Safaricom server
              </p>
            </div>
          )}

          {/* ACTIVE TAB 1: STK PUSH FORM */}
          {activeTab === 'stk_push' && stkState === 'idle' && (
            <form onSubmit={handleInitiateStk} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Contributing Member
                </label>
                <select
                  value={selectedMemberId}
                  onChange={(e) => {
                    setSelectedMemberId(e.target.value);
                    const m = members.find((x) => x.id === e.target.value);
                    if (m) setPhone(m.phone);
                  }}
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white focus:ring-2 focus:ring-emerald-600"
                >
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.fullName} ({m.memberNumber}) — {m.phone}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  M-Pesa Phone Number (Receives STK Prompt)
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0712345678 or +254..."
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-mono pl-3"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Amount (KES)
                  </label>
                  <input
                    type="number"
                    min="10"
                    step="50"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-semibold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value="savings">Monthly Savings</option>
                    <option value="welfare">Welfare Kitty</option>
                    <option value="special_project">Special Investment</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Payment Note (Optional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. October savings share"
                  className="w-full border border-slate-300 rounded-xl p-2 text-xs"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-emerald-700 hover:bg-emerald-800 active:scale-98 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm"
                >
                  <Smartphone size={16} />
                  <span>Send M-Pesa STK Push ({formatKES(amount)})</span>
                </button>
              </div>

              <div className="flex items-center gap-1.5 justify-center text-[10px] text-slate-400 pt-1">
                <Shield size={12} className="text-emerald-600" />
                <span>Protected by Safaricom Daraja 2.0 API Sandbox Gateway</span>
              </div>
            </form>
          )}

          {/* ACTIVE TAB 2: MANUAL SMS / BANK SLIP RECONCILIATION */}
          {activeTab === 'manual_sms' && stkState === 'idle' && (
            <form onSubmit={handleManualReconcile} className="space-y-3 text-xs">
              <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl">
                <div className="flex items-center justify-between text-amber-900 font-semibold mb-1">
                  <span>Paste Safaricom SMS for Auto-Extraction</span>
                  <Sparkles size={14} className="text-amber-600" />
                </div>
                <textarea
                  rows={2}
                  value={smsRawText}
                  onChange={(e) => setSmsRawText(e.target.value)}
                  placeholder="Paste Safaricom M-Pesa SMS here (e.g. SIK891KLD3 Confirmed. Ksh2,500.00 sent to...)"
                  className="w-full p-2 border border-amber-300 rounded-lg text-[11px] bg-white font-mono"
                />
                <button
                  type="button"
                  onClick={handleParseSms}
                  className="mt-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold py-1 px-3 rounded-md text-[11px] flex items-center gap-1"
                >
                  <RefreshCw size={11} />
                  <span>Auto Extract Reference & Amount</span>
                </button>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Member
                </label>
                <select
                  value={selectedMemberId}
                  onChange={(e) => setSelectedMemberId(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                >
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.fullName} ({m.memberNumber})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Channel
                  </label>
                  <select
                    value={manualMethod}
                    onChange={(e) => setManualMethod(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value="mpesa_manual">M-Pesa SMS Forward</option>
                    <option value="bank_transfer">Bank Deposit Slip</option>
                    <option value="cash">Cash in Meeting</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Amount (KES)
                  </label>
                  <input
                    type="number"
                    value={manualAmount}
                    onChange={(e) => setManualAmount(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-semibold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Transaction Reference / Slip Code
                </label>
                <input
                  type="text"
                  value={manualRef}
                  onChange={(e) => setManualRef(e.target.value)}
                  placeholder="e.g. SIK891KLD3 or KCB-DEP-9921"
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-mono uppercase"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 mt-2"
              >
                <FileText size={16} />
                <span>Reconcile & Issue Official Receipt</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
