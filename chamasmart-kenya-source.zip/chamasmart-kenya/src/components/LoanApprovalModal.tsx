import React, { useState } from 'react';
import { 
  X, CheckCircle, ShieldCheck, ArrowRight, UserCheck, 
  Send, AlertCircle, Banknote, Smartphone 
} from 'lucide-react';
import { Loan } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';

interface LoanApprovalModalProps {
  loan: Loan | null;
  isOpen: boolean;
  onClose: () => void;
  onLoanUpdated: (updatedLoan: Loan) => void;
}

export const LoanApprovalModal: React.FC<LoanApprovalModalProps> = ({
  loan,
  isOpen,
  onClose,
  onLoanUpdated,
}) => {
  if (!isOpen || !loan) return null;

  const currentUser = storage.getCurrentUser();
  const [disbursementMethod, setDisbursementMethod] = useState<'mpesa' | 'bank' | 'cash'>('mpesa');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');

  const handleApprove = (role: 'chairperson' | 'treasurer') => {
    setIsProcessing(true);
    setError('');
    try {
      const updated = storage.approveLoan(loan.id, role, currentUser.fullName);
      if (updated) {
        onLoanUpdated(updated);
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'Approval failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDisburse = () => {
    setIsProcessing(true);
    setError('');
    try {
      const updated = storage.disburseLoan(loan.id, currentUser.fullName, disbursementMethod);
      if (updated) {
        onLoanUpdated(updated);
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'Disbursement failed');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col max-h-[90vh] text-slate-800 animate-in fade-in duration-150">
        <div className="bg-emerald-950 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck size={20} className="text-amber-400" />
            <div>
              <h3 className="font-bold text-sm">Loan Approval & Disbursement</h3>
              <p className="text-[11px] text-emerald-300">Dual Sign-off Workflow</p>
            </div>
          </div>
          <button onClick={onClose} className="text-emerald-300 hover:text-white p-1">
            <X size={18} />
          </button>
        </div>

        <div className="p-4 space-y-4 text-xs overflow-y-auto">
          {error && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 flex items-center gap-2">
              <AlertCircle size={14} />
              <span>{error}</span>
            </div>
          )}

          {/* Loan details */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Applicant:</span>
              <span className="font-bold text-slate-900">{loan.memberName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Phone:</span>
              <span className="font-mono text-slate-700">{loan.memberPhone}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Requested Principal:</span>
              <span className="font-bold text-emerald-800 text-sm font-mono">{formatKES(loan.approvedAmount)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Interest Method:</span>
              <span className="capitalize font-medium text-slate-800">
                {loan.interestMethod.replace('_', ' ')} ({loan.interestRatePercent}%)
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Total Repayable:</span>
              <span className="font-bold text-slate-900 font-mono">{formatKES(loan.totalPayable)}</span>
            </div>
            <div className="text-[11px] text-slate-600 pt-1 border-t border-slate-200">
              <span className="font-semibold text-slate-700">Purpose: </span>
              {loan.purpose}
            </div>
          </div>

          {/* Guarantors */}
          <div className="border border-slate-200 rounded-xl p-3 space-y-2">
            <p className="font-semibold text-slate-700 text-xs">Pledged Guarantors</p>
            <div className="space-y-1.5">
              {loan.guarantors.map((g, i) => (
                <div key={i} className="flex justify-between text-[11px] bg-slate-50 p-2 rounded-lg">
                  <span className="font-medium text-slate-800">{g.memberName}</span>
                  <span className="font-mono text-emerald-700">{formatKES(g.amountGuaranteed)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Dual Approval Signatures */}
          <div className="space-y-2 pt-1">
            <p className="font-semibold text-slate-800">Approval Sign-off Status</p>
            
            {/* Chairperson Signature */}
            <div className="p-3 border rounded-xl flex items-center justify-between bg-slate-50">
              <div>
                <p className="font-semibold text-xs text-slate-900">1. Chairperson Approval</p>
                <p className="text-[11px] text-slate-500">
                  {loan.chairApprovedBy ? `Signed by ${loan.chairApprovedBy}` : 'Pending Chairperson review'}
                </p>
              </div>
              {loan.chairApprovedBy ? (
                <span className="text-emerald-600 font-semibold text-xs flex items-center gap-1">
                  <CheckCircle size={14} /> Signed
                </span>
              ) : (
                <button
                  onClick={() => handleApprove('chairperson')}
                  disabled={isProcessing}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-1.5 px-3 rounded-lg text-xs"
                >
                  Sign as Chair
                </button>
              )}
            </div>

            {/* Treasurer Signature */}
            <div className="p-3 border rounded-xl flex items-center justify-between bg-slate-50">
              <div>
                <p className="font-semibold text-xs text-slate-900">2. Treasurer Approval</p>
                <p className="text-[11px] text-slate-500">
                  {loan.treasurerApprovedBy ? `Signed by ${loan.treasurerApprovedBy}` : 'Pending Treasurer verification'}
                </p>
              </div>
              {loan.treasurerApprovedBy ? (
                <span className="text-emerald-600 font-semibold text-xs flex items-center gap-1">
                  <CheckCircle size={14} /> Signed
                </span>
              ) : (
                <button
                  onClick={() => handleApprove('treasurer')}
                  disabled={isProcessing}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-1.5 px-3 rounded-lg text-xs"
                >
                  Sign as Treasurer
                </button>
              )}
            </div>
          </div>

          {/* Disbursal Section (If fully approved or ready to disburse) */}
          {(loan.approvalStatus === 'fully_approved' || (loan.chairApprovedBy && loan.treasurerApprovedBy)) && (
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl space-y-3">
              <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs">
                <Send size={14} />
                <span>Ready for Disbursal to Member</span>
              </div>
              <div>
                <label className="block text-[11px] font-medium text-amber-900 mb-1">
                  Select Disbursement Channel
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setDisbursementMethod('mpesa')}
                    className={`py-2 px-1 text-center rounded-lg border text-[11px] font-semibold flex flex-col items-center gap-1 ${
                      disbursementMethod === 'mpesa'
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    <Smartphone size={14} />
                    <span>M-Pesa B2C</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDisbursementMethod('bank')}
                    className={`py-2 px-1 text-center rounded-lg border text-[11px] font-semibold flex flex-col items-center gap-1 ${
                      disbursementMethod === 'bank'
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    <Banknote size={14} />
                    <span>Bank EFT</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDisbursementMethod('cash')}
                    className={`py-2 px-1 text-center rounded-lg border text-[11px] font-semibold flex flex-col items-center gap-1 ${
                      disbursementMethod === 'cash'
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    <Banknote size={14} />
                    <span>Cash</span>
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={handleDisburse}
                disabled={isProcessing}
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm"
              >
                <Send size={14} />
                <span>Disburse {formatKES(loan.approvedAmount)} Now</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
