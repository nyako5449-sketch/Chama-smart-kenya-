import React from 'react';
import { X, Download, Share2, Printer, CheckCircle, ShieldCheck } from 'lucide-react';
import { Contribution } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';

interface ReceiptModalProps {
  contribution: Contribution | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  contribution,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !contribution) return null;

  const activeChama = storage.getActiveChama();
  const [copied, setCopied] = React.useState(false);

  const receiptSummaryText = `*OFFICIAL CHAMA RECEIPT*\n` +
    `Group: ${activeChama.name}\n` +
    `Receipt No: ${contribution.receiptNumber}\n` +
    `Member: ${contribution.memberName}\n` +
    `Amount: ${formatKES(contribution.amount)}\n` +
    `Type: ${contribution.type.toUpperCase()}\n` +
    `Reference: ${contribution.paymentReference}\n` +
    `Date: ${new Date(contribution.createdAt).toLocaleDateString('en-GB')}\n` +
    `Status: VERIFIED & RECONCILED\n` +
    `_Powered by ChamaSmart Kenya_`;

  const whatsappHref = `https://api.whatsapp.com/send?text=${encodeURIComponent(receiptSummaryText)}`;

  const handleCopyReceipt = () => {
    navigator.clipboard.writeText(receiptSummaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl flex flex-col text-slate-800 animate-in fade-in zoom-in-95 duration-150">
        {/* Top Action Bar */}
        <div className="bg-slate-900 text-white px-4 py-2.5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5">
            <ShieldCheck size={14} className="text-emerald-400" />
            <span className="font-semibold">Verified Electronic Receipt</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            <X size={16} />
          </button>
        </div>

        {/* Printable Receipt Paper Body */}
        <div className="p-5 bg-amber-50/40 border-b border-dashed border-slate-300 relative font-sans">
          {/* Subtle watermark */}
          <div className="absolute inset-0 flex items-center justify-center opacity-4 pointer-events-none">
            <span className="text-6xl font-black rotate-[-25deg] text-emerald-900">
              CHAMASMART
            </span>
          </div>

          <div className="text-center pb-4 border-b border-slate-200">
            <h2 className="text-base font-extrabold text-emerald-950 uppercase tracking-tight">
              {activeChama.name}
            </h2>
            <p className="text-[11px] text-slate-600 mt-0.5">
              {activeChama.county} · Reg: {activeChama.regNumber || 'Registered CBO/Chama'}
            </p>
            <div className="inline-block mt-1.5 px-2.5 py-0.5 bg-emerald-100 text-emerald-800 font-mono text-[10px] font-bold rounded">
              RECEIPT: {contribution.receiptNumber}
            </div>
          </div>

          <div className="py-4 space-y-2.5 text-xs">
            <div className="flex justify-between items-center text-slate-600">
              <span>Date & Time:</span>
              <span className="font-medium text-slate-900">
                {new Date(contribution.createdAt).toLocaleString('en-KE', { dateStyle: 'medium', timeStyle: 'short' })}
              </span>
            </div>

            <div className="flex justify-between items-center text-slate-600">
              <span>Member Name:</span>
              <span className="font-semibold text-slate-900">{contribution.memberName}</span>
            </div>

            <div className="flex justify-between items-center text-slate-600">
              <span>Payment Channel:</span>
              <span className="uppercase font-medium text-slate-800">
                {contribution.paymentMethod.replace('_', ' ')}
              </span>
            </div>

            <div className="flex justify-between items-center text-slate-600">
              <span>Transaction Ref:</span>
              <span className="font-mono font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded">
                {contribution.paymentReference}
              </span>
            </div>

            <div className="flex justify-between items-center text-slate-600">
              <span>Fund Account:</span>
              <span className="capitalize font-medium text-slate-800">
                {contribution.type} Fund
              </span>
            </div>

            {contribution.notes && (
              <div className="text-[11px] text-slate-500 pt-1 italic">
                Note: "{contribution.notes}"
              </div>
            )}
          </div>

          <div className="pt-3 border-t-2 border-slate-900 flex justify-between items-center">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Total Received:
            </span>
            <span className="text-lg font-black text-emerald-900 font-mono">
              {formatKES(contribution.amount)}
            </span>
          </div>

          <div className="mt-4 pt-3 border-t border-dashed border-slate-300 text-center text-[10px] text-slate-500 space-y-1">
            <div className="flex items-center justify-center gap-1 text-emerald-700 font-semibold">
              <CheckCircle size={12} />
              <span>Reconciled by {contribution.verifiedBy || 'Treasury'}</span>
            </div>
            <p>Official record generated by ChamaSmart Kenya platform.</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-3 bg-white flex gap-2">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all text-center"
          >
            <Share2 size={14} />
            <span>WhatsApp</span>
          </a>
          <button
            onClick={handleCopyReceipt}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all"
          >
            {copied ? <CheckCircle size={14} className="text-emerald-600" /> : <Printer size={14} />}
            <span>{copied ? 'Copied!' : 'Copy Text'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
