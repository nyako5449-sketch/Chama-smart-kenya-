import React, { useState } from 'react';
import { 
  ChevronDown, Bell, Globe, Wifi, WifiOff, 
  Shield, Check, UserCheck, Sparkles 
} from 'lucide-react';
import { Chama, Language, UserRole } from '../types';
import { storage } from '../services/storageService';

interface HeaderBarProps {
  activeChama: Chama;
  onOpenChamaSwitch: () => void;
  onOpenNotifications: () => void;
  unreadCount: number;
  currentLanguage: Language;
  onToggleLanguage: () => void;
  isOffline: boolean;
  onToggleOffline: () => void;
  currentRole: UserRole;
  onRoleChanged: (role: UserRole) => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  activeChama,
  onOpenChamaSwitch,
  onOpenNotifications,
  unreadCount,
  currentLanguage,
  onToggleLanguage,
  isOffline,
  onToggleOffline,
  currentRole,
  onRoleChanged,
}) => {
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const currentUser = storage.getCurrentUser();

  const roleLabels: Record<UserRole, string> = {
    super_admin: 'Super Admin',
    chairperson: 'Chairperson',
    treasurer: 'Treasurer',
    secretary: 'Secretary',
    member: 'Ordinary Member',
    auditor: 'Auditor',
  };

  const roleColors: Record<UserRole, string> = {
    super_admin: 'bg-purple-100 text-purple-800 border-purple-200',
    chairperson: 'bg-amber-100 text-amber-900 border-amber-300',
    treasurer: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    secretary: 'bg-blue-100 text-blue-900 border-blue-300',
    member: 'bg-slate-100 text-slate-800 border-slate-200',
    auditor: 'bg-rose-100 text-rose-900 border-rose-300',
  };

  return (
    <div className="bg-emerald-950 text-white px-4 py-3 flex-shrink-0 shadow-md">
      {/* Top micro bar: Offline indicator & Language & Role Switcher */}
      <div className="flex items-center justify-between pb-2 border-b border-emerald-900/80 text-[11px]">
        {/* Offline Toggle */}
        <button
          onClick={onToggleOffline}
          className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold transition-all ${
            isOffline
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              : 'bg-emerald-800/60 text-emerald-300'
          }`}
          title="Toggle network simulation"
        >
          {isOffline ? <WifiOff size={11} /> : <Wifi size={11} />}
          <span>{isOffline ? 'Offline (Queued)' : 'Online'}</span>
        </button>

        {/* Role & Lang Buttons */}
        <div className="flex items-center gap-2">
          {/* Role Preview Dropdown Button */}
          <div className="relative">
            <button
              onClick={() => setShowRoleMenu(!showRoleMenu)}
              className="flex items-center gap-1 text-[10px] bg-emerald-900/90 hover:bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded-md border border-emerald-800 font-medium"
            >
              <UserCheck size={11} className="text-amber-400" />
              <span>Role: {roleLabels[currentRole]}</span>
              <ChevronDown size={10} />
            </button>

            {showRoleMenu && (
              <div className="absolute right-0 top-full mt-1.5 w-44 bg-white text-slate-900 rounded-xl shadow-xl border border-slate-200 p-1.5 z-50 text-xs animate-in fade-in duration-100">
                <p className="px-2 py-1 text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                  Test Chama Roles
                </p>
                {(Object.keys(roleLabels) as UserRole[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => {
                      onRoleChanged(r);
                      setShowRoleMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between ${
                      currentRole === r
                        ? 'bg-emerald-50 text-emerald-900 font-bold'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>{roleLabels[r]}</span>
                    {currentRole === r && <Check size={12} className="text-emerald-700" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Language Toggle */}
          <button
            onClick={onToggleLanguage}
            className="flex items-center gap-1 text-[10px] bg-emerald-900/90 text-emerald-200 px-2 py-0.5 rounded-md border border-emerald-800 font-bold"
          >
            <Globe size={11} />
            <span>{currentLanguage === 'en' ? 'KISWAHILI' : 'ENGLISH'}</span>
          </button>
        </div>
      </div>

      {/* Main Bar: Active Chama Name & Selector */}
      <div className="pt-2 flex items-center justify-between">
        <button
          onClick={onOpenChamaSwitch}
          className="flex items-center gap-2 text-left group hover:opacity-95 transition-opacity"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center font-bold text-white shadow-inner flex-shrink-0 text-base">
            {activeChama.name.charAt(0)}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1 text-white">
              <h1 className="font-bold text-sm truncate max-w-[210px] group-hover:text-amber-300 transition-colors">
                {activeChama.name}
              </h1>
              <ChevronDown size={14} className="text-emerald-400 flex-shrink-0" />
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-300">
              <span className="capitalize">{activeChama.groupType.replace('_', ' ')}</span>
              <span>·</span>
              <span>{activeChama.county}</span>
            </div>
          </div>
        </button>

        {/* Notifications Icon with count */}
        <button
          onClick={onOpenNotifications}
          className="relative p-2 text-emerald-200 hover:text-white rounded-xl hover:bg-emerald-900/60 transition-colors"
          aria-label="Notifications"
        >
          <Bell size={20} />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </button>
      </div>
    </div>
  );
};
