import React, { useState } from 'react';
import { 
  X, Check, Plus, Key, Building2, MapPin, 
  Users, ChevronRight, ShieldCheck 
} from 'lucide-react';
import { Chama, ChamaType, ContributionFrequency, InterestMethod } from '../types';
import { storage } from '../services/storageService';
import { formatKES } from '../services/calculations';

interface ChamaSwitchModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeChamaId: string;
  onChamaSelected: (chamaId: string) => void;
}

export const ChamaSwitchModal: React.FC<ChamaSwitchModalProps> = ({
  isOpen,
  onClose,
  activeChamaId,
  onChamaSelected,
}) => {
  const [mode, setMode] = useState<'list' | 'create' | 'join'>('list');
  const [chamas, setChamas] = useState<Chama[]>(storage.getChamas());
  const [joinCode, setJoinCode] = useState('');
  const [joinError, setJoinError] = useState('');

  // Create Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [county, setCounty] = useState('Nairobi');
  const [town, setTown] = useState('Westlands');
  const [groupType, setGroupType] = useState<ChamaType>('table_banking');
  const [frequency, setFrequency] = useState<ContributionFrequency>('monthly');
  const [minContribution, setMinContribution] = useState<number>(3000);
  const [welfareContribution, setWelfareContribution] = useState<number>(500);
  const [interestMethod, setInterestMethod] = useState<InterestMethod>('flat_rate');
  const [interestRate, setInterestRate] = useState<number>(10);
  const [multiplier, setMultiplier] = useState<number>(3);

  if (!isOpen) return null;

  const handleSelect = (id: string) => {
    storage.setActiveChamaId(id);
    onChamaSelected(id);
    onClose();
  };

  const handleJoinChama = (e: React.FormEvent) => {
    e.preventDefault();
    setJoinError('');
    const code = joinCode.trim().toUpperCase();
    const found = chamas.find((c) => c.inviteCode.toUpperCase() === code);

    if (found) {
      handleSelect(found.id);
    } else {
      setJoinError('Invalid invitation code. Check with your Chama Secretary or Chairperson.');
    }
  };

  const handleCreateChama = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const currentUser = storage.getCurrentUser();
    const randCode = `${name.slice(0, 4).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newChama = storage.createChama({
      name: name.trim(),
      description: description.trim() || 'Kenyan community savings and investment syndicate.',
      county,
      town,
      groupType,
      chairpersonId: currentUser.id,
      treasurerId: currentUser.id,
      secretaryId: currentUser.id,
      contributionFrequency: frequency,
      minContribution,
      welfareContribution,
      loanInterestMethod: interestMethod,
      defaultInterestRatePercent: interestRate,
      maxLoanRepaymentMonths: 6,
      maxLoanMultiplier: multiplier,
      latePenaltyPercent: 5,
      meetingSchedule: 'Monthly on First Saturday at 2:00 PM',
      inviteCode: randCode,
      isPremium: false,
      currency: 'KES',
      mpesaPaybill: '408221',
    });

    setChamas(storage.getChamas());
    handleSelect(newChama.id);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col max-h-[90vh] text-slate-800 animate-in fade-in duration-150">
        <div className="bg-emerald-950 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 size={20} className="text-amber-400" />
            <div>
              <h3 className="font-bold text-sm">Chama Switcher & Creation</h3>
              <p className="text-[11px] text-emerald-300">Manage Multiple Investment Groups</p>
            </div>
          </div>
          <button onClick={onClose} className="text-emerald-300 hover:text-white p-1">
            <X size={18} />
          </button>
        </div>

        {/* Tab switch header */}
        <div className="flex border-b border-slate-200 bg-slate-50 p-1 text-xs">
          <button
            onClick={() => setMode('list')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              mode === 'list' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            My Chamas ({chamas.length})
          </button>
          <button
            onClick={() => setMode('join')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              mode === 'join' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Join with Code
          </button>
          <button
            onClick={() => setMode('create')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              mode === 'create' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Create New
          </button>
        </div>

        <div className="p-4 overflow-y-auto flex-1 space-y-3 text-xs">
          {/* MODE 1: LIST */}
          {mode === 'list' && (
            <div className="space-y-2">
              {chamas.map((c) => {
                const isCurrent = c.id === activeChamaId;
                const members = storage.getMembers(c.id);

                return (
                  <div
                    key={c.id}
                    onClick={() => handleSelect(c.id)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                      isCurrent
                        ? 'bg-emerald-50 border-emerald-600 ring-1 ring-emerald-600'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-700 to-teal-800 text-white font-bold flex items-center justify-center text-sm shadow-inner">
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-bold text-xs text-slate-900">{c.name}</h4>
                          {c.isPremium && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-900 font-bold px-1.5 py-0.2 rounded">
                              PRO
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                          <span className="capitalize">{c.groupType.replace('_', ' ')}</span>
                          <span>·</span>
                          <span>{c.county}</span>
                          <span>·</span>
                          <span>{members.length} Members</span>
                        </div>
                      </div>
                    </div>

                    {isCurrent ? (
                      <span className="text-emerald-700 font-bold flex items-center gap-1 text-[11px]">
                        <Check size={14} /> Active
                      </span>
                    ) : (
                      <ChevronRight size={16} className="text-slate-400" />
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* MODE 2: JOIN */}
          {mode === 'join' && (
            <form onSubmit={handleJoinChama} className="space-y-3">
              {joinError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl">
                  {joinError}
                </div>
              )}
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Chama Invitation Code
                </label>
                <input
                  type="text"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value)}
                  placeholder="e.g. TUMAINI-2026 or HUSTLE-NAIROBI"
                  className="w-full border border-slate-300 rounded-xl p-3 font-mono font-bold text-center tracking-widest text-sm uppercase"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 px-3 rounded-xl transition-all"
              >
                Join Chama
              </button>

              <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl space-y-1">
                <span className="font-semibold text-slate-700">Sample Codes to Test:</span>
                <p>· <strong>TUMAINI-2026</strong> (Tumaini Women Table Banking)</p>
                <p>· <strong>HUSTLE-NAIROBI</strong> (Nairobi Hustlers Investment Club)</p>
                <p>· <strong>USHIRIKIANO-NYERI</strong> (Ushirikiano Welfare SACCO)</p>
              </div>
            </form>
          )}

          {/* MODE 3: CREATE */}
          {mode === 'create' && (
            <form onSubmit={handleCreateChama} className="space-y-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Group Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Karibu Farmers Table Banking"
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Group Type</label>
                  <select
                    value={groupType}
                    onChange={(e) => setGroupType(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value="table_banking">Table Banking</option>
                    <option value="investment_club">Investment Club</option>
                    <option value="merry_go_round">Merry-Go-Round</option>
                    <option value="welfare_sacco">Welfare Association</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Contribution Schedule</label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value="monthly">Monthly</option>
                    <option value="weekly">Weekly</option>
                    <option value="quarterly">Quarterly</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">County</label>
                  <select
                    value={county}
                    onChange={(e) => setCounty(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value="Nairobi">Nairobi</option>
                    <option value="Nakuru">Nakuru</option>
                    <option value="Kiambu">Kiambu</option>
                    <option value="Nyeri">Nyeri</option>
                    <option value="Mombasa">Mombasa</option>
                    <option value="Kisumu">Kisumu</option>
                    <option value="Uasin Gishu">Uasin Gishu (Eldoret)</option>
                    <option value="Machakos">Machakos</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Town</label>
                  <input
                    type="text"
                    value={town}
                    onChange={(e) => setTown(e.target.value)}
                    placeholder="e.g. Westlands / CBD"
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Min Savings (KES)</label>
                  <input
                    type="number"
                    value={minContribution}
                    onChange={(e) => setMinContribution(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-semibold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Welfare Kitty (KES)</label>
                  <input
                    type="number"
                    value={welfareContribution}
                    onChange={(e) => setWelfareContribution(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-semibold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Loan Interest Rule</label>
                  <select
                    value={interestMethod}
                    onChange={(e) => setInterestMethod(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value="flat_rate">Flat Rate (10%)</option>
                    <option value="reducing_balance">Reducing Balance</option>
                    <option value="interest_free">Interest-Free</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Max Borrow Multiplier</label>
                  <select
                    value={multiplier}
                    onChange={(e) => setMultiplier(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value={2}>2x Savings</option>
                    <option value={3}>3x Savings</option>
                    <option value={4}>4x Savings</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 px-3 rounded-xl transition-all"
              >
                Create Chama & Generate Invite Code
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
