import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Wifi, BatteryMedium, Signal } from 'lucide-react';
import { storage } from '../services/storageService';

interface AndroidFrameProps {
  children: React.ReactNode;
  activeChamaName?: string;
  onOpenPublish?: () => void;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children, activeChamaName, onOpenPublish }) => {
  const [viewMode, setViewMode] = useState<'android_frame' | 'responsive'>(
    storage.getDeviceViewMode()
  );
  const [currentTime, setCurrentTime] = useState('08:30');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const toggleMode = (mode: 'android_frame' | 'responsive') => {
    setViewMode(mode);
    storage.setDeviceViewMode(mode);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-start text-slate-100 font-sans">
      {/* Top Floating Viewport Control Bar */}
      <div className="w-full bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-2 flex items-center justify-between text-xs z-40 sticky top-0">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-bold text-emerald-400">ChamaSmart Kenya</span>
          <span className="hidden sm:inline text-slate-400 text-[11px]">
            · Android Fintech Client
          </span>
        </div>

        <div className="flex items-center gap-2">
          {onOpenPublish && (
            <button
              onClick={onOpenPublish}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-2.5 py-1 rounded-lg text-[11px] flex items-center gap-1 shadow-sm transition-all active:scale-95"
            >
              <span>🚀 Publish</span>
              <span className="hidden sm:inline">to Play Store & GitHub</span>
            </button>
          )}

          <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-lg border border-slate-700">
            <button
              onClick={() => toggleMode('android_frame')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
                viewMode === 'android_frame'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone size={13} />
              <span className="hidden sm:inline">Pixel Frame</span>
            </button>
            <button
              onClick={() => toggleMode('responsive')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
                viewMode === 'responsive'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Monitor size={13} />
              <span className="hidden sm:inline">Fluid</span>
            </button>
          </div>
        </div>
      </div>

      {/* Container Content */}
      <div className="w-full flex-1 flex items-center justify-center p-0 sm:p-4">
        {viewMode === 'android_frame' ? (
          <div className="relative w-full max-w-[430px] h-[92vh] max-h-[890px] bg-slate-900 rounded-none sm:rounded-[42px] border-0 sm:border-[10px] border-slate-800 shadow-2xl flex flex-col overflow-hidden ring-1 ring-slate-700/50">
            {/* Camera Punch Hole & Android Status Bar */}
            <div className="bg-emerald-950 text-emerald-200 px-5 pt-3 pb-2 flex items-center justify-between text-xs font-mono select-none flex-shrink-0 z-30">
              <span className="font-bold text-white text-[12px]">{currentTime}</span>

              {/* Punch Hole */}
              <div className="w-4 h-4 rounded-full bg-black border border-slate-800 flex-shrink-0" />

              <div className="flex items-center gap-1.5 text-slate-300">
                <span className="text-[10px] text-emerald-300 font-sans font-bold">Safaricom 5G</span>
                <Signal size={12} className="text-emerald-400" />
                <Wifi size={12} className="text-emerald-400" />
                <BatteryMedium size={14} className="text-white" />
              </div>
            </div>

            {/* App Screen Viewport */}
            <div className="flex-1 overflow-y-auto bg-slate-100 text-slate-900 flex flex-col relative">
              {children}
            </div>

            {/* Android Navigation Gesture Pill Bar */}
            <div className="bg-white py-1.5 flex items-center justify-center flex-shrink-0 border-t border-slate-200">
              <div className="w-32 h-1 bg-slate-400 rounded-full" />
            </div>
          </div>
        ) : (
          <div className="w-full max-w-4xl min-h-[90vh] bg-slate-100 rounded-2xl shadow-xl flex flex-col overflow-hidden text-slate-900">
            {children}
          </div>
        )}
      </div>
    </div>
  );
};
