import React from 'react';
import { X, Bell, CheckCircle2, Landmark, Smartphone, Calendar, AlertCircle } from 'lucide-react';
import { NotificationItem } from '../types';
import { storage } from '../services/storageService';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onRefresh: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  notifications,
  onRefresh,
}) => {
  if (!isOpen) return null;

  const handleMarkRead = (id: string) => {
    storage.markNotificationRead(id);
    onRefresh();
  };

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'mpesa_received':
        return <Smartphone size={16} className="text-emerald-600" />;
      case 'loan_update':
        return <Landmark size={16} className="text-amber-600" />;
      case 'meeting_alert':
        return <Calendar size={16} className="text-blue-600" />;
      default:
        return <AlertCircle size={16} className="text-slate-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl flex flex-col max-h-[85vh] text-slate-800 animate-in fade-in duration-150">
        <div className="bg-emerald-950 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell size={18} className="text-amber-400" />
            <h3 className="font-bold text-sm">Notifications & Alerts</h3>
          </div>
          <button onClick={onClose} className="text-emerald-300 hover:text-white p-1">
            <X size={18} />
          </button>
        </div>

        <div className="p-3 overflow-y-auto divide-y divide-slate-100 flex-1 space-y-2 text-xs">
          {notifications.length === 0 ? (
            <div className="py-8 text-center text-slate-400">
              <p>No notifications right now.</p>
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                onClick={() => handleMarkRead(n.id)}
                className={`p-2.5 rounded-xl transition-all cursor-pointer space-y-1 ${
                  !n.isRead ? 'bg-emerald-50/70 border border-emerald-200' : 'hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-slate-900">
                    {getIcon(n.type)}
                    <span>{n.title}</span>
                  </div>
                  {!n.isRead && (
                    <span className="w-2 h-2 rounded-full bg-emerald-600" />
                  )}
                </div>
                <p className="text-[11px] text-slate-600 pl-5">{n.message}</p>
                <p className="text-[10px] text-slate-400 pl-5 font-mono">
                  {new Date(n.timestamp).toLocaleDateString('en-GB')}
                </p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
