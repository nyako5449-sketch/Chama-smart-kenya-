import React, { useState, useEffect } from 'react';
import { X, ExternalLink, ShieldCheck } from 'lucide-react';
import { storage } from '../services/storageService';

interface AdMobInterstitialModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdMobInterstitialModal: React.FC<AdMobInterstitialModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [canClose, setCanClose] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const config = storage.getAdMobConfig();

  useEffect(() => {
    if (isOpen) {
      setCanClose(false);
      setCountdown(3);
      storage.recordAdImpression('interstitial');

      const timer = setInterval(() => {
        setCountdown((c) => {
          if (c <= 1) {
            clearInterval(timer);
            setCanClose(true);
            return 0;
          }
          return c - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex flex-col justify-between p-4 text-white animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <span className="bg-amber-500/20 text-amber-300 font-mono text-[10px] px-2 py-0.5 rounded font-semibold">
            AdMob Interstitial Test
          </span>
          <span className="font-mono text-xs text-slate-400">
            {config.testAdUnitIds.interstitial}
          </span>
        </div>
        <div>
          {canClose ? (
            <button
              onClick={onClose}
              className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-all active:scale-95"
            >
              <X size={20} />
            </button>
          ) : (
            <div className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center font-mono text-xs text-amber-400 font-bold">
              {countdown}
            </div>
          )}
        </div>
      </div>

      {/* Main Creative */}
      <div className="max-w-md mx-auto w-full text-center my-auto space-y-6">
        <div className="w-24 h-24 rounded-2xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
          <span className="text-3xl font-extrabold font-mono">CIC</span>
        </div>

        <div>
          <h2 className="text-2xl font-bold text-white">
            CIC Chama Insurance & Group Asset Protection
          </h2>
          <p className="text-slate-300 text-sm mt-2 max-w-sm mx-auto leading-relaxed">
            Ensure your group's agricultural land titles, SACCO treasury bonds, and members' agribusiness loans are insured against drought and market volatility.
          </p>
        </div>

        <div className="bg-slate-800/80 rounded-xl p-4 border border-slate-700 text-left space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Coverage limit</span>
            <span className="font-semibold text-emerald-400">Up to KSh 10,000,000</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Instant Claim Payout</span>
            <span className="font-semibold text-white">Within 48 hours via M-Pesa</span>
          </div>
        </div>

        <a
          href="https://cic.co.ke"
          target="_blank"
          rel="noopener noreferrer"
          onClick={onClose}
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all text-center"
        >
          <span>Explore Group Plans</span>
          <ExternalLink size={16} />
        </a>
      </div>

      {/* Footer Notice */}
      <div className="flex items-center justify-center gap-2 text-slate-500 text-xs pb-2">
        <ShieldCheck size={14} className="text-emerald-500" />
        <span>Compliant with Google Mobile Ads Policies & Kenya DPA 2019</span>
      </div>
    </div>
  );
};
