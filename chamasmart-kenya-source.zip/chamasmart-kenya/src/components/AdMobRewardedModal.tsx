import React, { useState, useEffect } from 'react';
import { Award, CheckCircle2, Play, ShieldAlert, X } from 'lucide-react';
import { storage } from '../services/storageService';

interface AdMobRewardedModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardEarned: () => void;
}

export const AdMobRewardedModal: React.FC<AdMobRewardedModalProps> = ({
  isOpen,
  onClose,
  onRewardEarned,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(6);
  const [completed, setCompleted] = useState(false);
  const config = storage.getAdMobConfig();

  useEffect(() => {
    let timer: any;
    if (isPlaying && secondsLeft > 0) {
      timer = setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    } else if (isPlaying && secondsLeft === 0) {
      setCompleted(true);
      storage.recordAdImpression('rewarded');
    }
    return () => clearTimeout(timer);
  }, [isPlaying, secondsLeft]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 text-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Top Ad banner bar */}
        <div className="bg-slate-950 px-4 py-2 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="bg-amber-500/20 text-amber-400 font-mono text-[10px] px-2 py-0.5 rounded font-semibold">
              AdMob Rewarded Test Ad
            </span>
          </div>
          {isPlaying && (
            <span className="text-amber-400 font-mono text-xs">
              {secondsLeft > 0 ? `Reward in ${secondsLeft}s` : 'Reward Unlocked!'}
            </span>
          )}
          {!isPlaying && (
            <button onClick={onClose} className="p-1 hover:text-white rounded">
              <X size={16} />
            </button>
          )}
        </div>

        <div className="p-5 text-center">
          {!isPlaying && !completed && (
            <>
              <div className="w-14 h-14 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-3 text-amber-400">
                <Award size={32} />
              </div>
              <h3 className="text-base font-bold text-white mb-1">
                Unlock Chama Solvency & Audit Health Score
              </h3>
              <p className="text-xs text-slate-300 mb-4 leading-relaxed">
                Watch a short 6-second sponsor video to calculate your group's repayment reliability ratio, emergency liquidity score, and Kenya SACCO compliance health index for free.
              </p>
              <div className="bg-slate-800/70 rounded-lg p-2.5 mb-4 text-[11px] text-slate-300 font-mono text-left">
                Unit ID: {config.testAdUnitIds.rewarded}
              </div>
              <button
                onClick={() => setIsPlaying(true)}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-98"
              >
                <Play size={16} fill="currentColor" />
                <span>Watch Sponsor Video (6s)</span>
              </button>
            </>
          )}

          {isPlaying && !completed && (
            <div className="py-6 space-y-4">
              <div className="relative w-full aspect-video bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex flex-col items-center justify-center p-4">
                <div className="w-12 h-12 rounded-full border-3 border-emerald-500 border-t-transparent animate-spin mb-2" />
                <p className="text-sm font-semibold text-emerald-400">Safaricom Business Paybill</p>
                <p className="text-xs text-slate-400 text-center mt-1">
                  Automate Chama reconciliation with Safaricom Daraja API 2.0
                </p>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-emerald-500 h-full transition-all duration-1000 ease-linear"
                  style={{ width: `${((6 - secondsLeft) / 6) * 100}%` }}
                />
              </div>
            </div>
          )}

          {completed && (
            <div className="py-2 space-y-4">
              <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 size={36} />
              </div>
              <div>
                <h4 className="text-base font-bold text-white">Reward Granted!</h4>
                <p className="text-xs text-slate-300 mt-1">
                  Your chama's solvency score is 94/100 (Excellent). Advanced audit breakdown is now unlocked.
                </p>
              </div>
              <button
                onClick={() => {
                  onRewardEarned();
                  onClose();
                }}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 px-4 rounded-xl"
              >
                View Chama Health Score
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
