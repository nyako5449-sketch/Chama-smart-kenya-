import React, { useState } from 'react';
import { 
  X, Calculator, ArrowRight, ShieldAlert, CheckCircle, 
  HelpCircle, ChevronRight, UserCheck 
} from 'lucide-react';
import { storage } from '../services/storageService';
import { calculateLoanBreakdown, formatKES } from '../services/calculations';
import { InterestMethod, Loan, Member } from '../types';

interface LoanCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoanSubmitted: (loan: Loan) => void;
}

export const LoanCalculatorModal: React.FC<LoanCalculatorModalProps> = ({
  isOpen,
  onClose,
  onLoanSubmitted,
}) => {
  const activeChama = storage.getActiveChama();
  const members = storage.getMembers(activeChama.id);
  const currentUser = storage.getCurrentUser();

  const [applicantMemberId, setApplicantMemberId] = useState(members[0]?.id || '');
  const [requestedAmount, setRequestedAmount] = useState<number>(20000);
  const [durationMonths, setDurationMonths] = useState<number>(4);
  const [interestMethod, setInterestMethod] = useState<InterestMethod>(
    activeChama.loanInterestMethod || 'flat_rate'
  );
  const [interestRate, setInterestRate] = useState<number>(
    activeChama.defaultInterestRatePercent || 10
  );
  const [purpose, setPurpose] = useState('');
  const [guarantor1Id, setGuarantor1Id] = useState(members[1]?.id || '');
  const [guarantor2Id, setGuarantor2Id] = useState(members[2]?.id || '');
  const [showSchedule, setShowSchedule] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const applicant = members.find((m) => m.id === applicantMemberId) || members[0];
  const maxBorrowLimit = (applicant?.totalSavings || 0) * (activeChama.maxLoanMultiplier || 3);

  const breakdown = calculateLoanBreakdown(
    requestedAmount,
    interestRate,
    durationMonths,
    interestMethod
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (requestedAmount <= 0) {
      setError('Amount must be greater than KSh 0');
      return;
    }
    if (requestedAmount > maxBorrowLimit && maxBorrowLimit > 0) {
      setError(`Requested amount exceeds maximum borrowing limit of ${formatKES(maxBorrowLimit)} (3x savings of ${formatKES(applicant.totalSavings)})`);
      return;
    }
    if (!purpose.trim()) {
      setError('Please state the purpose of the loan');
      return;
    }
    if (guarantor1Id === applicantMemberId || guarantor2Id === applicantMemberId) {
      setError('Applicant cannot be their own guarantor');
      return;
    }
    if (guarantor1Id === guarantor2Id) {
      setError('Please select two distinct guarantors');
      return;
    }

    const g1 = members.find((m) => m.id === guarantor1Id);
    const g2 = members.find((m) => m.id === guarantor2Id);

    const half = Math.round(requestedAmount / 2);
    const newLoan = storage.applyForLoan(activeChama.id, {
      chamaId: activeChama.id,
      memberId: applicant.id,
      memberName: applicant.fullName,
      memberPhone: applicant.phone,
      requestedAmount,
      approvedAmount: requestedAmount,
      interestMethod,
      interestRatePercent: interestRate,
      totalInterest: breakdown.totalInterest,
      totalPayable: breakdown.totalPayable,
      monthlyInstallment: breakdown.monthlyInstallment,
      purpose,
      durationMonths,
      guarantors: [
        { memberId: guarantor1Id, memberName: g1?.fullName || 'Guarantor 1', amountGuaranteed: half, status: 'confirmed' },
        { memberId: guarantor2Id, memberName: g2?.fullName || 'Guarantor 2', amountGuaranteed: half, status: 'confirmed' },
      ],
      schedule: breakdown.schedule,
      lateFeeAccrued: 0,
    });

    onLoanSubmitted(newLoan);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in fade-in duration-150">
        {/* Header */}
        <div className="bg-emerald-950 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center text-amber-400">
              <Calculator size={18} />
            </div>
            <div>
              <h3 className="font-bold text-sm">Loan Application & Calculator</h3>
              <p className="text-[11px] text-emerald-300">
                {activeChama.name} · Multiplier: {activeChama.maxLoanMultiplier}x savings
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-emerald-300 hover:text-white p-1">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 overflow-y-auto space-y-3.5 text-xs text-slate-800">
          {error && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
              <ShieldAlert size={16} className="flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Member selector */}
          <div>
            <label className="block font-medium text-slate-700 mb-1">
              Applying Member
            </label>
            <select
              value={applicantMemberId}
              onChange={(e) => setApplicantMemberId(e.target.value)}
              className="w-full border border-slate-300 rounded-xl p-2.5 bg-white text-xs"
            >
              {members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.fullName} ({m.memberNumber}) — Savings: {formatKES(m.totalSavings)}
                </option>
              ))}
            </select>
            <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
              <span>Member Savings: <strong className="text-slate-800">{formatKES(applicant?.totalSavings || 0)}</strong></span>
              <span>Borrowing Cap: <strong className="text-emerald-700">{formatKES(maxBorrowLimit)}</strong></span>
            </div>
          </div>

          {/* Amount & Duration */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Requested Amount (KES)
              </label>
              <input
                type="number"
                min="1000"
                step="500"
                value={requestedAmount}
                onChange={(e) => setRequestedAmount(Number(e.target.value))}
                className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-semibold"
                required
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Repayment Period (Months)
              </label>
              <select
                value={durationMonths}
                onChange={(e) => setDurationMonths(Number(e.target.value))}
                className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
              >
                {[1, 2, 3, 4, 6, 9, 12].map((m) => (
                  <option key={m} value={m}>
                    {m} {m === 1 ? 'Month' : 'Months'}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Interest Method & Rate */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Interest Calculation Method
              </label>
              <select
                value={interestMethod}
                onChange={(e) => setInterestMethod(e.target.value as any)}
                className="w-full border border-slate-300 rounded-xl p-2 text-xs bg-white"
              >
                <option value="flat_rate">Flat Rate</option>
                <option value="reducing_balance">Reducing Balance</option>
                <option value="interest_free">Interest-Free (Welfare)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Interest Rate (%)
              </label>
              <input
                type="number"
                value={interestRate}
                disabled={interestMethod === 'interest_free'}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full border border-slate-300 rounded-xl p-2 text-xs disabled:bg-slate-100"
              />
            </div>
          </div>

          {/* Calculated Result Card */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-emerald-900 font-medium">Monthly Installment:</span>
              <span className="font-bold text-emerald-900 text-sm font-mono">
                {formatKES(breakdown.monthlyInstallment)}
              </span>
            </div>
            <div className="flex justify-between items-center text-xs text-slate-600">
              <span>Total Interest Accrued:</span>
              <span className="font-semibold text-slate-800 font-mono">{formatKES(breakdown.totalInterest)}</span>
            </div>
            <div className="flex justify-between items-center text-xs text-slate-600 border-t border-emerald-200/80 pt-1.5">
              <span className="font-bold text-slate-900">Total Payable:</span>
              <span className="font-bold text-emerald-950 font-mono text-sm">{formatKES(breakdown.totalPayable)}</span>
            </div>

            <button
              type="button"
              onClick={() => setShowSchedule(!showSchedule)}
              className="text-[11px] text-emerald-800 font-semibold underline mt-1 flex items-center gap-1"
            >
              <span>{showSchedule ? 'Hide' : 'View'} Monthly Amortization Schedule</span>
              <ChevronRight size={12} className={showSchedule ? 'rotate-90 transition-transform' : ''} />
            </button>

            {showSchedule && (
              <div className="mt-2 max-h-36 overflow-y-auto border border-emerald-200 rounded-lg bg-white text-[10px]">
                <table className="w-full text-left">
                  <thead className="bg-emerald-100/70 text-emerald-950">
                    <tr>
                      <th className="p-1.5">#</th>
                      <th className="p-1.5">Due Date</th>
                      <th className="p-1.5">Principal</th>
                      <th className="p-1.5">Interest</th>
                      <th className="p-1.5">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-emerald-100">
                    {breakdown.schedule.map((item) => (
                      <tr key={item.installmentNumber}>
                        <td className="p-1.5 font-medium">{item.installmentNumber}</td>
                        <td className="p-1.5">{item.dueDate}</td>
                        <td className="p-1.5">{formatKES(item.principalDue)}</td>
                        <td className="p-1.5">{formatKES(item.interestDue)}</td>
                        <td className="p-1.5 font-bold text-emerald-900">{formatKES(item.totalDue)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Purpose */}
          <div>
            <label className="block font-medium text-slate-700 mb-1">
              Loan Purpose
            </label>
            <input
              type="text"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder="e.g. Purchase agricultural fertilizer and seeds for long rains"
              className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
              required
            />
          </div>

          {/* Guarantors */}
          <div className="space-y-2 pt-1 border-t border-slate-200">
            <div className="flex items-center gap-1.5 text-slate-800 font-medium text-xs">
              <UserCheck size={14} className="text-emerald-700" />
              <span>Chama Guarantors (Dual Required)</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] text-slate-500 mb-0.5">Guarantor 1</label>
                <select
                  value={guarantor1Id}
                  onChange={(e) => setGuarantor1Id(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-[11px] bg-white"
                >
                  {members.filter((m) => m.id !== applicantMemberId).map((m) => (
                    <option key={m.id} value={m.id}>{m.fullName}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-0.5">Guarantor 2</label>
                <select
                  value={guarantor2Id}
                  onChange={(e) => setGuarantor2Id(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-[11px] bg-white"
                >
                  {members.filter((m) => m.id !== applicantMemberId).map((m) => (
                    <option key={m.id} value={m.id}>{m.fullName}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-sm"
            >
              <span>Submit Application for Chama Review</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
