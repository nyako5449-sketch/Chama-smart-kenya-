import React, { useState } from 'react';
import { 
  X, Github, Play, Check, Copy, ExternalLink, 
  Terminal, ShieldCheck, Download, Smartphone, Sparkles, 
  Globe, Share2, FileCode, CheckCircle2, Package, Layers, Info
} from 'lucide-react';

interface PublishModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PublishModal: React.FC<PublishModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'export' | 'uptodown' | 'softonic' | 'playstore' | 'github'>('export');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const appBaseUrl = window.location.origin.includes('localhost') 
    ? 'https://ais-pre-55mdt2d5mgi2l6pkw3nbdn-432883725025.europe-west3.run.app' 
    : window.location.origin;

  const zipDownloadUrl = `${appBaseUrl}/chamasmart-kenya-source.zip`;
  const padXmlUrl = `${appBaseUrl}/pad_file.xml`;
  const uptodownMetaUrl = `${appBaseUrl}/uptodown-meta.json`;
  const privacyUrl = `${appBaseUrl}/privacy.html`;
  const manifestUrl = `${appBaseUrl}/manifest.json`;

  const gitPushCommand = `git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/chamasmart-kenya.git
git branch -M main
git push -u origin main`;

  const ghCliCommand = `gh repo create chamasmart-kenya --public --source=. --push`;

  const playBuildCommand = `npm run build
npx @bubblewrap/cli init --manifest=${manifestUrl}
npx @bubblewrap/cli build`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 text-slate-100">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in fade-in duration-150">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
              <Sparkles size={18} />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">ChamaSmart Kenya Export & Distribution</h3>
              <p className="text-[11px] text-slate-400">Download ZIP • Phone APK Build • Uptodown • Play Store</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded">
            <X size={18} />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 p-1 text-xs overflow-x-auto gap-1">
          <button
            onClick={() => setActiveTab('export')}
            className={`py-2 px-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'export' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download size={14} className="text-emerald-300" />
            <span>1. Download ZIP & Phone APK</span>
          </button>
          <button
            onClick={() => setActiveTab('uptodown')}
            className={`py-2 px-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'uptodown' ? 'bg-emerald-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe size={14} className="text-emerald-400" />
            <span>2. Uptodown</span>
          </button>
          <button
            onClick={() => setActiveTab('softonic')}
            className={`py-2 px-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'softonic' ? 'bg-blue-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode size={14} className="text-blue-400" />
            <span>3. Softonic</span>
          </button>
          <button
            onClick={() => setActiveTab('playstore')}
            className={`py-2 px-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'playstore' ? 'bg-amber-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Play size={14} className="fill-current text-amber-400" />
            <span>4. Play Store</span>
          </button>
          <button
            onClick={() => setActiveTab('github')}
            className={`py-2 px-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'github' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Github size={14} />
            <span>5. GitHub</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs text-slate-300">
          {/* TAB 1: EXPORT & PHONE APK */}
          {activeTab === 'export' && (
            <div className="space-y-3.5">
              <div className="bg-emerald-950/80 border border-emerald-700/80 p-3.5 rounded-2xl flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Package size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white text-xs">Complete Source Code ZIP Packaged</h4>
                  <p className="text-[11px] text-emerald-200 mt-0.5 leading-relaxed">
                    120 files (0.55 MB). Contains the full React 19 source, Vite build config, Tailwind styles, Capacitor native Android Studio project with Gradle wrapper, and automated cloud APK builder.
                  </p>
                </div>
              </div>

              {/* Direct Download Action Button */}
              <div className="space-y-2">
                <a
                  href="/chamasmart-kenya-source.zip"
                  download="chamasmart-kenya-source.zip"
                  className="w-full bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-black py-3 px-4 rounded-xl flex items-center justify-center gap-2 text-xs shadow-lg transition-all text-center"
                >
                  <Download size={16} />
                  <span>Download chamasmart-kenya-source.zip (0.55 MB)</span>
                </a>

                {/* Direct Link Copy */}
                <div className="relative bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-[11px] flex items-center justify-between">
                  <span className="text-emerald-400 truncate pr-16">{zipDownloadUrl}</span>
                  <button
                    onClick={() => handleCopy(zipDownloadUrl, 'zip_url')}
                    className="bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-semibold py-1 px-2.5 rounded flex items-center gap-1 flex-shrink-0"
                  >
                    {copiedKey === 'zip_url' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedKey === 'zip_url' ? 'Copied!' : 'Copy Link'}</span>
                  </button>
                </div>
              </div>

              {/* Step-by-step phone only APK generation */}
              <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-white font-bold text-xs">
                  <Smartphone size={16} className="text-emerald-400" />
                  <span>How to Build an Installable APK from Your Phone (KSh 0 Budget):</span>
                </div>
                
                <ol className="list-decimal pl-4 space-y-1.5 text-[11px] text-slate-300">
                  <li>
                    <strong className="text-white">Download the ZIP</strong> onto your Android phone above.
                  </li>
                  <li>
                    Go to <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-emerald-400 underline font-semibold">github.com</a> in your phone browser and create a free new repository named <code className="text-emerald-300">chamasmart-kenya</code>.
                  </li>
                  <li>
                    Extract the ZIP and upload the files to your GitHub repository (or use the free Termux app on Android to push in 1 command).
                  </li>
                  <li>
                    <strong className="text-white">GitHub Actions builds it automatically!</strong> Because <code className="text-emerald-300">.github/workflows/build-apk.yml</code> is included, GitHub cloud runners will build <code className="text-white">app-debug.apk</code> in ~3 minutes for 100% free.
                  </li>
                  <li>
                    Tap the <strong>Actions</strong> tab on your GitHub repository, tap the completed build, and download the <strong>ChamaSmart-Kenya-Debug-APK</strong> directly onto your phone to install!
                  </li>
                </ol>
              </div>

              {/* Included Stack Info */}
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block font-semibold">Native Android ID</span>
                  <span className="text-emerald-400 font-mono font-bold">ke.chamasmart.app</span>
                </div>
                <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block font-semibold">Target SDK / Min</span>
                  <span className="text-white font-bold">SDK 34 / Android 7.0 (API 24)</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: UPTODOWN */}
          {activeTab === 'uptodown' && (
            <div className="space-y-3.5">
              <div className="bg-emerald-950/60 border border-emerald-800/80 p-3 rounded-xl flex items-start gap-2.5">
                <CheckCircle2 size={18} className="text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white text-xs">Uptodown Developer Zone Submission</h4>
                  <p className="text-[11px] text-emerald-200 mt-0.5 leading-relaxed">
                    Uptodown accepts direct Android web application URLs and package metadata. Below are the verified URLs configured for ChamaSmart Kenya.
                  </p>
                </div>
              </div>

              {/* Main Submission URL */}
              <div>
                <p className="font-semibold text-white mb-1 flex items-center gap-1.5">
                  <Globe size={14} className="text-emerald-400" />
                  Primary Application URL (Paste into Uptodown Developer Form)
                </p>
                <div className="relative bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-[11px] flex items-center justify-between">
                  <span className="text-emerald-400 truncate pr-16">{appBaseUrl}</span>
                  <button
                    onClick={() => handleCopy(appBaseUrl, 'upto_app')}
                    className="bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-semibold py-1 px-2.5 rounded flex items-center gap-1 flex-shrink-0"
                  >
                    {copiedKey === 'upto_app' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedKey === 'upto_app' ? 'Copied!' : 'Copy URL'}</span>
                  </button>
                </div>
              </div>

              {/* Uptodown JSON Feed */}
              <div>
                <p className="font-semibold text-white mb-1 flex items-center gap-1.5">
                  <FileCode size={14} className="text-emerald-400" />
                  Uptodown Metadata Manifest Endpoint
                </p>
                <div className="relative bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-[11px] flex items-center justify-between">
                  <span className="text-slate-300 truncate pr-16">{uptodownMetaUrl}</span>
                  <button
                    onClick={() => handleCopy(uptodownMetaUrl, 'upto_meta')}
                    className="bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-semibold py-1 px-2.5 rounded flex items-center gap-1 flex-shrink-0"
                  >
                    {copiedKey === 'upto_meta' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedKey === 'upto_meta' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {/* Privacy Policy URL */}
              <div>
                <p className="font-semibold text-white mb-1 flex items-center gap-1.5">
                  <ShieldCheck size={14} className="text-emerald-400" />
                  Kenya DPA 2019 Privacy Policy URL
                </p>
                <div className="relative bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-[11px] flex items-center justify-between">
                  <span className="text-slate-300 truncate pr-16">{privacyUrl}</span>
                  <button
                    onClick={() => handleCopy(privacyUrl, 'upto_priv')}
                    className="bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-semibold py-1 px-2.5 rounded flex items-center gap-1 flex-shrink-0"
                  >
                    {copiedKey === 'upto_priv' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedKey === 'upto_priv' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {/* Uptodown Submission Fields Reference */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-[11px]">
                <span className="font-bold text-white">Uptodown Submission Checklist:</span>
                <p className="text-slate-400">• App Name: <strong>ChamaSmart Kenya</strong></p>
                <p className="text-slate-400">• Package ID: <code>ke.chamasmart.app</code></p>
                <p className="text-slate-400">• Category: <strong>Finance & Productivity</strong></p>
                <p className="text-slate-400">• License: <strong>Free (Freeware with AdMob test units)</strong></p>
                <p className="text-slate-400">• Developer Email: <code>nyako5449@gmail.com</code></p>
              </div>

              <a
                href="https://developers.uptodown.com/publish"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 text-xs transition-all text-center"
              >
                <span>Open Uptodown Developer Publishing Portal</span>
                <ExternalLink size={14} />
              </a>
            </div>
          )}

          {/* TAB 3: SOFTONIC */}
          {activeTab === 'softonic' && (
            <div className="space-y-3.5">
              <div className="bg-blue-950/60 border border-blue-800/80 p-3 rounded-xl flex items-start gap-2.5">
                <CheckCircle2 size={18} className="text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white text-xs">Softonic Automated Ingestion (PAD File)</h4>
                  <p className="text-[11px] text-blue-200 mt-0.5 leading-relaxed">
                    Softonic automatically imports title, description, developer profile, screenshots, and licensing via the Portable Application Description (PAD v3.11) XML format.
                  </p>
                </div>
              </div>

              {/* PAD XML URL */}
              <div>
                <p className="font-semibold text-white mb-1 flex items-center gap-1.5">
                  <FileCode size={14} className="text-blue-400" />
                  Softonic PAD XML Feed URL (Paste into Softonic Submission)
                </p>
                <div className="relative bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-[11px] flex items-center justify-between">
                  <span className="text-blue-400 truncate pr-16">{padXmlUrl}</span>
                  <button
                    onClick={() => handleCopy(padXmlUrl, 'soft_pad')}
                    className="bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-semibold py-1 px-2.5 rounded flex items-center gap-1 flex-shrink-0"
                  >
                    {copiedKey === 'soft_pad' ? <Check size={12} className="text-blue-400" /> : <Copy size={12} />}
                    <span>{copiedKey === 'soft_pad' ? 'Copied!' : 'Copy PAD URL'}</span>
                  </button>
                </div>
              </div>

              {/* Softonic Profile Details */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-[11px]">
                <span className="font-bold text-white">Configured PAD Metadata:</span>
                <p className="text-slate-400">• Publisher: <strong>ChamaSmart Kenya Systems</strong></p>
                <p className="text-slate-400">• Author Email: <code>nyako5449@gmail.com</code></p>
                <p className="text-slate-400">• License Type: <strong>Freeware (100% Free to Use)</strong></p>
                <p className="text-slate-400">• Language: <strong>English & Kiswahili</strong></p>
                <p className="text-slate-400">• Application Platform: <strong>Android / Web App</strong></p>
              </div>

              <a
                href="https://developers.softonic.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 text-xs transition-all text-center"
              >
                <span>Open Softonic Developer Ingestion Portal</span>
                <ExternalLink size={14} />
              </a>
            </div>
          )}

          {/* TAB 4: PLAY STORE */}
          {activeTab === 'playstore' && (
            <div className="space-y-3.5">
              <div className="bg-amber-950/60 border border-amber-800/80 p-3 rounded-xl flex items-start gap-2.5">
                <CheckCircle2 size={18} className="text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white text-xs">Google Play Store Bundle (TWA / AAB)</h4>
                  <p className="text-[11px] text-amber-200 mt-0.5 leading-relaxed">
                    Google Play accepts Android App Bundles (<code className="bg-amber-900/60 px-1 py-0.5 rounded text-white font-mono">.aab</code>) using Google's official Bubblewrap CLI or Capacitor.
                  </p>
                </div>
              </div>

              {/* Bubblewrap CLI command */}
              <div>
                <p className="font-semibold text-white mb-1.5 flex items-center gap-1.5">
                  <Terminal size={14} className="text-amber-400" />
                  Terminal Commands to Generate .aab
                </p>
                <div className="relative bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px]">
                  <pre className="text-amber-400 overflow-x-auto whitespace-pre-wrap">{playBuildCommand}</pre>
                  <button
                    onClick={() => handleCopy(playBuildCommand, 'play_cmd')}
                    className="absolute top-2 right-2 bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-semibold py-1 px-2.5 rounded flex items-center gap-1"
                  >
                    {copiedKey === 'play_cmd' ? <Check size={12} className="text-amber-400" /> : <Copy size={12} />}
                    <span>{copiedKey === 'play_cmd' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {/* Play Store Submission Checklist */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] space-y-1">
                <span className="font-bold text-white block mb-1">Play Console Store Listing Details:</span>
                <div className="divide-y divide-slate-900">
                  <div className="flex justify-between py-1">
                    <span className="text-slate-400">Package Name:</span>
                    <span className="font-mono text-emerald-400">ke.chamasmart.app</span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span className="text-slate-400">Category:</span>
                    <span className="text-white">Finance / Productivity</span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span className="text-slate-400">Target Age:</span>
                    <span className="text-white">18 and over</span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span className="text-slate-400">Financial Declaration:</span>
                    <span className="text-white">Non-Banking Group Recordkeeping &amp; Table Banking Tool</span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span className="text-slate-400">Ads Declaration:</span>
                    <span className="text-white">Yes, Contains Ads (Google AdMob Compliant)</span>
                  </div>
                </div>
              </div>

              <a
                href="https://play.google.com/console"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 text-xs transition-all text-center"
              >
                <span>Open Google Play Console</span>
                <ExternalLink size={14} />
              </a>
            </div>
          )}

          {/* TAB 5: GITHUB */}
          {activeTab === 'github' && (
            <div className="space-y-3.5">
              <div className="bg-emerald-950/60 border border-emerald-800/80 p-3 rounded-xl flex items-start gap-2.5">
                <Check size={18} className="text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white text-xs">Git Repository Initialized &amp; Cloud APK Actions</h4>
                  <p className="text-[11px] text-emerald-200 mt-0.5">
                    Includes GitHub Actions workflow <code className="bg-emerald-900 px-1 py-0.5 rounded text-white font-mono">.github/workflows/build-apk.yml</code> for automated zero-cost cloud APK builds.
                  </p>
                </div>
              </div>

              <div>
                <p className="font-semibold text-white mb-1.5 flex items-center gap-1.5">
                  <Terminal size={14} className="text-emerald-400" />
                  Push to GitHub via Standard Git Commands
                </p>
                <div className="relative bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px]">
                  <pre className="text-emerald-400 overflow-x-auto whitespace-pre-wrap">{gitPushCommand}</pre>
                  <button
                    onClick={() => handleCopy(gitPushCommand, 'git')}
                    className="absolute top-2 right-2 bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-semibold py-1 px-2.5 rounded flex items-center gap-1"
                  >
                    {copiedKey === 'git' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedKey === 'git' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              <div>
                <p className="font-semibold text-white mb-1.5 flex items-center gap-1.5">
                  <Github size={14} className="text-emerald-400" />
                  Create &amp; Push via GitHub CLI (1-liner)
                </p>
                <div className="relative bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px]">
                  <pre className="text-emerald-400 overflow-x-auto whitespace-pre-wrap">{ghCliCommand}</pre>
                  <button
                    onClick={() => handleCopy(ghCliCommand, 'gh')}
                    className="absolute top-2 right-2 bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-semibold py-1 px-2.5 rounded flex items-center gap-1"
                  >
                    {copiedKey === 'gh' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedKey === 'gh' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
