import React, { useState } from 'react';
import { 
  X, FileCode, Database, Smartphone, ShieldCheck, 
  Terminal, Layers, CheckCircle2, Copy, Check 
} from 'lucide-react';

interface DevDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DevDocsModal: React.FC<DevDocsModalProps> = ({ isOpen, onClose }) => {
  const [activeSection, setActiveSection] = useState<'architecture' | 'database' | 'daraja' | 'admob' | 'apk'>('architecture');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyCode = (code: string, key: string) => {
    navigator.clipboard.writeText(code);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-slate-900 border border-slate-700 text-white rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in fade-in duration-150">
        {/* Header */}
        <div className="bg-slate-950 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCode size={20} className="text-emerald-400" />
            <div>
              <h3 className="font-bold text-sm text-white">ChamaSmart Kenya — Technical Architecture</h3>
              <p className="text-[11px] text-slate-400">Complete Developer Specs & Production Guide</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded">
            <X size={18} />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex bg-slate-950/80 border-b border-slate-800 p-1 text-xs overflow-x-auto">
          {[
            { id: 'architecture', label: '1. Architecture & Flow' },
            { id: 'database', label: '2. DB Schema (Drizzle/Firestore)' },
            { id: 'daraja', label: '3. Safaricom Daraja 2.0' },
            { id: 'admob', label: '4. Google AdMob Specs' },
            { id: 'apk', label: '5. Android APK / Play Store' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSection(tab.id as any)}
              className={`py-2 px-3 rounded-lg font-semibold whitespace-nowrap transition-all ${
                activeSection === tab.id
                  ? 'bg-emerald-700 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-300 leading-relaxed font-sans">
          {/* SECTION 1: ARCHITECTURE */}
          {activeSection === 'architecture' && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                <Layers size={16} /> 1. System Architecture & Component Flow
              </h4>
              <p>
                ChamaSmart Kenya is architected as an offline-first mobile financial management platform tailored for Android smartphones in Kenya.
              </p>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px] space-y-1 text-slate-300">
                <p className="text-emerald-400 font-bold">[Android Native / PWA Client] (Jetpack Compose / Capacitor)</p>
                <p className="pl-4">├── React 19 + TypeScript Presentation Layer (Zero-Pill WCAG AA compliant)</p>
                <p className="pl-4">├── Offline Storage Engine & Queue (IndexedDB + Room SQLite fallback)</p>
                <p className="pl-4">├── Google Mobile Ads SDK (AdMob Test Units + Remote Config Controller)</p>
                <p className="pl-4">└── Kenya DPA 2019 Privacy Consent & Export Module</p>
                <p className="text-amber-400 font-bold mt-2">[Backend API Proxy & Secure Cloud Functions]</p>
                <p className="pl-4">├── Safaricom Daraja STK Push & Webhook Callback Validator (B2C & C2B)</p>
                <p className="pl-4">├── Double-Entry Ledger Engine (Strict Non-Destructive Adjustments)</p>
                <p className="pl-4">└── Multi-Tenant Chama Security Rules (RBAC: Chair, Treasurer, Auditor)</p>
              </div>
            </div>
          )}

          {/* SECTION 2: DATABASE */}
          {activeSection === 'database' && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                <Database size={16} /> 2. Database Entities & Schema Definition
              </h4>
              <p>
                The database design enforces multi-tenant isolation where every financial record is indexed by <code>chamaId</code> and verified with cryptographic audit hashes.
              </p>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[10px] space-y-2 text-slate-300">
                <p className="text-emerald-300 font-bold">// Core Firestore / PostgreSQL Collections</p>
                <p>• <strong>users</strong>: <code>&#123; id, fullName, phone (+254), nationalId, role, isVerified &#125;</code></p>
                <p>• <strong>chamas</strong>: <code>&#123; id, name, groupType, county, minContribution, welfareKitty, inviteCode &#125;</code></p>
                <p>• <strong>members</strong>: <code>&#123; id, chamaId, memberNo, totalSavings, totalWelfare, activeLoanCount &#125;</code></p>
                <p>• <strong>contributions</strong>: <code>&#123; id, chamaId, memberId, amount, paymentMethod, paymentRef, receiptNo &#125;</code></p>
                <p>• <strong>loans</strong>: <code>&#123; id, chamaId, memberId, approvedAmount, interestMethod, balanceRemaining, chairApprovedBy, treasurerApprovedBy &#125;</code></p>
                <p>• <strong>ledger_entries</strong>: <code>&#123; id, chamaId, debitAccount, creditAccount, amount, auditHash, timestamp &#125;</code></p>
                <p>• <strong>meetings</strong>: <code>&#123; id, chamaId, title, date, venue, agenda, minutes, polls, actionItems &#125;</code></p>
              </div>
            </div>
          )}

          {/* SECTION 3: DARAJA */}
          {activeSection === 'daraja' && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                <Smartphone size={16} /> 3. Safaricom Daraja API 2.0 Integration
              </h4>
              <p>
                To go live with real M-Pesa payments, register at <strong>developer.safaricom.co.ke</strong> and provide:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-slate-300">
                <li><code>DARAJA_CONSUMER_KEY</code> & <code>DARAJA_CONSUMER_SECRET</code></li>
                <li><code>LIPA_NA_MPESA_PASSKEY</code> and <code>BUSINESS_SHORTCODE</code> (Till or Paybill)</li>
                <li>HTTPS Webhook Callback URL for Result Notifications</li>
              </ul>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[10px]">
                <p className="text-amber-400">// Sample Daraja STK Push Request Payload</p>
                <pre className="text-slate-300 overflow-x-auto mt-1">
{`POST https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest
{
  "BusinessShortCode": "408221",
  "Password": "BASE64(Shortcode+Passkey+Timestamp)",
  "Timestamp": "20261022143000",
  "TransactionType": "CustomerPayBillOnline",
  "Amount": 2500,
  "PartyA": "254712345678",
  "PartyB": "408221",
  "PhoneNumber": "254712345678",
  "CallBackURL": "https://chamasmart.ke/api/daraja/callback",
  "AccountReference": "CSK-001",
  "TransactionDesc": "Chama October Contribution"
}`}
                </pre>
              </div>
            </div>
          )}

          {/* SECTION 4: ADMOB */}
          {activeSection === 'admob' && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                <ShieldCheck size={16} /> 4. Google AdMob Monetization & Policy Compliance
              </h4>
              <p>
                Official test unit IDs are pre-configured to prevent ad network account suspensions during development:
              </p>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[10px] space-y-1">
                <p>• Adaptive Banner: <code>ca-app-pub-3940256099942544/6300978111</code></p>
                <p>• Interstitial Ad: <code>ca-app-pub-3940256099942544/1033173712</code></p>
                <p>• Rewarded Video Ad: <code>ca-app-pub-3940256099942544/5224354917</code></p>
                <p>• Native In-Feed: <code>ca-app-pub-3940256099942544/2247696110</code></p>
              </div>
              <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-[11px]">
                <strong>Policy Compliance Notice:</strong> Ads are strictly prohibited from appearing inside financial submission buttons or obscuring debt balances.
              </div>
            </div>
          )}

          {/* SECTION 5: APK */}
          {activeSection === 'apk' && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                <Terminal size={16} /> 5. Android APK & Google Play Store Checklist
              </h4>
              <p>
                To generate a release <code>.aab</code> or <code>.apk</code> for affordable Kenyan Android smartphones:
              </p>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px] space-y-1">
                <p className="text-emerald-400">// Build with Capacitor / Android Studio</p>
                <p>1. npm run build</p>
                <p>2. npx cap add android</p>
                <p>3. npx cap sync android</p>
                <p>4. ./gradlew bundleRelease</p>
              </div>
              <div className="space-y-1.5 pt-1">
                <p className="font-semibold text-slate-200">Google Play Compliance Steps:</p>
                <p className="flex items-center gap-1.5 text-slate-400"><CheckCircle2 size={13} className="text-emerald-400" /> Complete Financial Services Declaration</p>
                <p className="flex items-center gap-1.5 text-slate-400"><CheckCircle2 size={13} className="text-emerald-400" /> Disclose Kenya DPA 2019 Privacy Policy URL</p>
                <p className="flex items-center gap-1.5 text-slate-400"><CheckCircle2 size={13} className="text-emerald-400" /> Set App Content Rating for AdMob ads</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
