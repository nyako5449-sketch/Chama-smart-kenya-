import React from 'react';
import { 
  LayoutDashboard, ArrowLeftRight, Landmark, Users, 
  Menu 
} from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../i18n/translations';

export type TabType = 'dashboard' | 'transactions' | 'loans' | 'members' | 'more';

interface BottomNavProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  language: Language;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  language,
}) => {
  const t = getTranslation(language);

  const tabs: { id: TabType; label: string; icon: React.FC<{ size?: number; className?: string }> }[] = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'transactions', label: t.contributions, icon: ArrowLeftRight },
    { id: 'loans', label: t.loans, icon: Landmark },
    { id: 'members', label: t.members, icon: Users },
    { id: 'more', label: t.more, icon: Menu },
  ];

  return (
    <nav className="bg-white border-t border-slate-200/90 py-1 px-2 flex items-center justify-around flex-shrink-0 shadow-lg z-30">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex flex-col items-center justify-center py-1.5 px-3 rounded-xl transition-all relative ${
              isActive
                ? 'text-emerald-800 font-bold'
                : 'text-slate-500 hover:text-slate-800 font-medium'
            }`}
          >
            {isActive && (
              <span className="absolute -top-1 w-6 h-0.5 bg-emerald-700 rounded-full" />
            )}
            <Icon size={20} className={isActive ? 'text-emerald-700 scale-105 transition-transform' : 'text-slate-500'} />
            <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
