import React from 'react';
import { ExternalLink, Star } from 'lucide-react';
import { storage } from '../services/storageService';

interface AdMobNativeCardProps {
  category?: string;
}

export const AdMobNativeCard: React.FC<AdMobNativeCardProps> = () => {
  const config = storage.getAdMobConfig();
  const activeChama = storage.getActiveChama();

  if (!config.enabled || !config.nativeEnabled || activeChama.isPremium) {
    return null;
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-3.5 my-3 shadow-xs">
      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
        <span className="font-semibold text-emerald-800 tracking-wider uppercase text-[10px] bg-emerald-50 px-2 py-0.5 rounded">
          Sponsored · AdMob Native
        </span>
        <span className="font-mono text-[9px] text-slate-400">{config.testAdUnitIds.native.slice(0, 16)}...</span>
      </div>

      <div className="flex gap-3 items-start">
        <img
          src="https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&q=80&w=140"
          alt="Sponsor Ad"
          className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
        />
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-semibold text-slate-900 truncate">
            Britam Chama Group Funeral & Health Cover
          </h4>
          <p className="text-xs text-slate-600 line-clamp-2 mt-0.5">
            Shield your welfare members with KSh 100,000 benevolence cover from just KSh 150 per member monthly.
          </p>
          <div className="flex items-center justify-between mt-2">
            <div className="flex items-center text-amber-500 text-[11px] gap-1">
              <Star size={12} fill="currentColor" />
              <span className="font-semibold text-slate-700">4.8</span>
              <span className="text-slate-400">(420 chamas)</span>
            </div>
            <a
              href="https://www.britam.com"
              target="_blank"
              rel="noreferrer"
              onClick={() => storage.recordAdImpression('native')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline"
            >
              <span>Get Quote</span>
              <ExternalLink size={12} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
