import React from 'react';
import { 
  Calendar, BookOpen, BarChart3, Sliders, ShieldCheck, 
  FileCode2, ChevronRight, Sparkles, Building2, ExternalLink, Download 
} from 'lucide-react';
import { Chama, Language, UserRole } from '../types';

export type MoreSubScreen = 
  | 'menu' 
  | 'meetings' 
  | 'ledger' 
  | 'reports' 
  | 'ad_settings' 
  | 'privacy';

interface MoreViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
  onSelectSubScreen: (screen: MoreSubScreen) => void;
  onOpenDevDocs: () => void;
  onOpenPublish: () => void;
}

export const MoreView: React.FC<MoreViewProps> = ({
  activeChama,
  currentRole,
  language,
  onSelectSubScreen,
  onOpenDevDocs,
  onOpenPublish,
}) => {
  const menuItems = [
    {
      id: 'meetings',
      title: 'Meetings, Agendas & Polls',
      subtitle: 'Schedule sessions, minutes, live voting & WhatsApp notices',
      icon: Calendar,
      color: 'bg-blue-100 text-blue-800',
    },
    {
      id: 'ledger',
      title: 'Financial Ledger & Expenses',
      subtitle: 'Audited double-entry journal & operational cost approvals',
      icon: BookOpen,
      color: 'bg-emerald-100 text-emerald-800',
    },
    {
      id: 'reports',
      title: 'Financial Reports & Statements',
      subtitle: 'Annual savings growth, loan recovery rates & solvency',
      icon: BarChart3,
      color: 'bg-purple-100 text-purple-800',
    },
    {
      id: 'ad_settings',
      title: 'Google AdMob & Monetization',
      subtitle: 'Admin advertising controls, format switches & Pro upgrade',
      icon: Sliders,
      color: 'bg-amber-100 text-amber-800',
    },
    {
      id: 'privacy',
      title: 'Privacy & Kenya DPA 2019',
      subtitle: 'User profile, consent management & data export portability',
      icon: ShieldCheck,
      color: 'bg-teal-100 text-teal-800',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Header Banner */}
      <div className="bg-emerald-950 text-white p-4">
        <h2 className="text-base font-bold">Group Management & Tools</h2>
        <p className="text-xs text-emerald-300">
          Advanced Governance, Compliance & Monetization
        </p>
      </div>

      <div className="px-4 space-y-3">
        {/* Direct Download Source Code ZIP Card */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-800 text-white p-4 rounded-2xl shadow-md border border-emerald-600/50 flex flex-col gap-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 text-white flex items-center justify-center flex-shrink-0">
                <Download size={20} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-xs text-white">Full Source Code (.ZIP)</h4>
                  <span className="bg-emerald-400 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded uppercase">
                    Ready (0.55 MB)
                  </span>
                </div>
                <p className="text-[11px] text-emerald-100 mt-0.5">
                  120 files: React 19, Capacitor Android project & Gradle wrapper
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 pt-1 border-t border-emerald-700/60">
            <a
              href="/chamasmart-kenya-source.zip"
              download="chamasmart-kenya-source.zip"
              className="flex-1 bg-white text-emerald-950 hover:bg-emerald-50 active:scale-98 font-black py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 text-xs text-center shadow-xs transition-all"
            >
              <Download size={14} />
              <span>Download ZIP</span>
            </a>
            <button
              onClick={onOpenPublish}
              className="bg-emerald-950/70 hover:bg-emerald-950 text-white font-semibold py-2 px-3 rounded-xl flex items-center justify-center gap-1 text-xs border border-emerald-500/40"
            >
              <span>Build APK on Phone</span>
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        {/* Publish to Stores & Repositories Card */}
        <button
          onClick={onOpenPublish}
          className="w-full bg-slate-900 text-white p-4 rounded-2xl flex items-center justify-between shadow-md border border-slate-700/70 hover:brightness-110 active:scale-98 transition-all text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 text-emerald-400 border border-slate-700 flex items-center justify-center flex-shrink-0">
              <Sparkles size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-xs text-white">Publish Hub & Distribution</h4>
                <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded uppercase">
                  Uptodown &amp; Play
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5">
                PAD file, Uptodown JSON, Play Store AAB &amp; GitHub
              </p>
            </div>
          </div>
          <ChevronRight size={16} className="text-emerald-400 flex-shrink-0" />
        </button>

        {/* Menu list */}
        <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-xs">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onSelectSubScreen(item.id as MoreSubScreen)}
                className="w-full p-3.5 text-left flex items-center justify-between hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${item.color}`}>
                    <Icon size={18} />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-slate-900">{item.title}</h4>
                    <p className="text-[11px] text-slate-500 line-clamp-1">{item.subtitle}</p>
                  </div>
                </div>
                <ChevronRight size={16} className="text-slate-400 flex-shrink-0" />
              </button>
            );
          })}
        </div>

        {/* Developer Documentation Card */}
        <button
          onClick={onOpenDevDocs}
          className="w-full bg-slate-900 hover:bg-slate-800 text-white p-3.5 rounded-2xl flex items-center justify-between shadow-xs transition-colors"
        >
          <div className="flex items-center gap-3 text-left">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center flex-shrink-0">
              <FileCode2 size={18} />
            </div>
            <div>
              <h4 className="font-bold text-xs text-white">Technical Deliverables & Docs</h4>
              <p className="text-[11px] text-slate-400">Architecture, Daraja API guide & APK build</p>
            </div>
          </div>
          <ChevronRight size={16} className="text-slate-400 flex-shrink-0" />
        </button>

        {/* Legal & Regulatory Badge */}
        <div className="p-3 bg-emerald-50/80 border border-emerald-200/80 rounded-2xl text-[11px] text-slate-600 space-y-1">
          <div className="flex items-center gap-1.5 font-bold text-emerald-900">
            <ShieldCheck size={14} className="text-emerald-700" />
            <span>Kenya Fintech & SACCO Standards</span>
          </div>
          <p className="text-[10px] text-slate-500 leading-relaxed">
            ChamaSmart Kenya is a digital recordkeeping and group treasury management platform. Operates in accordance with the Kenya Data Protection Act (2019) and Microfinance Act (Table Banking guidelines).
          </p>
        </div>
      </div>
    </div>
  );
};
