import React, { useState } from 'react';
import { 
  Users, UserPlus, Share2, Download, Search, 
  Phone, Mail, Shield, CheckCircle, X, ChevronRight 
} from 'lucide-react';
import { Chama, Language, Member, UserRole } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';

interface MembersViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
}

export const MembersView: React.FC<MembersViewProps> = ({
  activeChama,
  currentRole,
  language,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [members, setMembers] = useState<Member[]>(storage.getMembers(activeChama.id));

  React.useEffect(() => {
    setMembers(storage.getMembers(activeChama.id));
  }, [activeChama.id]);

  // Add Member Form
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('07');
  const [newRole, setNewRole] = useState<UserRole>('member');
  const [newEmail, setNewEmail] = useState('');

  const filteredMembers = members.filter(
    (m) =>
      m.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.phone.includes(searchQuery) ||
      m.memberNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const inviteText = `Habari! You are invited to join our group *${activeChama.name}* on ChamaSmart Kenya.\n` +
    `Chama Code: *${activeChama.inviteCode}*\n` +
    `Meeting Schedule: ${activeChama.meetingSchedule}\n` +
    `Join here: https://chamasmart.ke/join?code=${activeChama.inviteCode}`;

  const whatsappInviteUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(inviteText)}`;

  const handleExportCsv = () => {
    const headers = ['Member No', 'Full Name', 'Phone', 'Role', 'Savings (KES)', 'Welfare (KES)', 'Loan Balance', 'Attendance %'];
    const rows = members.map((m) => [
      m.memberNumber,
      `"${m.fullName}"`,
      m.phone,
      m.role,
      m.totalSavings,
      m.totalWelfare,
      m.outstandingLoanBalance,
      `${m.attendanceRate}%`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${activeChama.name.replace(/\s+/g, '_')}_Members.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const added = storage.addMember(activeChama.id, {
      fullName: newName.trim(),
      phone: newPhone.trim(),
      role: newRole,
      email: newEmail.trim() || undefined,
    });

    setMembers(storage.getMembers(activeChama.id));
    setShowAddModal(false);
    setNewName('');
    setNewPhone('07');
  };

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Header Banner */}
      <div className="bg-emerald-950 text-white p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Chama Member Directory</h2>
            <p className="text-xs text-emerald-300">
              {members.length} Registered Members · Invite: {activeChama.inviteCode}
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <a
              href={whatsappInviteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-emerald-700 hover:bg-emerald-600 text-white p-2 rounded-xl text-xs flex items-center gap-1"
              title="Share Invite on WhatsApp"
            >
              <Share2 size={16} />
            </a>
            <button
              onClick={() => setShowAddModal(true)}
              className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center gap-1 shadow-sm"
            >
              <UserPlus size={16} />
              <span>Add</span>
            </button>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-3">
        {/* Search & Export bar */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search member name, phone..."
              className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-700"
            />
          </div>
          <button
            onClick={handleExportCsv}
            className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 p-2 rounded-xl text-xs flex items-center gap-1 flex-shrink-0"
            title="Export CSV"
          >
            <Download size={16} />
            <span className="hidden sm:inline">CSV</span>
          </button>
        </div>

        {/* Members List */}
        <div className="space-y-2">
          {filteredMembers.map((member) => (
            <div
              key={member.id}
              className="bg-white rounded-2xl border border-slate-200 p-3 hover:border-emerald-300 transition-all shadow-xs space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                    {member.fullName.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-bold text-xs text-slate-900">{member.fullName}</h4>
                      <span className="text-[10px] text-slate-400 font-mono">
                        ({member.memberNumber})
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-mono">{member.phone}</p>
                  </div>
                </div>

                <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                  {member.role}
                </span>
              </div>

              {/* Financial snapshot */}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-center text-xs">
                <div className="bg-slate-50 p-1.5 rounded-lg">
                  <span className="text-[10px] text-slate-400">Savings</span>
                  <p className="font-bold text-slate-900 font-mono text-[11px]">
                    {formatKES(member.totalSavings)}
                  </p>
                </div>
                <div className="bg-slate-50 p-1.5 rounded-lg">
                  <span className="text-[10px] text-slate-400">Welfare</span>
                  <p className="font-bold text-emerald-700 font-mono text-[11px]">
                    {formatKES(member.totalWelfare)}
                  </p>
                </div>
                <div className="bg-slate-50 p-1.5 rounded-lg">
                  <span className="text-[10px] text-slate-400">Debt/Loan</span>
                  <p
                    className={`font-bold font-mono text-[11px] ${
                      member.outstandingLoanBalance > 0 ? 'text-amber-700' : 'text-slate-400'
                    }`}
                  >
                    {formatKES(member.outstandingLoanBalance)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Member Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden p-4 space-y-3 text-slate-800">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900">Add New Chama Member</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddMember} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Kennedy Kiprono"
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Kenyan Phone</label>
                <input
                  type="tel"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="0712345678"
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-mono"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Assigned Role</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as any)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                >
                  <option value="member">Ordinary Member</option>
                  <option value="treasurer">Treasurer</option>
                  <option value="secretary">Secretary</option>
                  <option value="auditor">Auditor</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Email (Optional)</label>
                <input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-slate-100 text-slate-700 font-semibold py-2 px-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl"
                >
                  Save Member
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
