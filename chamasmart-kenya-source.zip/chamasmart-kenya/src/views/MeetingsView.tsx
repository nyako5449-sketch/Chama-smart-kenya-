import React, { useState } from 'react';
import { 
  Calendar, Clock, MapPin, CheckSquare, Vote, 
  Share2, Plus, FileText, CheckCircle2, ChevronRight, X 
} from 'lucide-react';
import { Chama, Language, Meeting, UserRole } from '../types';
import { storage } from '../services/storageService';

interface MeetingsViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
}

export const MeetingsView: React.FC<MeetingsViewProps> = ({
  activeChama,
  currentRole,
  language,
}) => {
  const [meetings, setMeetings] = useState<Meeting[]>(storage.getMeetings(activeChama.id));
  const [selectedMeeting, setSelectedMeeting] = useState<Meeting | null>(meetings[0] || null);

  React.useEffect(() => {
    const list = storage.getMeetings(activeChama.id);
    setMeetings(list);
    setSelectedMeeting(list[0] || null);
  }, [activeChama.id]);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const currentUser = storage.getCurrentUser();

  // Schedule Modal State
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('2026-11-07');
  const [newTime, setNewTime] = useState('14:00');
  const [newVenue, setNewVenue] = useState('St. Paul Community Hall');

  const handleVote = (pollId: string, optionId: string) => {
    if (!selectedMeeting) return;
    storage.voteOnPoll(activeChama.id, selectedMeeting.id, pollId, optionId, currentUser.id);
    const updatedMeetings = storage.getMeetings(activeChama.id);
    setMeetings(updatedMeetings);
    const curr = updatedMeetings.find((m) => m.id === selectedMeeting.id);
    if (curr) setSelectedMeeting(curr);
  };

  const getNoticeUrl = (meeting: Meeting) => {
    const text = `*CHAMA MEETING NOTICE: ${activeChama.name.toUpperCase()}*\n` +
      `Date: ${meeting.date}\n` +
      `Time: ${meeting.startTime} - ${meeting.endTime}\n` +
      `Venue: ${meeting.venue}\n\n` +
      `*Agenda:*\n` +
      meeting.agenda.map((a, i) => `${i + 1}. ${a.title} (${a.durationMinutes}m)`).join('\n') +
      `\n\n_Please confirm attendance on ChamaSmart Kenya_`;
    return `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
  };

  const handleScheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const created = storage.createMeeting({
      chamaId: activeChama.id,
      title: newTitle.trim(),
      date: newDate,
      startTime: newTime,
      endTime: '16:30',
      venue: newVenue,
      isVirtual: false,
      agenda: [
        { id: `ag_${Date.now()}_1`, title: 'Opening Prayer & Chairperson Welcome', durationMinutes: 15, presenter: 'Chairperson' },
        { id: `ag_${Date.now()}_2`, title: 'Table Banking Savings & Loan Collections', durationMinutes: 45, presenter: 'Treasurer' },
        { id: `ag_${Date.now()}_3`, title: 'Welfare Report & Emergency Cases', durationMinutes: 20, presenter: 'Secretary' },
      ],
      minutes: 'Draft pending meeting conclusion...',
      isMinutesPublished: false,
      attendance: [],
      actionItems: [],
      polls: [],
    });

    const updated = storage.getMeetings(activeChama.id);
    setMeetings(updated);
    setSelectedMeeting(created);
    setShowScheduleModal(false);
    setNewTitle('');
  };

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Top Banner */}
      <div className="bg-emerald-950 text-white p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Meetings & Resolutions</h2>
            <p className="text-xs text-emerald-300">
              {activeChama.name} · {meetings.length} Scheduled Sessions
            </p>
          </div>
          <button
            onClick={() => setShowScheduleModal(true)}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center gap-1 shadow-sm"
          >
            <Plus size={16} />
            <span>Schedule</span>
          </button>
        </div>
      </div>

      <div className="px-4 space-y-3">
        {/* Meeting selector tabs */}
        <div className="space-y-2">
          {meetings.map((m) => {
            const isSelected = selectedMeeting?.id === m.id;
            return (
              <div
                key={m.id}
                onClick={() => setSelectedMeeting(m)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer shadow-xs ${
                  isSelected
                    ? 'bg-emerald-50 border-emerald-600 ring-1 ring-emerald-600'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-xs text-slate-900">{m.title}</h4>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
                      <span className="flex items-center gap-1">
                        <Calendar size={12} className="text-emerald-700" />
                        {m.date}
                      </span>
                      <span>·</span>
                      <span className="flex items-center gap-1">
                        <Clock size={12} className="text-emerald-700" />
                        {m.startTime} - {m.endTime}
                      </span>
                    </div>
                  </div>
                  <a
                    href={getNoticeUrl(m)}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg flex items-center justify-center"
                    title="Share via WhatsApp"
                  >
                    <Share2 size={14} />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Meeting Details */}
        {selectedMeeting && (
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-1.5 text-xs text-slate-600">
                <MapPin size={14} className="text-emerald-700" />
                <span className="font-medium">{selectedMeeting.venue}</span>
              </div>
              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                {selectedMeeting.isMinutesPublished ? 'Minutes Published' : 'Agenda Draft'}
              </span>
            </div>

            {/* Agendas */}
            <div className="space-y-2">
              <h5 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
                Meeting Agendas
              </h5>
              <div className="space-y-1.5">
                {selectedMeeting.agenda.map((item, idx) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 rounded-xl bg-slate-50 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-[10px]">
                        {idx + 1}
                      </span>
                      <span className="font-medium text-slate-800">{item.title}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {item.durationMinutes}m ({item.presenter.split(' ')[0]})
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Live Voting Polls */}
            {selectedMeeting.polls.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs">
                  <Vote size={14} />
                  <span>Live Chama Member Poll</span>
                </div>
                {selectedMeeting.polls.map((poll) => {
                  const hasVoted = poll.votedUserIds.includes(currentUser.id);
                  const totalVotes = poll.options.reduce((s, o) => s + o.voteCount, 0);

                  return (
                    <div key={poll.id} className="bg-amber-50/60 border border-amber-200/80 rounded-xl p-3 space-y-2">
                      <p className="font-semibold text-xs text-slate-900">{poll.question}</p>
                      <div className="space-y-1.5">
                        {poll.options.map((opt) => {
                          const pct = totalVotes > 0 ? Math.round((opt.voteCount / totalVotes) * 100) : 0;
                          return (
                            <button
                              key={opt.id}
                              disabled={hasVoted}
                              onClick={() => handleVote(poll.id, opt.id)}
                              className="w-full text-left p-2 rounded-lg bg-white border border-slate-200 hover:border-amber-400 transition-all text-xs relative overflow-hidden"
                            >
                              <div
                                className="absolute inset-0 bg-amber-200/30 transition-all"
                                style={{ width: `${pct}%` }}
                              />
                              <div className="relative flex justify-between items-center">
                                <span className="font-medium text-slate-800">{opt.text}</span>
                                <span className="font-mono text-[11px] font-bold text-amber-900">
                                  {pct}% ({opt.voteCount})
                                </span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                      <p className="text-[10px] text-slate-500 italic text-right">
                        {hasVoted ? '✓ Your vote is recorded' : 'Click an option to cast your vote'}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Action Items */}
            {selectedMeeting.actionItems.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <h5 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
                  Agreed Action Items
                </h5>
                <div className="space-y-1.5">
                  {selectedMeeting.actionItems.map((act) => (
                    <div
                      key={act.id}
                      className="flex items-center justify-between p-2 rounded-xl bg-slate-50 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle2
                          size={14}
                          className={act.completed ? 'text-emerald-600' : 'text-slate-300'}
                        />
                        <span className={act.completed ? 'line-through text-slate-400' : 'text-slate-800'}>
                          {act.task}
                        </span>
                      </div>
                      <span className="text-[10px] font-medium text-slate-500">
                        Assigned: {act.assignedTo}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Minutes Summary */}
            {selectedMeeting.minutes && (
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <h5 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
                  Official Minutes Summary
                </h5>
                <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl leading-relaxed">
                  {selectedMeeting.minutes}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Schedule Meeting Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden p-4 space-y-3 text-slate-800">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900">Schedule Chama Meeting</h3>
              <button onClick={() => setShowScheduleModal(false)} className="text-slate-400">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleScheduleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Meeting Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. November Table Banking & Loan Draw"
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Time</label>
                  <input
                    type="time"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Venue / Physical Location</label>
                <input
                  type="text"
                  value={newVenue}
                  onChange={(e) => setNewVenue(e.target.value)}
                  placeholder="e.g. St. Paul Catholic Hall or Zoom Link"
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="flex-1 bg-slate-100 text-slate-700 font-semibold py-2 px-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl"
                >
                  Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
