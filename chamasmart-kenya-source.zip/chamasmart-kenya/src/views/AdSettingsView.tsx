import React, { useState } from 'react';
import { 
  Shield, Check, AlertTriangle, Sparkles, Sliders, 
  DollarSign, Eye, RefreshCw, Smartphone, Award, ExternalLink 
} from 'lucide-react';
import { AdMobConfig, Chama, Language, UserRole } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';

interface AdSettingsViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
  onAdConfigUpdated: () => void;
  onOpenTestInterstitial: () => void;
  onOpenTestRewarded: () => void;
}

export const AdSettingsView: React.FC<AdSettingsViewProps> = ({
  activeChama,
  currentRole,
  language,
  onAdConfigUpdated,
  onOpenTestInterstitial,
  onOpenTestRewarded,
}) => {
  const [config, setConfig] = useState<AdMobConfig>(storage.getAdMobConfig());
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isUpgrading, setIsUpgrading] = useState(false);

  const handleToggle = (key: keyof AdMobConfig) => {
    const updated = { ...config, [key]: !config[key] };
    setConfig(updated);
    storage.saveAdMobConfig(updated);
    onAdConfigUpdated();
  };

  const handlePlacementToggle = (placement: keyof AdMobConfig['bannerPlacements']) => {
    const updated = {
      ...config,
      bannerPlacements: {
        ...config.bannerPlacements,
        [placement]: !config.bannerPlacements[placement],
      },
    };
    setConfig(updated);
    storage.saveAdMobConfig(updated);
    onAdConfigUpdated();
  };

  const handleSave = () => {
    storage.saveAdMobConfig(config);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
    onAdConfigUpdated();
  };

  const handleUpgradeToPro = () => {
    setIsUpgrading(true);
    setTimeout(() => {
      activeChama.isPremium = true;
      storage.saveChamas(storage.getChamas().map((c) => (c.id === activeChama.id ? { ...c, isPremium: true } : c)));
      setIsUpgrading(false);
      onAdConfigUpdated();
    }, 1000);
  };

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Sliders size={18} />
            </div>
            <div>
              <h2 className="text-base font-bold">Google AdMob Management</h2>
              <p className="text-xs text-slate-400">Admin Advertising & Monetization Controls</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-3 text-xs text-slate-800">
        {savedSuccess && (
          <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl flex items-center gap-2">
            <Check size={16} />
            <span>Advertising settings saved successfully.</span>
          </div>
        )}

        {/* Pro Ad-Free Subscription Banner */}
        <div className="bg-gradient-to-r from-amber-600 to-amber-700 text-white p-4 rounded-2xl shadow-md space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase font-bold tracking-wider bg-white/20 px-2 py-0.5 rounded">
              ChamaSmart Pro
            </span>
            <span className="font-bold text-sm">KSh 499 / Month</span>
          </div>
          <h4 className="font-extrabold text-sm">Ad-Free Experience for Entire Chama</h4>
          <p className="text-[11px] text-amber-100 leading-snug">
            Remove all banner, interstitial, and sponsored native ads for all {activeChama.name} members while unlocking unlimited PDF exports.
          </p>
          <button
            onClick={handleUpgradeToPro}
            disabled={activeChama.isPremium || isUpgrading}
            className={`w-full py-2 px-3 rounded-xl font-bold text-xs transition-all ${
              activeChama.isPremium
                ? 'bg-emerald-900 text-emerald-100 cursor-default'
                : 'bg-white hover:bg-amber-50 text-slate-950 active:scale-98'
            }`}
          >
            {activeChama.isPremium
              ? '✓ Currently Active (Ad-Free Active)'
              : isUpgrading
              ? 'Activating Pro Plan...'
              : 'Upgrade to Ad-Free Pro (KSh 499)'}
          </button>
        </div>

        {/* Aggregated Analytics Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-xs space-y-2">
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
            AdMob Monetization Performance
          </h4>
          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-500">Total Impressions</span>
              <p className="font-bold text-sm text-slate-900 font-mono mt-0.5">
                {config.totalImpressions}
              </p>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-500">Est. Chama Revenue</span>
              <p className="font-bold text-sm text-emerald-700 font-mono mt-0.5">
                {formatKES(config.estimatedRevenueKes)}
              </p>
            </div>
          </div>
          <p className="text-[10px] text-slate-400 italic">
            *Revenue based on Kenyan regional eCPM (~KSh 0.18/impression). Real earnings depend on Google Play approval and advertiser demand.
          </p>
        </div>

        {/* Global Controls & Test Mode */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-xs space-y-3">
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
            Global Switches
          </h4>

          <div className="flex items-center justify-between py-1 border-b border-slate-100">
            <div>
              <p className="font-semibold text-slate-900">Enable Google AdMob</p>
              <p className="text-[11px] text-slate-500">Master switch for all advertising modules</p>
            </div>
            <input
              type="checkbox"
              checked={config.enabled}
              onChange={() => handleToggle('enabled')}
              className="w-4 h-4 text-emerald-600 rounded"
            />
          </div>

          <div className="flex items-center justify-between py-1 border-b border-slate-100">
            <div>
              <p className="font-semibold text-slate-900">Test Ad Mode</p>
              <p className="text-[11px] text-slate-500">Use official Google Mobile Ads test IDs</p>
            </div>
            <input
              type="checkbox"
              checked={config.testMode}
              onChange={() => handleToggle('testMode')}
              className="w-4 h-4 text-emerald-600 rounded"
            />
          </div>
        </div>

        {/* Ad Formats */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-xs space-y-3">
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
            Ad Format Controls
          </h4>

          <div className="flex items-center justify-between py-1 border-b border-slate-100">
            <div>
              <p className="font-semibold text-slate-900">Adaptive Banner Ads</p>
              <p className="text-[11px] text-slate-500">Non-intrusive bottom banners</p>
            </div>
            <input
              type="checkbox"
              checked={config.bannerEnabled}
              onChange={() => handleToggle('bannerEnabled')}
              className="w-4 h-4 text-emerald-600 rounded"
            />
          </div>

          <div className="flex items-center justify-between py-1 border-b border-slate-100">
            <div>
              <p className="font-semibold text-slate-900">Native In-Feed Ads</p>
              <p className="text-[11px] text-slate-500">Group insurance and banking sponsors</p>
            </div>
            <input
              type="checkbox"
              checked={config.nativeEnabled}
              onChange={() => handleToggle('nativeEnabled')}
              className="w-4 h-4 text-emerald-600 rounded"
            />
          </div>

          <div className="flex items-center justify-between py-1 border-b border-slate-100">
            <div>
              <p className="font-semibold text-slate-900">Rewarded Video Ads</p>
              <p className="text-[11px] text-slate-500">Opt-in unlock for Solvency Audit reports</p>
            </div>
            <input
              type="checkbox"
              checked={config.rewardedEnabled}
              onChange={() => handleToggle('rewardedEnabled')}
              className="w-4 h-4 text-emerald-600 rounded"
            />
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <p className="font-semibold text-slate-900">Interstitial Ads</p>
              <p className="text-[11px] text-slate-500">Used strictly on non-financial screens</p>
            </div>
            <input
              type="checkbox"
              checked={config.interstitialEnabled}
              onChange={() => handleToggle('interstitialEnabled')}
              className="w-4 h-4 text-emerald-600 rounded"
            />
          </div>
        </div>

        {/* Live Test Trigger Buttons */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-xs space-y-2.5">
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
            Test Ad Unit Previews
          </h4>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onOpenTestInterstitial}
              className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-semibold text-xs flex items-center justify-center gap-1.5"
            >
              <Smartphone size={14} />
              <span>Test Interstitial Ad</span>
            </button>
            <button
              onClick={onOpenTestRewarded}
              className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-semibold text-xs flex items-center justify-center gap-1.5"
            >
              <Award size={14} />
              <span>Test Rewarded Ad</span>
            </button>
          </div>
        </div>

        {/* Official Google Test Unit IDs */}
        <div className="bg-slate-900 text-slate-200 p-3.5 rounded-2xl space-y-2 font-mono text-[10px]">
          <p className="font-bold text-amber-400 text-xs">Official Google AdMob Test Unit IDs</p>
          <div className="truncate">Banner: {config.testAdUnitIds.banner}</div>
          <div className="truncate">Interstitial: {config.testAdUnitIds.interstitial}</div>
          <div className="truncate">Rewarded: {config.testAdUnitIds.rewarded}</div>
          <div className="truncate">Native: {config.testAdUnitIds.native}</div>
        </div>
      </div>
    </div>
  );
};
