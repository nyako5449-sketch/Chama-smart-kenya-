import React, { useState } from 'react';
import { 
  Plus, Search, Filter, Smartphone, CheckCircle, 
  Clock, AlertCircle, FileText, Share2 
} from 'lucide-react';
import { Chama, Contribution, Language, UserRole } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';

interface ContributionsViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
  onOpenStkPush: () => void;
  onSelectContributionForReceipt: (c: Contribution) => void;
}

export const ContributionsView: React.FC<ContributionsViewProps> = ({
  activeChama,
  currentRole,
  language,
  onOpenStkPush,
  onSelectContributionForReceipt,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'savings' | 'welfare' | 'pending'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [contributions, setContributions] = useState<Contribution[]>(
    storage.getContributions(activeChama.id)
  );

  React.useEffect(() => {
    setContributions(storage.getContributions(activeChama.id));
  }, [activeChama.id]);

  const currentUser = storage.getCurrentUser();

  const handleReconcile = (e: React.MouseEvent, c: Contribution) => {
    e.stopPropagation();
    storage.reconcileContribution(activeChama.id, c.id, currentUser.fullName);
    setContributions(storage.getContributions(activeChama.id));
  };

  const filtered = contributions.filter((c) => {
    const matchesSearch =
      c.memberName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.paymentReference.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.receiptNumber.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (filterType === 'savings') return c.type === 'savings';
    if (filterType === 'welfare') return c.type === 'welfare';
    if (filterType === 'pending') return c.status === 'pending_reconciliation';
    return true;
  });

  const totalCollected = contributions
    .filter((c) => c.status === 'confirmed')
    .reduce((sum, c) => sum + c.amount, 0);

  const pendingCount = contributions.filter((c) => c.status === 'pending_reconciliation').length;

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Top Banner Header */}
      <div className="bg-emerald-950 text-white p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Contributions & Savings</h2>
            <p className="text-xs text-emerald-300">
              {activeChama.name} · {activeChama.contributionFrequency} cycle
            </p>
          </div>
          <button
            onClick={onOpenStkPush}
            className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center gap-1.5 shadow-sm transition-all"
          >
            <Plus size={16} />
            <span>Record Payment</span>
          </button>
        </div>

        {/* Quick summary stats */}
        <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
          <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-800">
            <span className="text-[10px] text-emerald-300">Total Confirmed</span>
            <p className="font-bold text-sm font-mono mt-0.5">{formatKES(totalCollected)}</p>
          </div>
          <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-800">
            <span className="text-[10px] text-emerald-300">Pending Verification</span>
            <p className="font-bold text-sm font-mono mt-0.5 text-amber-300">{pendingCount} Transactions</p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-3">
        {/* Search & Filters */}
        <div className="relative">
          <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search member, M-Pesa ref (e.g. SIK...)"
            className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          />
        </div>

        {/* Segmented Filter Controls */}
        <div className="flex bg-slate-200/80 p-1 rounded-xl text-xs gap-1">
          <button
            onClick={() => setFilterType('all')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              filterType === 'all' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilterType('savings')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              filterType === 'savings' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Savings
          </button>
          <button
            onClick={() => setFilterType('welfare')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              filterType === 'welfare' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Welfare
          </button>
          <button
            onClick={() => setFilterType('pending')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              filterType === 'pending' ? 'bg-white text-amber-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Pending ({pendingCount})
          </button>
        </div>

        {/* Transactions List */}
        <div className="space-y-2">
          {filtered.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center text-slate-400 border border-slate-200">
              <FileText size={32} className="mx-auto mb-2 opacity-50" />
              <p className="text-xs">No contributions match your filter.</p>
            </div>
          ) : (
            filtered.map((c) => (
              <div
                key={c.id}
                onClick={() => onSelectContributionForReceipt(c)}
                className="bg-white rounded-2xl border border-slate-200 p-3 hover:border-emerald-300 transition-all cursor-pointer shadow-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-900">{c.memberName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      · {new Date(c.createdAt).toLocaleDateString('en-GB')}
                    </span>
                  </div>
                  <span className="font-bold text-xs font-mono text-emerald-900">
                    +{formatKES(c.amount)}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                  <div className="flex items-center gap-1.5">
                    <span className="capitalize font-medium text-slate-700">{c.type}</span>
                    <span>·</span>
                    <span className="font-mono text-slate-600 uppercase text-[10px] bg-slate-100 px-1.5 py-0.5 rounded">
                      {c.paymentReference}
                    </span>
                  </div>

                  {c.status === 'confirmed' ? (
                    <span className="text-emerald-700 font-medium flex items-center gap-1 text-[10px]">
                      <CheckCircle size={12} />
                      <span>Confirmed</span>
                    </span>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="text-amber-700 font-medium flex items-center gap-1 text-[10px]">
                        <Clock size={12} />
                        <span>Pending</span>
                      </span>
                      {(currentRole === 'treasurer' || currentRole === 'chairperson' || currentRole === 'super_admin') && (
                        <button
                          onClick={(e) => handleReconcile(e, c)}
                          className="bg-emerald-700 hover:bg-emerald-800 text-white text-[10px] font-bold px-2 py-1 rounded-lg"
                        >
                          Reconcile
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
