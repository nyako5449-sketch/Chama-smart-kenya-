import React, { useState } from 'react';
import { 
  Landmark, Plus, CheckCircle, Clock, AlertCircle, 
  ChevronRight, Calendar, UserCheck, Smartphone, CheckCheck 
} from 'lucide-react';
import { Chama, Language, Loan, UserRole } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';

interface LoansViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
  onOpenLoanCalculator: () => void;
  onOpenLoanApproval: (loan: Loan) => void;
  onRefreshData: () => void;
}

export const LoansView: React.FC<LoansViewProps> = ({
  activeChama,
  currentRole,
  language,
  onOpenLoanCalculator,
  onOpenLoanApproval,
  onRefreshData,
}) => {
  const [filterTab, setFilterTab] = useState<'active' | 'pending' | 'settled'>('active');
  const [repayingLoan, setRepayingLoan] = useState<Loan | null>(null);
  const [repayAmount, setRepayAmount] = useState<number>(5500);

  const loans = storage.getLoans(activeChama.id);
  const currentUser = storage.getCurrentUser();

  const activeLoans = loans.filter((l) => l.approvalStatus === 'disbursed');
  const pendingLoans = loans.filter((l) => l.approvalStatus === 'pending' || l.approvalStatus === 'chair_approved');
  const settledLoans = loans.filter((l) => l.approvalStatus === 'settled');

  const totalOutstanding = activeLoans.reduce((sum, l) => sum + l.balanceRemaining, 0);
  const totalInterestCollected = loans.reduce((sum, l) => sum + (l.totalInterest || 0), 0);

  const displayedLoans =
    filterTab === 'active'
      ? activeLoans
      : filterTab === 'pending'
      ? pendingLoans
      : settledLoans;

  const handleQuickRepay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!repayingLoan) return;

    storage.recordLoanRepayment({
      loanId: repayingLoan.id,
      chamaId: activeChama.id,
      memberId: repayingLoan.memberId,
      memberName: repayingLoan.memberName,
      amount: repayAmount,
      paymentMethod: 'mpesa',
      paymentReference: `REP-MPESA-${Date.now().toString().slice(-6)}`,
      recordedBy: currentUser.fullName,
    });

    setRepayingLoan(null);
    onRefreshData();
  };

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Top Banner */}
      <div className="bg-emerald-950 text-white p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Loan Portfolio & Credit</h2>
            <p className="text-xs text-emerald-300">
              {activeChama.name} · {activeChama.loanInterestMethod.replace('_', ' ')}
            </p>
          </div>
          <button
            onClick={onOpenLoanCalculator}
            className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center gap-1.5 shadow-sm transition-all"
          >
            <Plus size={16} />
            <span>Apply Loan</span>
          </button>
        </div>

        {/* Portfolio Stats */}
        <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
          <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-800">
            <span className="text-[10px] text-emerald-300">Total Outstanding</span>
            <p className="font-bold text-sm font-mono mt-0.5 text-amber-300">{formatKES(totalOutstanding)}</p>
          </div>
          <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-800">
            <span className="text-[10px] text-emerald-300">Interest Yield</span>
            <p className="font-bold text-sm font-mono mt-0.5 text-emerald-100">{formatKES(totalInterestCollected)}</p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-3">
        {/* Segmented Tab */}
        <div className="flex bg-slate-200/80 p-1 rounded-xl text-xs gap-1">
          <button
            onClick={() => setFilterTab('active')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              filterTab === 'active' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Active ({activeLoans.length})
          </button>
          <button
            onClick={() => setFilterTab('pending')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              filterTab === 'pending' ? 'bg-white text-amber-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Pending ({pendingLoans.length})
          </button>
          <button
            onClick={() => setFilterTab('settled')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              filterTab === 'settled' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Settled ({settledLoans.length})
          </button>
        </div>

        {/* Loans List */}
        <div className="space-y-3">
          {displayedLoans.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center text-slate-400 border border-slate-200">
              <Landmark size={32} className="mx-auto mb-2 opacity-50" />
              <p className="text-xs">No loans in this category.</p>
            </div>
          ) : (
            displayedLoans.map((loan) => {
              const isOverdue = loan.schedule?.some((s) => s.status === 'overdue');
              const canApprove =
                (currentRole === 'chairperson' && !loan.chairApprovedBy) ||
                (currentRole === 'treasurer' && !loan.treasurerApprovedBy) ||
                currentRole === 'super_admin';

              return (
                <div
                  key={loan.id}
                  className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3 hover:border-emerald-300 transition-all"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-xs text-slate-900">{loan.memberName}</h4>
                      <p className="text-[11px] text-slate-500">{loan.purpose}</p>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        loan.approvalStatus === 'disbursed'
                          ? isOverdue
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-emerald-100 text-emerald-800'
                          : loan.approvalStatus === 'settled'
                          ? 'bg-slate-100 text-slate-700'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {loan.approvalStatus === 'disbursed'
                        ? isOverdue
                          ? 'In Arrears'
                          : 'Disbursed'
                        : loan.approvalStatus.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>

                  {/* Financial Balance Bar */}
                  <div className="bg-slate-50 rounded-xl p-2.5 text-xs space-y-1.5 border border-slate-100">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Remaining Balance:</span>
                      <span className="font-mono font-bold text-slate-900">
                        {formatKES(loan.balanceRemaining)}
                      </span>
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>Total Repayable:</span>
                      <span className="font-mono text-slate-700">{formatKES(loan.totalPayable)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>Monthly Installment:</span>
                      <span className="font-mono text-slate-700 font-semibold">{formatKES(loan.monthlyInstallment)} / mo</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden mt-1">
                      <div
                        className="bg-emerald-600 h-full rounded-full"
                        style={{
                          width: `${Math.min(
                            100,
                            ((loan.amountPaid || 0) / (loan.totalPayable || 1)) * 100
                          )}%`,
                        }}
                      />
                    </div>
                  </div>

                  {/* Guarantors */}
                  <div className="text-[11px] text-slate-500 flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <UserCheck size={12} className="text-emerald-700" />
                      <span>
                        Guarantors: {loan.guarantors.map((g) => g.memberName.split(' ')[0]).join(', ')}
                      </span>
                    </div>
                    <span className="text-slate-400 font-mono text-[10px]">
                      {loan.durationMonths} Mos @ {loan.interestRatePercent}%
                    </span>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-2 border-t border-slate-100 flex gap-2">
                    {loan.approvalStatus !== 'disbursed' && loan.approvalStatus !== 'settled' && (
                      <button
                        onClick={() => onOpenLoanApproval(loan)}
                        className="flex-1 bg-amber-600 hover:bg-amber-700 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle size={14} />
                        <span>Review & Dual Sign</span>
                      </button>
                    )}

                    {loan.approvalStatus === 'disbursed' && (
                      <button
                        onClick={() => {
                          setRepayingLoan(loan);
                          setRepayAmount(loan.monthlyInstallment);
                        }}
                        className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5"
                      >
                        <Smartphone size={14} />
                        <span>Record Repayment ({formatKES(loan.monthlyInstallment)})</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Quick Repayment Dialog Modal */}
      {repayingLoan && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden p-4 space-y-3 text-slate-800">
            <h3 className="font-bold text-sm text-slate-900">
              Record Loan Repayment
            </h3>
            <p className="text-xs text-slate-500">
              For {repayingLoan.memberName} · Balance: {formatKES(repayingLoan.balanceRemaining)}
            </p>

            <form onSubmit={handleQuickRepay} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Repayment Amount (KES)
                </label>
                <input
                  type="number"
                  max={repayingLoan.balanceRemaining}
                  value={repayAmount}
                  onChange={(e) => setRepayAmount(Number(e.target.value))}
                  className="w-full border border-slate-300 rounded-xl p-2.5 font-bold text-sm font-mono"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRepayingLoan(null)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2 px-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl"
                >
                  Confirm Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
