import React, { useState } from 'react';
import { 
  BookOpen, Plus, Landmark, Wallet, Smartphone, 
  ArrowRight, ShieldCheck, CheckCircle2, Clock, X 
} from 'lucide-react';
import { Chama, Expense, Language, LedgerEntry, UserRole } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';

interface LedgerExpensesViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
}

export const LedgerExpensesView: React.FC<LedgerExpensesViewProps> = ({
  activeChama,
  currentRole,
  language,
}) => {
  const [tab, setTab] = useState<'ledger' | 'expenses'>('ledger');
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>(
    storage.getLedger(activeChama.id)
  );
  const [expenses, setExpenses] = useState<Expense[]>(
    storage.getExpenses(activeChama.id)
  );

  React.useEffect(() => {
    setLedgerEntries(storage.getLedger(activeChama.id));
    setExpenses(storage.getExpenses(activeChama.id));
  }, [activeChama.id]);

  const currentUser = storage.getCurrentUser();

  // Expense form
  const [expTitle, setExpTitle] = useState('');
  const [expCategory, setExpCategory] = useState<Expense['category']>('meeting_refreshments');
  const [expAmount, setExpAmount] = useState<number>(1500);
  const [expPaidTo, setExpPaidTo] = useState('');
  const [expAccount, setExpAccount] = useState<'cash' | 'bank' | 'mpesa_paybill'>('cash');
  const [expDesc, setExpDesc] = useState('');

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expTitle.trim() || expAmount <= 0) return;

    storage.recordExpense({
      chamaId: activeChama.id,
      title: expTitle.trim(),
      category: expCategory,
      amount: expAmount,
      paidTo: expPaidTo.trim() || 'Vendor',
      paidFromAccount: expAccount,
      status: 'approved',
      approvedBy: currentUser.fullName,
      description: expDesc.trim(),
      date: new Date().toISOString().split('T')[0],
    });

    setExpenses(storage.getExpenses(activeChama.id));
    setLedgerEntries(storage.getLedger(activeChama.id));
    setShowAddExpense(false);
    setExpTitle('');
    setExpDesc('');
  };

  const members = storage.getMembers(activeChama.id);
  const totalSavings = members.reduce((s, m) => s + m.totalSavings, 0);
  const totalWelfare = members.reduce((s, m) => s + m.totalWelfare, 0);
  const loans = storage.getLoans(activeChama.id);
  const activeLoansBal = loans.filter((l) => l.approvalStatus === 'disbursed').reduce((s, l) => s + l.balanceRemaining, 0);

  const totalApprovedExpenses = expenses
    .filter((e) => e.status === 'approved')
    .reduce((s, e) => s + e.amount, 0);
  const totalLiquid = Math.max(0, totalSavings + totalWelfare - activeLoansBal - totalApprovedExpenses);
  const mpesaFloat = Math.round(totalLiquid * 0.35);
  const bankBalance = Math.round(totalLiquid * 0.55);
  const cashInHand = Math.max(0, totalLiquid - mpesaFloat - bankBalance);

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Header Banner */}
      <div className="bg-emerald-950 text-white p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Financial Ledger & Accounts</h2>
            <p className="text-xs text-emerald-300">
              {activeChama.name} · Double-Entry Audited
            </p>
          </div>
          <button
            onClick={() => setShowAddExpense(true)}
            className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center gap-1 shadow-sm"
          >
            <Plus size={16} />
            <span>Record Expense</span>
          </button>
        </div>
      </div>

      <div className="px-4 space-y-3">
        {/* Account Balances Summary Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-xs space-y-2.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800">
            <span>Verified Liquidity Balances</span>
            <span className="text-[10px] font-normal text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-mono">
              Balanced Ledger
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-500">Cash in Hand</span>
              <p className="font-bold text-slate-900 font-mono text-xs mt-0.5">
                {formatKES(cashInHand)}
              </p>
            </div>
            <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-500">Bank Account</span>
              <p className="font-bold text-emerald-900 font-mono text-xs mt-0.5">
                {formatKES(bankBalance)}
              </p>
            </div>
            <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-500">M-Pesa Float</span>
              <p className="font-bold text-emerald-800 font-mono text-xs mt-0.5">
                {formatKES(mpesaFloat)}
              </p>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex bg-slate-200/80 p-1 rounded-xl text-xs gap-1">
          <button
            onClick={() => setTab('ledger')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              tab === 'ledger' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Double-Entry Ledger ({ledgerEntries.length})
          </button>
          <button
            onClick={() => setTab('expenses')}
            className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
              tab === 'expenses' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
            }`}
          >
            Expenses ({expenses.length})
          </button>
        </div>

        {/* Tab 1: Ledger Journal Entries */}
        {tab === 'ledger' && (
          <div className="space-y-2">
            {ledgerEntries.map((entry) => (
              <div
                key={entry.id}
                className="bg-white rounded-2xl border border-slate-200 p-3 shadow-xs space-y-2 hover:border-emerald-300 transition-all text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-slate-800">{entry.reference}</span>
                  <span className="font-mono font-black text-slate-900">
                    {formatKES(entry.amount)}
                  </span>
                </div>

                <p className="text-slate-600 text-xs">{entry.narration}</p>

                {/* Double entry accounts */}
                <div className="flex items-center justify-between text-[11px] bg-slate-50 p-2 rounded-lg font-mono">
                  <div className="text-emerald-800">
                    <span className="font-semibold">Dr: </span>
                    <span className="capitalize">{entry.debitAccount.replace(/_/g, ' ')}</span>
                  </div>
                  <ArrowRight size={12} className="text-slate-400" />
                  <div className="text-amber-800">
                    <span className="font-semibold">Cr: </span>
                    <span className="capitalize">{entry.creditAccount.replace(/_/g, ' ')}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-100">
                  <span>Audited by {entry.recordedBy}</span>
                  <span className="font-mono">{new Date(entry.timestamp).toLocaleDateString('en-GB')}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Expenses List */}
        {tab === 'expenses' && (
          <div className="space-y-2">
            {expenses.map((exp) => (
              <div
                key={exp.id}
                className="bg-white rounded-2xl border border-slate-200 p-3 shadow-xs space-y-2 text-xs"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900">{exp.title}</h4>
                    <p className="text-[11px] text-slate-500">Paid to: {exp.paidTo}</p>
                  </div>
                  <span className="font-mono font-bold text-rose-700">
                    -{formatKES(exp.amount)}
                  </span>
                </div>

                {exp.description && (
                  <p className="text-[11px] text-slate-600 italic bg-slate-50 p-2 rounded-lg">
                    "{exp.description}"
                  </p>
                )}

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                  <span className="capitalize font-medium text-slate-700">
                    {exp.category.replace('_', ' ')}
                  </span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1 text-[10px]">
                    <CheckCircle2 size={12} />
                    Approved ({exp.approvedBy?.split(' ')[0]})
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Expense Modal */}
      {showAddExpense && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden p-4 space-y-3 text-slate-800">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900">Record Chama Expense</h3>
              <button onClick={() => setShowAddExpense(false)} className="text-slate-400">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddExpense} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Expense Title</label>
                <input
                  type="text"
                  value={expTitle}
                  onChange={(e) => setExpTitle(e.target.value)}
                  placeholder="e.g. Refreshments for table banking meeting"
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Amount (KES)</label>
                  <input
                    type="number"
                    value={expAmount}
                    onChange={(e) => setExpAmount(Number(e.target.value))}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-semibold"
                    required
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Category</label>
                  <select
                    value={expCategory}
                    onChange={(e) => setExpCategory(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value="meeting_refreshments">Venue & Refreshments</option>
                    <option value="welfare_benevolence">Welfare Benevolence</option>
                    <option value="bank_charges">Bank Charges</option>
                    <option value="administrative">Administrative</option>
                    <option value="legal_audit">Legal & Audit</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Paid To</label>
                  <input
                    type="text"
                    value={expPaidTo}
                    onChange={(e) => setExpPaidTo(e.target.value)}
                    placeholder="Vendor / Payee"
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Source Account</label>
                  <select
                    value={expAccount}
                    onChange={(e) => setExpAccount(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-white"
                  >
                    <option value="cash">Cash in Hand</option>
                    <option value="bank">Bank Account</option>
                    <option value="mpesa_paybill">M-Pesa Float</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Narration / Details</label>
                <textarea
                  rows={2}
                  value={expDesc}
                  onChange={(e) => setExpDesc(e.target.value)}
                  placeholder="Additional context or receipt details"
                  className="w-full border border-slate-300 rounded-xl p-2 text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddExpense(false)}
                  className="flex-1 bg-slate-100 text-slate-700 font-semibold py-2 px-3 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl"
                >
                  Post to Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
