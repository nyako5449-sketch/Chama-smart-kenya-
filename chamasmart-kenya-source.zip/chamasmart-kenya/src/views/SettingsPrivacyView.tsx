import React, { useState } from 'react';
import { 
  ShieldCheck, Lock, Download, Trash2, Globe, 
  HelpCircle, Check, AlertCircle, FileCode2, User 
} from 'lucide-react';
import { Language, User as UserType, UserRole } from '../types';
import { storage } from '../services/storageService';

interface SettingsPrivacyViewProps {
  language: Language;
  onToggleLanguage: () => void;
  onOpenDevDocs: () => void;
  onRefreshData: () => void;
}

export const SettingsPrivacyView: React.FC<SettingsPrivacyViewProps> = ({
  language,
  onToggleLanguage,
  onOpenDevDocs,
  onRefreshData,
}) => {
  const [currentUser, setCurrentUser] = useState<UserType>(storage.getCurrentUser());
  const [name, setName] = useState(currentUser.fullName);
  const [email, setEmail] = useState(currentUser.email);
  const [nationalId, setNationalId] = useState(currentUser.nationalId);
  const [phone, setPhone] = useState(currentUser.phone);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [consentAnalytics, setConsentAnalytics] = useState(true);
  const [consentAds, setConsentAds] = useState(true);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserType = {
      ...currentUser,
      fullName: name.trim(),
      email: email.trim(),
      nationalId: nationalId.trim(),
      phone: phone.trim(),
    };
    storage.setCurrentUser(updated);
    setCurrentUser(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
    onRefreshData();
  };

  const handleExportData = () => {
    const activeChama = storage.getActiveChama();
    const myContributions = storage.getContributions(activeChama.id).filter((c) => c.memberPhone === currentUser.phone);
    const myLoans = storage.getLoans(activeChama.id).filter((l) => l.memberPhone === currentUser.phone);
    
    const exportBundle = {
      user: currentUser,
      exportTimestamp: new Date().toISOString(),
      compliance: 'Kenya Data Protection Act, 2019 - Section 26 (Right to Access & Portability)',
      contributions: myContributions,
      loans: myLoans,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportBundle, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ChamaSmart_Data_Export_${currentUser.phone.replace('+', '')}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const [confirmAction, setConfirmAction] = useState<'reset' | 'delete' | null>(null);

  const executeConfirmedAction = () => {
    if (confirmAction === 'reset' || confirmAction === 'delete') {
      storage.resetAllData();
      onRefreshData();
      setConfirmAction(null);
      setSavedSuccess(true);
      setTimeout(() => {
        window.location.reload();
      }, 500);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Header Banner */}
      <div className="bg-emerald-950 text-white p-4">
        <h2 className="text-base font-bold">Profile, Privacy & Settings</h2>
        <p className="text-xs text-emerald-300">
          Account Preferences & Kenya DPA 2019 Compliance
        </p>
      </div>

      <div className="px-4 space-y-3 text-xs text-slate-800">
        {savedSuccess && (
          <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl flex items-center gap-2">
            <Check size={16} />
            <span>Profile information updated successfully.</span>
          </div>
        )}

        {/* Profile Card Form */}
        <form onSubmit={handleSaveProfile} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
          <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm">
              {currentUser.fullName.charAt(0)}
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-900">{currentUser.fullName}</h4>
              <p className="text-[11px] text-slate-500 font-mono">{currentUser.phone}</p>
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Full Legal Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Phone (+254)</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-mono"
                required
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">National ID</label>
              <input
                type="text"
                value={nationalId}
                onChange={(e) => setNationalId(e.target.value)}
                className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-mono"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-slate-300 rounded-xl p-2.5 text-xs"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 px-3 rounded-xl transition-all"
          >
            Update Profile
          </button>
        </form>

        {/* Kenya DPA 2019 Compliance Center */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <ShieldCheck size={18} className="text-emerald-700" />
            <div>
              <h4 className="font-bold text-xs text-slate-900">
                Data Protection & Privacy (Kenya DPA 2019)
              </h4>
              <p className="text-[10px] text-slate-500">
                Office of the Data Protection Commissioner (ODPC) Standards
              </p>
            </div>
          </div>

          <p className="text-[11px] text-slate-600 leading-relaxed">
            In compliance with the Data Protection Act (No. 24 of 2019), ChamaSmart Kenya ensures all financial records, member IDs, and loan data remain strictly confidential. Private financial data is never sold or used for ad targeting.
          </p>

          <div className="space-y-2 pt-1 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-800">Non-Personalized Ads Consent</p>
                <p className="text-[10px] text-slate-500">Google User Messaging Platform (UMP)</p>
              </div>
              <input
                type="checkbox"
                checked={consentAds}
                onChange={() => setConsentAds(!consentAds)}
                className="w-4 h-4 text-emerald-600 rounded"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-800">Audit & Diagnostic Telemetry</p>
                <p className="text-[10px] text-slate-500">For double-entry error detection</p>
              </div>
              <input
                type="checkbox"
                checked={consentAnalytics}
                onChange={() => setConsentAnalytics(!consentAnalytics)}
                className="w-4 h-4 text-emerald-600 rounded"
              />
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 flex gap-2">
            <button
              onClick={handleExportData}
              className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all text-xs"
            >
              <Download size={14} />
              <span>Export My Data (JSON)</span>
            </button>
          </div>
        </div>

        {/* Developer Documentation & Deliverable Specs Button */}
        <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode2 size={18} className="text-amber-400" />
              <h4 className="font-bold text-xs">Technical Deliverables & Docs</h4>
            </div>
            <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-mono">
              v1.0.0 Architecture
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-snug">
            View full Android architecture, Daraja API 2.0 integration guide, database schema, and Google Play release checklist.
          </p>
          <button
            onClick={onOpenDevDocs}
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all"
          >
            <span>Open Technical Architecture & Deliverables</span>
          </button>
        </div>

        {/* Danger Zone: Reset Data & Account Deletion */}
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 space-y-2.5">
          <h4 className="font-bold text-xs text-rose-900 uppercase tracking-wider">
            Data Governance & Maintenance
          </h4>
          <div className="flex gap-2">
            <button
              onClick={() => setConfirmAction('reset')}
              className="flex-1 bg-white border border-rose-300 text-rose-800 font-semibold py-2 px-2.5 rounded-xl text-xs hover:bg-rose-100"
            >
              Reset Demo Seeds
            </button>
            <button
              onClick={() => setConfirmAction('delete')}
              className="flex-1 bg-rose-700 hover:bg-rose-800 text-white font-bold py-2 px-2.5 rounded-xl text-xs flex items-center justify-center gap-1"
            >
              <Trash2 size={13} />
              <span>Delete Account (DPA)</span>
            </button>
          </div>
        </div>
      </div>

      {/* In-App Confirmation Modal */}
      {confirmAction && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-4 text-slate-900 space-y-3 shadow-2xl">
            <h3 className="font-bold text-sm text-rose-900">
              {confirmAction === 'reset' ? 'Reset All Data to Demo Seeds?' : 'Delete Account (Kenya DPA 2019)?'}
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              {confirmAction === 'reset'
                ? 'This will restore all Chamas, contributions, loans, and meetings back to default Kenyan demo groups.'
                : 'Under Kenya DPA 2019, your identity and credentials will be expunged. Required statutory audit records will be anonymized.'}
            </p>
            <div className="flex gap-2 pt-1">
              <button
                onClick={() => setConfirmAction(null)}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2 px-3 rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                onClick={executeConfirmedAction}
                className="flex-1 bg-rose-700 hover:bg-rose-800 text-white font-bold py-2 px-3 rounded-xl text-xs"
              >
                Yes, Proceed
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
