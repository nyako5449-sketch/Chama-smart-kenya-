import React, { useState } from 'react';
import { 
  BarChart3, PieChart, TrendingUp, Download, Printer, 
  Sparkles, Award, ShieldCheck, ArrowUpRight 
} from 'lucide-react';
import { Chama, Language, UserRole } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';
import { AdMobBanner } from '../components/AdMobBanner';

interface ReportsViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
  onOpenRewardedAd: () => void;
  isRewardUnlocked: boolean;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  activeChama,
  currentRole,
  language,
  onOpenRewardedAd,
  isRewardUnlocked,
}) => {
  const members = storage.getMembers(activeChama.id);
  const contributions = storage.getContributions(activeChama.id);
  const loans = storage.getLoans(activeChama.id);
  const expenses = storage.getExpenses(activeChama.id);

  const totalSavings = members.reduce((s, m) => s + m.totalSavings, 0);
  const totalWelfare = members.reduce((s, m) => s + m.totalWelfare, 0);
  const totalLoansOutstanding = loans
    .filter((l) => l.approvalStatus === 'disbursed')
    .reduce((s, l) => s + l.balanceRemaining, 0);
  const totalExpenses = expenses
    .filter((e) => e.status === 'approved')
    .reduce((s, e) => sum(s, e.amount), 0);
  const totalInterestEarned = loans.reduce((s, l) => s + (l.totalInterest || 0), 0);

  function sum(a: number, b: number) {
    return a + b;
  }

  // Monthly breakdown mockup data
  const monthlyData = [
    { month: 'Jun', savings: 48000, loans: 30000 },
    { month: 'Jul', savings: 52000, loans: 40000 },
    { month: 'Aug', savings: 55000, loans: 25000 },
    { month: 'Sep', savings: 59000, loans: 35000 },
    { month: 'Oct', savings: 63000, loans: 20000 },
  ];

  const handleExportStatement = () => {
    const netWorth = totalSavings + totalWelfare + totalInterestEarned - totalExpenses;
    const csvContent = 'data:text/csv;charset=utf-8,' + [
      `Chama Financial Statement - ${activeChama.name}`,
      `Generated Date,${new Date().toISOString()}`,
      `Group County,${activeChama.county}`,
      '',
      'Account Line,Amount (KES)',
      `Total Member Savings (Equity),${totalSavings}`,
      `Welfare & Emergency Reserve,${totalWelfare}`,
      `Active Loans Principal Receivable,${totalLoansOutstanding}`,
      `Total Interest Income Collected,${totalInterestEarned}`,
      `Operating Expenses Paid,${totalExpenses}`,
      `Net Chama Assets & Group Worth,${netWorth}`
    ].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${activeChama.name.replace(/\s+/g, '_')}_Financial_Statement.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-3.5">
      {/* Header Banner */}
      <div className="bg-emerald-950 text-white p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Financial Reports & Statements</h2>
            <p className="text-xs text-emerald-300">
              {activeChama.name} · Annual Audit Trail
            </p>
          </div>
          <button
            onClick={handleExportStatement}
            className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center gap-1.5 shadow-sm"
          >
            <Printer size={15} />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      <div className="px-4 space-y-3">
        {/* Rewarded Solvency Audit Card */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-4 rounded-2xl shadow-md border border-slate-700 space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center">
                <Award size={20} />
              </div>
              <div>
                <h4 className="font-bold text-xs">Chama Solvency & Compliance Score</h4>
                <p className="text-[11px] text-slate-400">Kenya SACCO & CBO Standard</p>
              </div>
            </div>
            {isRewardUnlocked ? (
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 border border-emerald-700 px-2 py-0.5 rounded-full font-mono">
                SCORE: 94/100 (A+)
              </span>
            ) : (
              <button
                onClick={onOpenRewardedAd}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] px-2.5 py-1 rounded-lg flex items-center gap-1"
              >
                <Sparkles size={12} />
                <span>Unlock (6s)</span>
              </button>
            )}
          </div>

          {isRewardUnlocked ? (
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-700 text-center text-xs">
              <div className="bg-slate-800/80 p-2 rounded-xl">
                <span className="text-[10px] text-slate-400">Liquidity Ratio</span>
                <p className="font-bold text-emerald-400 font-mono mt-0.5">1.82x</p>
              </div>
              <div className="bg-slate-800/80 p-2 rounded-xl">
                <span className="text-[10px] text-slate-400">Recovery Rate</span>
                <p className="font-bold text-emerald-400 font-mono mt-0.5">96.8%</p>
              </div>
              <div className="bg-slate-800/80 p-2 rounded-xl">
                <span className="text-[10px] text-slate-400">Risk Level</span>
                <p className="font-bold text-emerald-400 font-mono mt-0.5">Low</p>
              </div>
            </div>
          ) : (
            <p className="text-[11px] text-slate-300 leading-snug">
              Unlock a full regulatory solvency score including repayment velocity, loan default risk exposure, and liquidity coverage ratio.
            </p>
          )}
        </div>

        {/* Balance Sheet Summary */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
            Statement of Assets & Equity
          </h4>

          <div className="space-y-2 text-xs divide-y divide-slate-100">
            <div className="flex justify-between py-1.5">
              <span className="text-slate-600">Total Member Savings (Equity):</span>
              <span className="font-mono font-bold text-slate-900">{formatKES(totalSavings)}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-600">Welfare & Emergency Reserve:</span>
              <span className="font-mono font-bold text-emerald-800">{formatKES(totalWelfare)}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-600">Active Loans Principal (Receivable):</span>
              <span className="font-mono font-bold text-amber-800">{formatKES(totalLoansOutstanding)}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-600">Total Cumulative Interest Yield:</span>
              <span className="font-mono font-bold text-emerald-700">{formatKES(totalInterestEarned)}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-600">Total Operating Expenses:</span>
              <span className="font-mono font-bold text-rose-700">-{formatKES(totalExpenses)}</span>
            </div>
            <div className="flex justify-between py-2 border-t-2 border-slate-900 font-bold text-slate-900">
              <span>Total Chama Net Worth:</span>
              <span className="font-mono text-emerald-950 text-sm">
                {formatKES(totalSavings + totalWelfare + totalInterestEarned - totalExpenses)}
              </span>
            </div>
          </div>
        </div>

        {/* Monthly Trend Visual Bar Chart */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
            Monthly Savings Growth Trend
          </h4>

          <div className="space-y-2 pt-2">
            {monthlyData.map((d) => (
              <div key={d.month} className="space-y-1">
                <div className="flex justify-between text-xs text-slate-600">
                  <span className="font-bold text-slate-800">{d.month} 2026</span>
                  <span className="font-mono text-emerald-900 font-semibold">{formatKES(d.savings)}</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full rounded-full"
                    style={{ width: `${(d.savings / 70000) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AdMob Banner at bottom of Reports */}
        <AdMobBanner placement="reportsBottom" />
      </div>
    </div>
  );
};
