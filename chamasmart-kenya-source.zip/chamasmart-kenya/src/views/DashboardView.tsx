import React, { useState } from 'react';
import { 
  ArrowUpRight, ArrowDownRight, Wallet, Landmark, 
  HeartHandshake, AlertCircle, PlusCircle, Sparkles, 
  Receipt, ArrowRight, ShieldCheck, ChevronRight 
} from 'lucide-react';
import { Chama, Contribution, Language, Loan, UserRole } from '../types';
import { formatKES } from '../services/calculations';
import { storage } from '../services/storageService';
import { AdMobBanner } from '../components/AdMobBanner';
import { AdMobNativeCard } from '../components/AdMobNativeCard';

interface DashboardViewProps {
  activeChama: Chama;
  currentRole: UserRole;
  language: Language;
  onOpenStkPush: () => void;
  onOpenLoanCalculator: () => void;
  onNavigateTab: (tab: any) => void;
  onSelectContributionForReceipt: (c: Contribution) => void;
  onOpenAdMobRewarded: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  activeChama,
  currentRole,
  language,
  onOpenStkPush,
  onOpenLoanCalculator,
  onNavigateTab,
  onSelectContributionForReceipt,
  onOpenAdMobRewarded,
}) => {
  const members = storage.getMembers(activeChama.id);
  const contributions = storage.getContributions(activeChama.id);
  const loans = storage.getLoans(activeChama.id);
  const expenses = storage.getExpenses(activeChama.id);

  // Financial aggregates
  const totalSavings = members.reduce((sum, m) => sum + (m.totalSavings || 0), 0);
  const totalWelfare = members.reduce((sum, m) => sum + (m.totalWelfare || 0), 0);
  const activeLoans = loans.filter((l) => l.approvalStatus === 'disbursed');
  const totalLoansOutstanding = activeLoans.reduce((sum, l) => sum + (l.balanceRemaining || 0), 0);
  const totalExpenses = expenses
    .filter((e) => e.status === 'approved')
    .reduce((sum, e) => sum + e.amount, 0);

  // Group Account Balances derived dynamically
  const totalLiquid = Math.max(0, totalSavings + totalWelfare - totalLoansOutstanding - totalExpenses);
  const mpesaFloat = Math.round(totalLiquid * 0.35);
  const bankBalance = Math.round(totalLiquid * 0.55);
  const cashInHand = Math.max(0, totalLiquid - mpesaFloat - bankBalance);

  // Overdue loans check
  const overdueLoans = loans.filter((l) =>
    l.schedule?.some((s) => s.status === 'overdue')
  );

  return (
    <div className="flex-1 overflow-y-auto pb-6 space-y-4">
      {/* Top Hero Balance Card */}
      <div className="bg-gradient-to-b from-emerald-950 via-emerald-900 to-emerald-900 text-white p-5 rounded-b-3xl shadow-lg relative overflow-hidden">
        {/* Subtle patterned background */}
        <div className="absolute -right-8 -bottom-8 w-44 h-44 rounded-full bg-emerald-700/20 blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between text-xs text-emerald-300 mb-1">
          <span className="font-semibold uppercase tracking-wider text-[11px]">
            Total Net Group Savings
          </span>
          <span className="bg-emerald-800/80 text-emerald-200 px-2 py-0.5 rounded-full text-[10px] font-mono">
            {members.length} Active Members
          </span>
        </div>

        <div className="flex items-baseline gap-2 mt-1">
          <h2 className="text-3xl font-extrabold tracking-tight text-white font-mono">
            {formatKES(totalSavings)}
          </h2>
        </div>

        {/* Financial Sub-Metrics Pills */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-emerald-800/70 text-center">
          <div className="bg-emerald-900/60 p-2 rounded-xl">
            <p className="text-[10px] text-emerald-300">Welfare Kitty</p>
            <p className="text-xs font-bold text-white font-mono mt-0.5">
              {formatKES(totalWelfare)}
            </p>
          </div>
          <div className="bg-emerald-900/60 p-2 rounded-xl">
            <p className="text-[10px] text-emerald-300">Active Loans</p>
            <p className="text-xs font-bold text-amber-300 font-mono mt-0.5">
              {formatKES(totalLoansOutstanding)}
            </p>
          </div>
          <div className="bg-emerald-900/60 p-2 rounded-xl">
            <p className="text-[10px] text-emerald-300">Bank & Float</p>
            <p className="text-xs font-bold text-emerald-100 font-mono mt-0.5">
              {formatKES(bankBalance + mpesaFloat)}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="px-4">
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={onOpenStkPush}
            className="bg-emerald-800 hover:bg-emerald-900 active:scale-98 text-white p-3.5 rounded-2xl flex items-center gap-3 shadow-sm transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-700/80 flex items-center justify-center flex-shrink-0 text-amber-400">
              <ArrowDownRight size={22} />
            </div>
            <div className="text-left">
              <p className="text-xs font-bold leading-tight">M-Pesa STK</p>
              <p className="text-[11px] text-emerald-200">Pay Monthly Share</p>
            </div>
          </button>

          <button
            onClick={onOpenLoanCalculator}
            className="bg-slate-900 hover:bg-slate-800 active:scale-98 text-white p-3.5 rounded-2xl flex items-center gap-3 shadow-sm transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center flex-shrink-0 text-emerald-400">
              <Landmark size={22} />
            </div>
            <div className="text-left">
              <p className="text-xs font-bold leading-tight">Apply Loan</p>
              <p className="text-[11px] text-slate-300">10% Table Banking</p>
            </div>
          </button>
        </div>
      </div>

      {/* Arrears or Actionable Alert (If any) */}
      {overdueLoans.length > 0 && (
        <div className="px-4">
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center flex-shrink-0 mt-0.5">
              <AlertCircle size={18} />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold text-amber-900">
                1 Member Loan Installment Overdue
              </h4>
              <p className="text-[11px] text-amber-800 mt-0.5 leading-snug">
                {overdueLoans[0].memberName} has 1 overdue installment of {formatKES(11000)}. Automatic late fee of KSh 550 applied.
              </p>
              <button
                onClick={() => onNavigateTab('loans')}
                className="mt-1.5 text-[11px] font-bold text-amber-900 hover:underline flex items-center gap-1"
              >
                <span>View Loan Details & Guarantors</span>
                <ChevronRight size={12} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chama Solvency Rewarded Audit Hook */}
      <div className="px-4">
        <div className="bg-gradient-to-r from-teal-900 to-emerald-950 text-white rounded-2xl p-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center">
              <Sparkles size={18} />
            </div>
            <div>
              <p className="text-xs font-bold">Chama Credit & Solvency Score</p>
              <p className="text-[11px] text-teal-200">
                SACCO compliance & liquidity ratio: 94% (A+)
              </p>
            </div>
          </div>
          <button
            onClick={onOpenAdMobRewarded}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold py-1.5 px-3 rounded-xl flex-shrink-0 transition-transform active:scale-95"
          >
            Audit Report
          </button>
        </div>
      </div>

      {/* Recent Contributions Section */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Recent Contributions
          </h3>
          <button
            onClick={() => onNavigateTab('transactions')}
            className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight size={14} />
          </button>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-xs">
          {contributions.slice(0, 4).map((c) => (
            <div
              key={c.id}
              onClick={() => onSelectContributionForReceipt(c)}
              className="p-3 hover:bg-slate-50 transition-colors flex items-center justify-between cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold ${
                    c.status === 'confirmed'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {c.memberName.charAt(0)}
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">{c.memberName}</p>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                    <span className="capitalize">{c.type}</span>
                    <span>·</span>
                    <span className="font-mono text-emerald-700">{c.paymentReference}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <p className="text-xs font-bold text-slate-900 font-mono">
                  +{formatKES(c.amount)}
                </p>
                <span
                  className={`inline-block text-[10px] font-semibold ${
                    c.status === 'confirmed' ? 'text-emerald-700' : 'text-amber-700'
                  }`}
                >
                  {c.status === 'confirmed' ? 'Confirmed' : 'Pending Review'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Native Sponsored Card (Compliant non-intrusive) */}
      <div className="px-4">
        <AdMobNativeCard category="insurance" />
      </div>

      {/* AdMob Test Banner Placement at bottom of Dashboard */}
      <AdMobBanner placement="dashboardBottom" />
    </div>
  );
};
