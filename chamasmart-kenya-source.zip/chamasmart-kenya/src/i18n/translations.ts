import { Language } from '../types';

export const translations = {
  en: {
    appName: 'ChamaSmart Kenya',
    tagline: 'Empowering Kenyan Savings Groups & Table Banking',
    dashboard: 'Dashboard',
    contributions: 'Contributions',
    loans: 'Loans',
    members: 'Members',
    meetings: 'Meetings',
    ledger: 'Ledger',
    reports: 'Reports',
    more: 'More',
    settings: 'Settings',
    privacy: 'Data Privacy (DPA 2019)',
    adSettings: 'AdMob Settings',
    developerDocs: 'Developer Docs & Specs',
    
    // Financial Terms
    totalSavings: 'Total Group Savings',
    activeLoans: 'Active Loans Balance',
    cashInHand: 'Cash in Hand',
    bankBalance: 'Bank Account Balance',
    mpesaFloat: 'M-Pesa Float Balance',
    welfareKitty: 'Welfare / Emergency Kitty',
    totalExpenses: 'Total Expenses',
    netGroupWealth: 'Total Net Group Worth',
    monthlyTarget: 'Monthly Savings Target',
    reconciliationStatus: 'Reconciled Ledger',
    
    // Actions
    recordPayment: 'Record Contribution',
    applyLoan: 'Apply for Loan',
    disburseLoan: 'Disburse Loan',
    repayLoan: 'Make Repayment',
    scheduleMeeting: 'Schedule Meeting',
    newExpense: 'Record Expense',
    exportReport: 'Export Statement',
    switchChama: 'Switch Chama',
    createChama: 'Create New Chama',
    inviteMember: 'Invite Members',
    sendStkPush: 'M-Pesa STK Push',
    manualReconcile: 'Reconcile SMS / Bank',
    viewReceipt: 'View Receipt',
    downloadPdf: 'Download PDF',
    shareWhatsapp: 'Share via WhatsApp',
    
    // Status
    confirmed: 'Confirmed',
    pending: 'Pending Review',
    overdue: 'Overdue',
    approved: 'Approved',
    rejected: 'Rejected',
    disbursed: 'Disbursed',
    settled: 'Fully Settled',
    
    // Roles
    super_admin: 'Super Administrator',
    chairperson: 'Chairperson',
    treasurer: 'Treasurer',
    secretary: 'Secretary',
    member: 'Ordinary Member',
    auditor: 'Auditor / Reviewer',
    
    // Quick labels
    online: 'Online (Synced)',
    offline: 'Offline Mode (Local Queue)',
    testAdBadge: 'Google AdMob Test Unit',
    adFreeNotice: 'Upgrade to ChamaSmart Pro for an Ad-Free Experience',
  },
  sw: {
    appName: 'ChamaSmart Kenya',
    tagline: 'Kuwezesha Vikundi vya Akiba na Benki ya Mezani Kenya',
    dashboard: 'Dashibodi',
    contributions: 'Michango',
    loans: 'Mikopo',
    members: 'Wanachama',
    meetings: 'Mikutano',
    ledger: 'Daftari la Fedha',
    reports: 'Ripoti za Fedha',
    more: 'Mengineyo',
    settings: 'Mipangilio',
    privacy: 'Faragha na Sheria ya Data (DPA 2019)',
    adSettings: 'Mipangilio ya Matangazo (AdMob)',
    developerDocs: 'Mwongozo wa Kiufundi',
    
    // Financial Terms
    totalSavings: 'Jumla ya Akiba ya Chama',
    activeLoans: 'Deni la Mikopo Iliyotolewa',
    cashInHand: 'Pesa Mkononi (Taslimu)',
    bankBalance: 'Salio la Akaunti ya Benki',
    mpesaFloat: 'Salio la M-Pesa / Paybill',
    welfareKitty: 'Hazina ya Ustawi na Dharura',
    totalExpenses: 'Jumla ya Gharama',
    netGroupWealth: 'Thamani Kamili ya Chama',
    monthlyTarget: 'Lengo la Michango Mwezi Huu',
    reconciliationStatus: 'Daftari Lililosuluhishwa',
    
    // Actions
    recordPayment: 'Weka Mchango Mpya',
    applyLoan: 'Omba Mkopo',
    disburseLoan: 'Toa Mkopo',
    repayLoan: 'Lipa Mkopo',
    scheduleMeeting: 'Panga Mkutano',
    newExpense: 'Rekodi Matumizi',
    exportReport: 'Pakua Taarifa ya Fedha',
    switchChama: 'Badilisha Chama',
    createChama: 'Fungua Chama Kipya',
    inviteMember: 'Alika Mwanachama',
    sendStkPush: 'Malipo ya M-Pesa (STK Push)',
    manualReconcile: 'Suluhisha kwa SMS / Benki',
    viewReceipt: 'Angalia Risiti',
    downloadPdf: 'Pakua PDF',
    shareWhatsapp: 'Tuma kwa WhatsApp',
    
    // Status
    confirmed: 'Imethibitishwa',
    pending: 'Inasubiri Uhakiki',
    overdue: 'Imechelewa',
    approved: 'Imeidhinishwa',
    rejected: 'Imekataliwa',
    disbursed: 'Imetolewa',
    settled: 'Imelipwa Kamili',
    
    // Roles
    super_admin: 'Msimamizi Mkuu',
    chairperson: 'Mwenyekiti',
    treasurer: 'Mweka Hazina',
    secretary: 'Katibu',
    member: 'Mwanachama wa Kawaida',
    auditor: 'Mkaguzi wa Hesabu',
    
    // Quick labels
    online: 'Mtandaoni (Imesawazishwa)',
    offline: 'Bila Mtandao (Foleni ya Simu)',
    testAdBadge: 'Tangazo la Majaribio (AdMob)',
    adFreeNotice: 'Boresha hadi ChamaSmart Pro ili uondoe matangazo',
  }
};

export function getTranslation(lang: Language) {
  return translations[lang] || translations.en;
}
