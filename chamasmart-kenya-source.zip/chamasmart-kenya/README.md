# ChamaSmart Kenya (ke.chamasmart.app)

> **Complete Android-First Digital Chama, Table Banking & Savings Group Platform**  
> Built with React 19, TypeScript, Tailwind CSS v4, Capacitor 8 Android Engine, and Automated Cloud APK Builder.

[![Android App](https://img.shields.io/badge/package-ke.chamasmart.app-green.svg)](https://chamasmart.ke)
[![Currency](https://img.shields.io/badge/currency-KES%20%2F%20KSh-emerald.svg)](https://chamasmart.ke)
[![Android Build](https://img.shields.io/badge/build-GitHub%20Actions%20(Free)-blue.svg)](https://github.com)
[![Compliance](https://img.shields.io/badge/compliance-Kenya%20DPA%202019-teal.svg)](https://chamasmart.ke)

---

## 📱 1. Technology Stack Breakdown

This application uses a hybrid architecture optimized for Android smartphones:

| Component | Technology | Version / Details |
|---|---|---|
| **Frontend Framework** | React (Modular Functional Components & Hooks) | `^19.0.1` |
| **Language** | TypeScript (Strict type checks) | `^7.0.2` |
| **Build Tool & Bundler** | Vite (Ultra-fast ESM bundling) | `^8.3.0` |
| **Styling** | Tailwind CSS (Modern utility CSS) | `^4.3.3` |
| **Icons & Motion** | Lucide React & Motion (Smooth native-feeling animations) | `0.546.0` / `12.23.24` |
| **Mobile Native Bridge** | Capacitor Native Android Bridge | `^8.5.3` |
| **Native Android Platform** | Android Studio Gradle Project (`/android`) | Android SDK 34 / Java 17 |
| **Application ID** | `ke.chamasmart.app` | Min SDK 24 (Android 7.0+) |
| **Cloud APK Builder** | GitHub Actions Workflow (`.github/workflows/build-apk.yml`) | Ubuntu Runner (100% Free) |

---

## 📦 2. Downloadable Source ZIP

The complete repository is packaged as a ready-to-use archive:
- **Direct Download URL**: `https://ais-pre-55mdt2d5mgi2l6pkw3nbdn-432883725025.europe-west3.run.app/chamasmart-kenya-source.zip`
- **File size**: ~0.55 MB (120 files)
- **Folder inside zip**: `chamasmart-kenya/`

---

## 📲 3. How to Build an Installable Android APK from Your Phone (Zero Computer, KSh 0 Budget)

You do **not** need a laptop or computer. You can build a real, installable Android APK (`.apk`) using **GitHub Actions** directly through Google Chrome or any browser on your Android phone for free.

### Step-by-Step Mobile Instructions:

#### Step A: Create a Free GitHub Account
1. Open Chrome on your phone and go to [github.com](https://github.com).
2. Sign up for a free account (or sign in).

#### Step B: Create a New Repository
1. In the top right corner of GitHub on your phone, tap the `+` icon $\rightarrow$ **New repository**.
2. Name it: `chamasmart-kenya`.
3. Set visibility to **Public** (or **Private**). Free public repositories have **unlimited free GitHub Actions minutes**; private repositories include 2,000 free minutes per month.
4. Tap **Create repository**.

#### Step C: Upload the Project Files
- **Option 1 (Using GitHub Web Upload on phone)**:
  1. Download `chamasmart-kenya-source.zip` onto your phone.
  2. Use your phone's file manager (Files by Google, ZArchiver, or default My Files) to extract the ZIP.
  3. On your GitHub repo page, tap **"uploading an existing file"** or use the GitHub web interface / Git app (such as *MGit* or *Termux* from F-Droid).
- **Option 2 (Using Termux on Android - Recommended for fast 1-command push)**:
  1. Install **Termux** from F-Droid (free, open source terminal for Android).
  2. In Termux, type:
     ```bash
     pkg update && pkg install git
     cd /sdcard/Download/chamasmart-kenya
     git init
     git add .
     git commit -m "Initial ChamaSmart commit"
     git branch -M main
     git remote add origin https://github.com/<your-username>/chamasmart-kenya.git
     git push -u origin main
     ```

#### Step D: Let GitHub Build Your APK (Automated)
1. Because the project includes `.github/workflows/build-apk.yml`, GitHub automatically starts the build immediately upon push!
2. To watch or manually run it:
   - On GitHub in your phone browser, tap the **Actions** tab.
   - Tap **"Build Android APK (ChamaSmart Kenya)"**.
   - Tap **"Run workflow"** if triggering manually.
3. The Ubuntu cloud runner will:
   - Set up Java 17 and Node.js 20.
   - Run `npm install` and `npm run build`.
   - Run `npx cap sync android`.
   - Run `./gradlew assembleDebug` using the Android SDK.
   - Produce `app-debug.apk`.
4. The build completes in approximately 2 to 3 minutes.

#### Step E: Download & Install the APK on Your Phone
1. Tap the completed green checkmark run in the **Actions** tab.
2. Scroll down to the **Artifacts** section at the bottom.
3. Tap **ChamaSmart-Kenya-Debug-APK** to download the ZIP containing your `app-debug.apk`.
4. Open the downloaded file, tap `app-debug.apk`, and tap **Install**.
   *(If prompted by Android, allow "Install unknown apps" for Chrome or your file manager).*
5. ChamaSmart Kenya is now running as a standalone native app on your phone!

---

## 💻 4. Local Build Instructions (If You Ever Have Access to a Computer)

If you have a computer with Node.js and Android Studio:

```bash
# 1. Unzip the project and navigate inside
cd chamasmart-kenya

# 2. Install dependencies
npm install

# 3. Test in local web browser
npm run dev

# 4. Build web production bundle
npm run build

# 5. Sync Capacitor Android bridge
npx cap sync android

# 6. Open in Android Studio
npx cap open android

# 7. Or build APK directly via command line:
cd android
./gradlew assembleDebug
# The APK will be at: android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 🚀 5. Publishing to Uptodown

Uptodown is an independent Android app store used by over 100 million users worldwide.

### Requirements for Uptodown:
1. **Developer Account**: Free registration at [Uptodown Developer Zone](https://developers.uptodown.com/publish).
2. **Package Name**: Pre-configured as `ke.chamasmart.app`.
3. **App Information**:
   - Title: `ChamaSmart Kenya`
   - Version: `1.0.0`
   - Min SDK: Android 7.0 (API 24)
   - Category: `Finance / Management`
4. **Privacy Policy Link**:
   ```text
   https://ais-pre-55mdt2d5mgi2l6pkw3nbdn-432883725025.europe-west3.run.app/privacy.html
   ```
5. **Softonic PAD XML Feed**:
   ```text
   https://ais-pre-55mdt2d5mgi2l6pkw3nbdn-432883725025.europe-west3.run.app/pad_file.xml
   ```

### ⚠️ Important: Debug APK vs. Signed Release APK
- **Debug APK (`app-debug.apk`)**:
  - Signed with Android's default debug key.
  - Installs and runs on any Android phone for testing and group demos.
  - Most app stores (including Google Play and Uptodown production tiers) require a **Signed Release APK (`app-release.apk`)**.
- **How to create a Signed Release APK without a PC**:
  - You can generate a free keystore using GitHub Actions secrets (`KEYSTORE_FILE`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`) and have GitHub Actions run `./gradlew assembleRelease`.
  - Alternatively, free Android apps like *ZipSigner* or *APK Signer* (available on Google Play / F-Droid) can sign an APK directly on your phone!

---

## 🔍 6. Project Completeness & Secrets Audit

### Included in This ZIP:
- ✅ **100% Complete Source Code**: All UI views, components, services, and models.
- ✅ **Kenyan Financial Engine**: Table banking, loans, double-entry ledger, receipt generator, meeting polls, and attendance registers.
- ✅ **Native Android Bridge**: Complete Gradle wrapper (`gradlew`), `AndroidManifest.xml`, Java launcher activity, Capacitor plugin mappings, and resource assets.
- ✅ **Automated Free Cloud APK Builder**: `.github/workflows/build-apk.yml`.
- ✅ **Privacy Policy & Standards**: Kenyan Data Protection Act (DPA 2019) HTML policy and Softonic PAD XML feed.

### External Services & Configuration Checklist (What Requires Real Credentials):
The downloadable source code contains **zero hardcoded private secrets or API keys**. All services are safely defaulted:

1. **Safaricom Daraja STK Push**:
   - Currently operating in high-fidelity simulation mode with full M-Pesa receipt generation and Safaricom SMS text auto-extraction.
   - For real M-Pesa transactions in Kenya: Register at [developer.safaricom.co.ke](https://developer.safaricom.co.ke) for a Shortcode (Paybill/Till), Consumer Key, Consumer Secret, and Passkey.
2. **Google AdMob**:
   - Pre-configured with official Google Mobile Ads **Test Ad Unit IDs** (`ca-app-pub-3940256099942544/...`).
   - For real revenue: Create a free Google AdMob account at [admob.google.com](https://admob.google.com) and replace the test IDs with your production Ad Unit IDs.
3. **SMS OTP Gateway**:
   - Uses simulated OTP verification. For live network SMS delivery, integrate Africa's Talking or Twilio.
4. **Data Persistence**:
   - The app persists data in browser/WebView `localStorage` and device storage. For real-time multi-device cloud synchronization across 50+ members simultaneously, connect a backend database (Firebase Firestore or PostgreSQL).

---

## 📂 7. Complete Manifest of Included Files

```
chamasmart-kenya/
├── .github/
│   └── workflows/
│       └── build-apk.yml         # Cloud APK build script
├── .env.example                  # Environment variable template
├── .gitignore                    # Git ignore file
├── README.md                     # This complete guide
├── index.html                    # Web app entry point
├── metadata.json                 # App metadata
├── package.json                  # Dependencies & scripts
├── tsconfig.json                 # TypeScript compiler configuration
├── vite.config.ts                # Vite bundler configuration
├── capacitor.config.json         # Capacitor Android configuration
├── public/                       # Static public assets
│   ├── icon.svg                  # High-resolution vector icon
│   ├── manifest.json             # Web App Manifest
│   ├── pad_file.xml              # Softonic PAD XML feed
│   ├── privacy.html              # Kenya DPA 2019 Privacy Policy
│   └── uptodown-meta.json        # Uptodown developer manifest
├── src/                          # Application source code
│   ├── App.tsx                   # Main React container & router
│   ├── main.tsx                  # React DOM mount point
│   ├── index.css                 # Global Tailwind CSS directives
│   ├── components/               # UI components
│   │   ├── AndroidFrame.tsx      # Mobile framing & status bar
│   │   ├── BottomNav.tsx         # Mobile navigation bar
│   │   ├── Header.tsx            # Top app bar & chama switcher
│   │   ├── AdMobBanner.tsx       # AdMob banner module
│   │   ├── DarajaStkModal.tsx    # Safaricom M-Pesa STK modal
│   │   ├── ReceiptModal.tsx      # Printable/shareable KES receipt
│   │   ├── AuthModal.tsx         # Login, OTP & registration
│   │   ├── CreateChamaModal.tsx  # Chama onboarding wizard
│   │   └── PublishModal.tsx      # Store publishing console & downloads
│   ├── views/                    # Full view modules
│   │   ├── DashboardView.tsx     # Chama overview & quick actions
│   │   ├── MembersView.tsx       # Member directory & roles
│   │   ├── ContributionsView.tsx # Savings & contribution ledger
│   │   ├── LoansView.tsx         # Loan calculator & dual sign-off
│   │   ├── LedgerExpensesView.tsx# Double-entry audit trail
│   │   ├── MeetingsView.tsx      # Agendas, minutes & voting polls
│   │   ├── ReportsView.tsx       # Financial statements & CSV export
│   │   ├── AdSettingsView.tsx    # AdMob monetization control panel
│   │   ├── SettingsPrivacyView.tsx# DPA 2019 data export & deletion
│   │   └── MoreView.tsx          # Settings & distribution links
│   ├── services/                 # Business logic & local storage
│   │   ├── storageService.ts     # LocalStorage state management
│   │   └── darajaSimulator.ts    # M-Pesa STK & SMS parser
│   ├── types/                    # Data contracts & interfaces
│   │   └── index.ts              # Full TypeScript typings
│   └── i18n/                     # Kiswahili & English dictionary
│       └── translations.ts       # Bilingual translation maps
└── android/                      # Native Android Studio Project
    ├── build.gradle              # Project-level Gradle config
    ├── settings.gradle           # Gradle settings
    ├── gradlew                   # Linux/macOS Gradle wrapper
    ├── gradlew.bat               # Windows Gradle wrapper
    ├── variables.gradle          # Android SDK & library versions
    ├── capacitor.settings.gradle # Capacitor plugin linker
    └── app/
        ├── build.gradle          # App-level Gradle config (ke.chamasmart.app)
        ├── proguard-rules.pro    # ProGuard code optimization rules
        └── src/
            └── main/
                ├── AndroidManifest.xml # Android app manifest & permissions
                ├── java/ke/chamasmart/app/MainActivity.java # Android entry point
                ├── assets/       # Packaged production web assets
                └── res/          # Icons, splash screens, and strings
```

---

## ⚖️ License
Licensed under the Apache License, Version 2.0. Copyright © 2026 ChamaSmart Kenya.
